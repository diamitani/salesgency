export type WorkflowId =
  | 'prospect-automation'
  | 'inbound-automation'
  | 'pre-call-workflow'
  | 'post-call-workflow'
  | 'daily-execution-report'
  | 'gtm-dashboard';

export interface WorkflowItem {
  id: WorkflowId;
  number: string;
  title: string;
  subtitle: string;
  category: 'Outbound' | 'Inbound' | 'Meetings' | 'Reporting' | 'Intelligence';
  summary: string;
  fullDescription: string;
  stackIntegration: string[];
  businessImpact: string;
  blueprintReference: 'AEORIM AI' | 'VNTNR Logistics' | 'ARCHIN Robotics' | 'Internal Core';
  deliverables: string[];
  metricsTarget: string;
}

export interface OptionalProject {
  id: string;
  title: string;
  badge: string;
  description: string;
  capabilities: string[];
  architecture: string;
  estimatedDelivery: string;
}

export interface RoadmapPhase {
  phaseNumber: string;
  title: string;
  dateRange: string;
  status: 'upcoming' | 'milestone' | 'active';
  summary: string;
  activities: string[];
  deliverables: string[];
}

export interface ThreeTItem {
  key: 'Timeline' | 'Transaction' | 'Technology';
  headline: string;
  subtitle: string;
  points: string[];
  icon: string;
}

export interface ProposalMetadata {
  title: string;
  subtitle: string;
  client: string;
  author: string;
  authorTitle: string;
  company: string;
  brand: string;
  proposalDate: string;
  kickoffDate: string;
  initialEngagementDate: string;
  checkupDate: string;
  engagementLength: string;
}
