import React, { useState } from 'react';
import { OPTIONAL_PROJECTS } from '../data/proposalData';
import { 
  Bot, 
  Sparkles, 
  GraduationCap, 
  Check, 
  PlusCircle, 
  CheckCircle2, 
  Cpu, 
  Layers,
  ArrowRight
} from 'lucide-react';

export const OptionalProjectsSection: React.FC = () => {
  const [selectedOptionalIds, setSelectedOptionalIds] = useState<string[]>([]);

  const toggleProject = (id: string) => {
    setSelectedOptionalIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const getIcon = (id: string) => {
    switch (id) {
      case 'custom-sdr-agent':
        return <Bot className="w-6 h-6 text-cyan-400" />;
      case 'sales-enablement-agent':
        return <Cpu className="w-6 h-6 text-purple-400" />;
      case 'gtm-coe':
        return <GraduationCap className="w-6 h-6 text-emerald-400" />;
      default:
        return <Sparkles className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="optional-projects" className="py-14 border-b border-slate-800 bg-slate-950/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20 text-xs font-mono mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              SECTION 04 • HIGH-IMPACT EXTENSIONS
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Optional Expansion Projects
            </h2>
            <p className="mt-2 text-slate-300 max-w-2xl text-sm sm:text-base">
              Autonomous agents and organizational enablement modules available as sprint add-ons 
              or for activation in Phase 2.
            </p>
          </div>

          <div className="text-xs font-mono text-slate-400 bg-slate-900 border border-slate-800 px-3.5 py-2 rounded-lg self-start md:self-auto">
            Optional Projects Selected: <strong className="text-cyan-400">{selectedOptionalIds.length} of 3</strong>
          </div>
        </div>

        {/* 3 Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {OPTIONAL_PROJECTS.map((project) => {
            const isSelected = selectedOptionalIds.includes(project.id);
            return (
              <div
                key={project.id}
                className={`relative rounded-2xl border p-6 flex flex-col justify-between transition-all ${
                  isSelected
                    ? 'bg-slate-900/90 border-cyan-500/60 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/40'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                      {getIcon(project.id)}
                    </div>
                    <span className="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {project.estimatedDelivery}
                    </span>
                  </div>

                  <div className="text-[11px] font-mono text-cyan-400 font-semibold uppercase mb-1">
                    {project.badge}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">
                    {project.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed mb-5">
                    {project.description}
                  </p>

                  {/* Capabilities List */}
                  <div className="space-y-2 mb-5">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                      Key Capabilities
                    </div>
                    {project.capabilities.map((cap, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{cap}</span>
                      </div>
                    ))}
                  </div>

                  {/* Architecture */}
                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[11px] font-mono text-slate-400 mb-4">
                    <span className="text-slate-500 block text-[10px] uppercase font-bold">Technical Stack:</span>
                    <span className="text-slate-200">{project.architecture}</span>
                  </div>
                </div>

                {/* Scope Selection Button */}
                <button
                  onClick={() => toggleProject(project.id)}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {isSelected ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-slate-950" />
                      Included in Proposal Scope
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-4 h-4 text-cyan-400" />
                      Add to Activation Scope
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* CoE Video & Skills Library Highlight */}
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-purple-950/30 via-slate-900 to-cyan-950/30 border border-purple-500/20 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">
                Institutional Knowledge Guarantee: GTM Center of Excellence
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Every automation built by Patrick Diamitani is documented with custom AI video walkthroughs 
                and versioned skills, ensuring Praecipio’s team retains permanent operational mastery.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs font-mono text-purple-300 bg-purple-950/60 border border-purple-500/30 px-3 py-1.5 rounded-lg">
              Library of Internal Skills & Workflows
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
