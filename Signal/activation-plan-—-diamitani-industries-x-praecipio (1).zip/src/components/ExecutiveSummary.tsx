import React from 'react';
import { ENGAGEMENT_COMPARISON, PROPOSAL_METADATA } from '../data/proposalData';
import { 
  CheckCircle2, 
  ArrowRight, 
  Zap, 
  Cpu, 
  TrendingUp, 
  ShieldAlert, 
  Sparkles,
  Users,
  Compass,
  FileCode2
} from 'lucide-react';

export const ExecutiveSummary: React.FC<{ onNavigateToWorkflows: () => void }> = ({ onNavigateToWorkflows }) => {
  return (
    <section id="overview" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono mb-3">
            <Compass className="w-3.5 h-3.5" />
            SECTION 01 • STRATEGIC CONTEXT & ENGAGEMENT OVERVIEW
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            About The Engagement
          </h2>
          <p className="mt-3 text-lg text-slate-300 max-w-3xl leading-relaxed">
            Praecipio Consulting is currently interested in reviewing Patrick Diamitani for an internal GTM role, 
            or Forward Deployed AI Engineer opportunity.
          </p>
        </div>

        {/* The Strategic Pivot Banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-cyan-950/40 border border-cyan-500/30 p-6 sm:p-8 mb-12 shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-400 text-slate-950 font-bold text-xs mb-4">
                <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                THE PROPOSED MODEL: 6-MONTH CONSULTING ACTIVATION
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                High-Velocity Execution Without Headcount Overhead
              </h3>
              <p className="mt-4 text-slate-300 leading-relaxed text-sm sm:text-base">
                This plan proposes, instead, a <strong>6 month consulting activation with the option to renew</strong>, 
                whereas Patrick Diamitani consults, strategizes, and executes directly on a variety of internal go-to-market efforts.
              </p>
              <p className="mt-2 text-slate-400 text-sm leading-relaxed">
                Rather than dealing with long enterprise hiring cycles, internal payroll overhead, and rigid job descriptions, 
                Praecipio gains immediate access to a forward-deployed AI architect who builds, integrates, monitors, and optimizes 
                customized, revenue-generating autonomous pipelines from Day 1.
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-4 text-xs font-mono text-cyan-300">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-950/60 border border-slate-800">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  Initial Engagement: {PROPOSAL_METADATA.initialEngagementDate}
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-950/60 border border-slate-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Official Kickoff: {PROPOSAL_METADATA.kickoffDate}
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-950/60 border border-slate-800">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  {PROPOSAL_METADATA.checkupDate}
                </div>
              </div>
            </div>

            {/* Quick Value Metrics */}
            <div className="lg:col-span-4 bg-slate-950/80 rounded-xl p-5 border border-slate-800 space-y-4">
              <h4 className="text-xs uppercase tracking-wider text-slate-400 font-semibold font-mono">
                Activation Commitments
              </h4>
              
              <div className="flex items-start gap-3">
                <div className="p-1.5 rounded bg-cyan-500/10 text-cyan-400 shrink-0 mt-0.5">
                  <Cpu className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">6 Core Custom Automations</div>
                  <div className="text-xs text-slate-400">Production-grade, end-to-end integration</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-1.5 rounded bg-emerald-500/10 text-emerald-400 shrink-0 mt-0.5">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">Continuous Ad-Hoc Skills</div>
                  <div className="text-xs text-slate-400">Rapid construction of new agents as needed</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-1.5 rounded bg-purple-500/10 text-purple-400 shrink-0 mt-0.5">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">Dedicated Weekly Cadence</div>
                  <div className="text-xs text-slate-400">Standups, office hours, and unlimited direct access</div>
                </div>
              </div>

              <button
                onClick={onNavigateToWorkflows}
                className="w-full mt-2 py-2.5 px-4 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-semibold text-xs border border-cyan-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                Explore 6 Core Workflows
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Side-by-Side Comparison: Activation vs Internal FTE */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-white tracking-tight">
                Comparison: 6-Month Activation Plan vs. Full-Time Internal Hire
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Evaluating the strategic trade-offs between a dedicated consulting activation and permanent headcount.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/80 text-xs font-mono text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-5 font-semibold">Strategic Dimension</th>
                  <th className="py-3.5 px-5 font-semibold text-cyan-400 bg-cyan-950/20 border-l border-r border-cyan-500/20">
                    6-Month Consulting Activation (Proposed)
                  </th>
                  <th className="py-3.5 px-5 font-semibold text-slate-400">
                    Traditional Internal Full-Time Hire
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {ENGAGEMENT_COMPARISON.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-4 px-5 font-medium text-slate-200">
                      {row.attribute}
                    </td>
                    <td className="py-4 px-5 text-slate-100 bg-cyan-950/10 border-l border-r border-cyan-500/10 font-medium">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{row.consultingActivation}</span>
                      </div>
                    </td>
                    <td className="py-4 px-5 text-slate-400 text-xs sm:text-sm">
                      {row.internalHire}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* The 3 Pillars of Patrick Diamitani's Mandate */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center mb-4">
              <Compass className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">1. Strategy & ICP Architecture</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Aligning Praecipio’s consulting offerings (Atlassian, DevOps, Cloud) with razor-sharp account targeting, 
              intent triggers, and executive value propositions.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-4">
              <FileCode2 className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">2. Forward-Deployed Engineering</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Hands-on building of resilient, fault-tolerant automations across Clay, Claude, HubSpot, Salesforce, 
              meeting tools, and custom API webhook layers.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center mb-4">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">3. Team Enablement & CoE</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Upskilling Praecipio’s sales reps and practice leads through weekly office hours, standups, and documentation 
              to ensure permanent institutional value.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
