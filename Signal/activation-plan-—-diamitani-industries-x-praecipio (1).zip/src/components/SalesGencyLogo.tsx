import React from 'react';

interface SalesGencyLogoProps {
  variant?: 'gradient' | 'dark' | 'light' | 'auto';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  withGlow?: boolean;
}

export const SalesGencyLogo: React.FC<SalesGencyLogoProps> = ({
  variant = 'gradient',
  size = 'md',
  className = '',
  withGlow = false
}) => {
  const sizeClasses = {
    xs: 'text-base tracking-tight',
    sm: 'text-lg tracking-tight',
    md: 'text-2xl tracking-tight',
    lg: 'text-3xl tracking-tight',
    xl: 'text-4xl sm:text-5xl tracking-tight font-black'
  };

  const dotSizes = {
    xs: 'w-1.5 h-1.5 ml-0.5',
    sm: 'w-2 h-2 ml-0.5',
    md: 'w-2.5 h-2.5 ml-1',
    lg: 'w-3 h-3 ml-1',
    xl: 'w-3.5 h-3.5 ml-1.5'
  };

  if (variant === 'light') {
    return (
      <div className={`inline-flex items-baseline font-bold select-none ${sizeClasses[size]} ${className}`}>
        <span className="text-slate-900 font-extrabold tracking-tight">Sales</span>
        <span className="text-slate-900 font-extrabold tracking-tight">Gency</span>
        <span className={`inline-block rounded-full bg-[#0284C7] ${dotSizes[size]}`} />
      </div>
    );
  }

  if (variant === 'dark') {
    return (
      <div className={`inline-flex items-baseline font-bold select-none ${sizeClasses[size]} ${className}`}>
        <span className="text-slate-900 font-extrabold tracking-tight">Sales</span>
        <span className="text-slate-900 font-extrabold tracking-tight">Gency</span>
        <span
          className={`inline-block rounded-full bg-[#0284C7] ${dotSizes[size]} ${
            withGlow ? 'shadow-[0_0_8px_rgba(2,132,199,0.5)]' : ''
          }`}
        />
      </div>
    );
  }

  // Default: Crisp modern gradient variant for white background
  return (
    <div className={`inline-flex items-baseline font-bold select-none ${sizeClasses[size]} ${className}`}>
      <span className="text-slate-900 font-extrabold tracking-tight">Sales</span>
      <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent font-extrabold tracking-tight">
        Gency
      </span>
      <span
        className={`inline-block rounded-full bg-[#0284C7] ${dotSizes[size]} ${
          withGlow ? 'shadow-[0_0_10px_rgba(2,132,199,0.6)]' : ''
        }`}
      />
    </div>
  );
};

export const PartnershipBadge: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-slate-200 bg-white/95 shadow-sm text-xs font-semibold text-slate-700 ${className}`}>
      <div className="flex items-center gap-1.5">
        <SalesGencyLogo size="xs" variant="gradient" withGlow={false} />
      </div>
      <span className="text-slate-300 font-normal">×</span>
      <div className="flex items-center gap-1.5 text-slate-800 font-bold tracking-tight">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
        Praecipio Consulting
      </div>
    </div>
  );
};
