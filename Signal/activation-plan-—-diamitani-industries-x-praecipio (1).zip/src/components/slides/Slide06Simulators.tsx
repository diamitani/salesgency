import React, { useState } from 'react';
import { 
  Sliders, 
  Send, 
  Zap, 
  Clock, 
  TrendingUp, 
  CheckCircle2, 
  FileText, 
  DollarSign, 
  Calculator,
  ArrowRight,
  RotateCcw
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
}

export const Slide06Simulators: React.FC<SlideProps> = ({ onNext }) => {
  const [activeTab, setActiveTab] = useState<'outbound' | 'inbound' | 'precall' | 'roi'>('outbound');

  // Simulator 1: Outbound State
  const [targetAccount, setTargetAccount] = useState('Fintech Enterprise (2,500+ seats, Jira Cloud Migration)');
  const [outboundTone, setOutboundTone] = useState<'consultative' | 'direct' | 'technical'>('consultative');

  // Simulator 2: Inbound State
  const [leadTier, setLeadTier] = useState<'enterprise' | 'growth'>('enterprise');
  const [routedRep, setRoutedRep] = useState('Sarah Jenkins (Strategic Accounts)');

  // Simulator 4: ROI Calculator State
  const [repsCount, setRepsCount] = useState(8);
  const [hoursPerWeek, setHoursPerWeek] = useState(14);
  const [averageDealSize, setAverageDealSize] = useState(65000);

  // ROI calculations
  const totalHoursSavedMonthly = repsCount * (hoursPerWeek * 0.75) * 4;
  const equivalentFTECapacity = (totalHoursSavedMonthly / 160).toFixed(1);
  const projectedPipelineLift = Math.round(repsCount * averageDealSize * 0.35);

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 06 • ARCHITECTURE TEST-DRIVE</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Interactive Workflow Simulators
          </h2>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
            Live Preview Sandbox
          </span>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          Experience how Praecipio's custom workflows process real-world inputs into revenue-generating outputs.
        </p>
      </div>

      {/* Simulator Switcher Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'outbound', label: '1. Outbound PAS Engine', icon: Send },
          { id: 'inbound', label: '2. Inbound Speed-to-Lead', icon: Zap },
          { id: 'precall', label: '3. Pre-Call Dossier Brief', icon: FileText },
          { id: 'roi', label: '4. Praecipio Capacity Calculator', icon: Calculator },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Simulator Container */}
      <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-7 shadow-sm">
        
        {/* Tab 1: Outbound Simulator */}
        {activeTab === 'outbound' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <h3 className="text-base font-bold text-slate-900">Target Scenario Parameters</h3>
              
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1.5">Target Account Profile:</label>
                <select
                  value={targetAccount}
                  onChange={(e) => setTargetAccount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-medium"
                >
                  <option value="Fintech Enterprise (2,500+ seats, Jira Cloud Migration)">Fintech Enterprise (2,500+ seats, Jira Cloud Migration)</option>
                  <option value="Healthcare Provider (5,000+ employees, ITSM Optimization)">Healthcare Provider (5,000+ employees, ITSM Optimization)</option>
                  <option value="SaaS Scaleup ($50M ARR, Confluence & Agile Transformation)">SaaS Scaleup ($50M ARR, Confluence & Agile Transformation)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1.5">Rep Tone Calibration:</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['consultative', 'direct', 'technical'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setOutboundTone(t)}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold capitalize border transition-all cursor-pointer ${
                        outboundTone === t
                          ? 'bg-sky-50 border-sky-400 text-sky-800'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span>Predicted Deliverability:</span>
                  <strong className="text-emerald-700 font-bold">99.2% (Warmup active)</strong>
                </div>
                <div className="flex justify-between">
                  <span>Benchmark Reply Rate:</span>
                  <strong className="text-sky-700 font-bold">24.2% (AEORIM Blueprint)</strong>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 bg-slate-50 rounded-xl p-5 border border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">Auto-Generated Sequence Draft (Step 1 of 5)</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-bold">Verified Valid</span>
                </div>

                <div className="mt-4 text-xs text-slate-700 space-y-3 leading-relaxed">
                  <p><strong>Subject:</strong> Praecipio insight: Accelerating Jira Cloud migration for {targetAccount.split(' ')[0]}</p>
                  <p>Hi Alex,</p>
                  <p>
                    Saw {targetAccount.split(' ')[0]} is scaling its engineering footprint while orchestrating enterprise Atlassian tooling across distributed units.
                  </p>
                  <p>
                    Most VP of Engineering teams we partner with at Praecipio hit friction points around custom workflow governance, legacy Jira server plugin parity, and compliance controls during cloud cutover.
                  </p>
                  <p>
                    Would you be opposed to a brief 15-minute peer benchmark on how leading fintechs structured their migration runway?
                  </p>
                  <p className="text-slate-500 pt-2">— Sent via Praecipio SDR Team (Automated Research Attributed)</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <span>Personalization Factors: 4 data points matched</span>
                <span className="text-sky-700 font-bold">Ready for rep dispatch</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Inbound Speed-to-Lead */}
        {activeTab === 'inbound' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-900">Incoming Webhook Payload Simulation</h3>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block">Prospect:</span>
                  <strong className="text-slate-800">Elena Rostova • VP Digital Transformation</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Company:</span>
                  <strong className="text-slate-800">Apex Medical Systems (3,800 employees)</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Inquiry Type:</span>
                  <span className="inline-block px-2 py-0.5 rounded bg-sky-100 text-sky-800 font-bold mt-1">
                    Atlassian Enterprise Agile / Jira Align RFP
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setLeadTier('enterprise')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border cursor-pointer ${
                    leadTier === 'enterprise' ? 'bg-sky-50 border-sky-400 text-sky-800' : 'bg-white border-slate-200 text-slate-600'
                  }`}
                >
                  Enterprise Route ($100k+)
                </button>
                <button
                  onClick={() => setLeadTier('growth')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border cursor-pointer ${
                    leadTier === 'growth' ? 'bg-sky-50 border-sky-400 text-sky-800' : 'bg-white border-slate-200 text-slate-600'
                  }`}
                >
                  Mid-Market Route ($30k+)
                </button>
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="font-bold text-slate-800">Sub-90-Second Routing Telemetry</span>
                <span className="text-emerald-700 font-bold">Latency: 42 seconds</span>
              </div>

              <div className="space-y-2 text-slate-700">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Form Ingestion:</strong> Normalization verified without data loss.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Firmographic Enrichment:</strong> Clearbit appended 3,800 headcount, Healthcare vertical.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>AI Intent Score:</strong> 94/100 (High Buying Intent / Active RFP).</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>CRM Sync:</strong> Record populated in HubSpot & Salesforce concurrently.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Slack Alert:</strong> Dispatched to {leadTier === 'enterprise' ? 'Enterprise Pod #1' : 'Commercial AE Pod'} with personalized reply draft.</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Pre-Call Dossier Brief */}
        {activeTab === 'precall' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-xs">
              <div>
                <span className="font-bold text-slate-900 text-sm block">Pre-Meeting Intelligence Briefing</span>
                <span className="text-slate-500">Delivered 60 minutes prior to external discovery call</span>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 font-semibold text-[11px]">
                Auto-Synchronized with Google / Outlook Calendar
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block text-xs uppercase tracking-wider">Target Executive</span>
                <div className="font-bold text-slate-900 text-sm">Marcus Vance</div>
                <p className="text-slate-600">Head of Enterprise Architecture, Global Retail Corp</p>
                <p className="text-slate-500 text-[11px]">Past roles: 6 yrs Director at Nordstrom, heavy Atlassian champion.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block text-xs uppercase tracking-wider">Company Trigger Events</span>
                <div className="font-bold text-slate-900 text-sm">Acquisition + Tool Consolidation</div>
                <p className="text-slate-600">Recently acquired 2 subsidiaries. Needs to migrate 4 Jira instances into single cloud org.</p>
                <p className="text-slate-500 text-[11px]">Q3 deadline announced in public press release.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block text-xs uppercase tracking-wider">Recommended Discovery Questions</span>
                <ul className="text-slate-700 space-y-1.5 list-disc list-inside">
                  <li>How are you managing custom field sprawl across instances?</li>
                  <li>What is the security timeline for Atlassian Guard?</li>
                  <li>Who is owning the change management mandate?</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: ROI & Capacity Calculator */}
        {activeTab === 'roi' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-6 space-y-4 text-xs">
              <h3 className="text-base font-bold text-slate-900">Praecipio Sales Team Inputs</h3>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Number of Quota-Carrying Reps / Consultants:</span>
                  <span className="text-sky-700 font-bold">{repsCount} Reps</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="30"
                  value={repsCount}
                  onChange={(e) => setRepsCount(Number(e.target.value))}
                  className="w-full accent-sky-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Current Admin & Prospecting Hours / Week / Rep:</span>
                  <span className="text-sky-700 font-bold">{hoursPerWeek} Hours</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="25"
                  value={hoursPerWeek}
                  onChange={(e) => setHoursPerWeek(Number(e.target.value))}
                  className="w-full accent-sky-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Average Consulting Deal Size (ACV):</span>
                  <span className="text-sky-700 font-bold">${averageDealSize.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="20000"
                  max="200000"
                  step="5000"
                  value={averageDealSize}
                  onChange={(e) => setAverageDealSize(Number(e.target.value))}
                  className="w-full accent-sky-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="lg:col-span-6 grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-sky-50 border border-sky-200">
                <span className="text-[11px] font-bold text-sky-800 uppercase tracking-wider block mb-1">
                  Rep Capacity Unlocked
                </span>
                <div className="text-2xl font-black text-slate-900">
                  {totalHoursSavedMonthly.toLocaleString()} hrs
                </div>
                <span className="text-[11px] text-slate-600">saved per month across team</span>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                  Equivalent FTE Gain
                </span>
                <div className="text-2xl font-black text-slate-900">
                  +{equivalentFTECapacity} Full-Time Reps
                </div>
                <span className="text-[11px] text-slate-600">in productive selling time</span>
              </div>

              <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 col-span-2">
                <span className="text-[11px] font-bold text-indigo-800 uppercase tracking-wider block mb-1">
                  Estimated New Pipeline Generated
                </span>
                <div className="text-3xl font-black text-slate-900">
                  ${projectedPipelineLift.toLocaleString()}
                </div>
                <span className="text-xs text-slate-600">based on 35% outbound velocity uplift over 6-month term</span>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Presenter Notes / Key Takeaway */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Measurable Value:</strong> Reclaiming 10+ hours per rep per week immediately translates into higher deal volume and faster sales cycles.
          </span>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: Expansion Projects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
