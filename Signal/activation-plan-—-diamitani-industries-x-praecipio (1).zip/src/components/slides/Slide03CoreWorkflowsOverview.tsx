import React from 'react';
import { CORE_WORKFLOWS } from '../../data/proposalData';
import { 
  Workflow, 
  Send, 
  Layers, 
  FileText, 
  CheckSquare, 
  Activity, 
  BarChart3, 
  Sparkles, 
  ArrowRight,
  ChevronRight
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
  onSelectWorkflowDetail?: (workflowId: string) => void;
}

export const Slide03CoreWorkflowsOverview: React.FC<SlideProps> = ({ onNext, onSelectWorkflowDetail }) => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'prospect-automation':
        return <Send className="w-5 h-5 text-sky-600" />;
      case 'inbound-automation':
        return <Layers className="w-5 h-5 text-emerald-600" />;
      case 'pre-call-workflow':
        return <FileText className="w-5 h-5 text-indigo-600" />;
      case 'post-call-workflow':
        return <CheckSquare className="w-5 h-5 text-purple-600" />;
      case 'daily-execution-report':
        return <Activity className="w-5 h-5 text-amber-600" />;
      case 'gtm-dashboard':
        return <BarChart3 className="w-5 h-5 text-rose-600" />;
      default:
        return <Workflow className="w-5 h-5 text-sky-600" />;
    }
  };

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 03 • CORE DELIVERABLES CATALOG</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            The 6 Core Custom Workflows
          </h2>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-sky-100 text-sky-800">
            Tailored to Praecipio's Tech Stack
          </span>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          Six battle-tested, customized automations deployed sequentially across Praecipio's GTM organization, 
          backed by continuous ad-hoc engineering support throughout the 6-month activation.
        </p>
      </div>

      {/* 6 Workflows Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {CORE_WORKFLOWS.map((wf) => (
          <div
            key={wf.id}
            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-sky-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  {getIcon(wf.id)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">WF-{wf.number}</span>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                    {wf.category}
                  </span>
                </div>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug mb-1">
                {wf.title}
              </h3>
              <p className="text-xs text-sky-700 font-medium mb-2.5">
                {wf.subtitle}
              </p>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                {wf.summary}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium truncate max-w-[170px]">
                Target: <strong className="text-slate-800">{wf.metricsTarget.split('|')[0]}</strong>
              </span>
              {onSelectWorkflowDetail && (
                <button
                  onClick={() => onSelectWorkflowDetail(wf.id)}
                  className="text-sky-600 hover:text-sky-700 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>Details</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Ad-Hoc Engineering Commitment Guarantee */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-sky-50 to-indigo-50 border border-sky-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0 font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <strong className="text-slate-900 block text-sm">Ad-Hoc Engineering Included</strong>
            <span className="text-slate-600">
              Beyond these 6 core workflows, Patrick will architect, test, and iterate on unlisted custom skills, webhook bridges, and internal prompt tools as needs emerge.
            </span>
          </div>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: Workflows 1–3</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
