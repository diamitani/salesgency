import React from 'react';
import { OPTIONAL_PROJECTS } from '../../data/proposalData';
import { 
  Bot, 
  Cpu, 
  GraduationCap, 
  Check, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  Video
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
}

export const Slide07ExpansionProjects: React.FC<SlideProps> = ({ onNext }) => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'custom-sdr-agent':
        return <Bot className="w-6 h-6 text-sky-600" />;
      case 'sales-enablement-agent':
        return <Cpu className="w-6 h-6 text-purple-600" />;
      case 'gtm-coe':
        return <GraduationCap className="w-6 h-6 text-emerald-600" />;
      default:
        return <Sparkles className="w-6 h-6 text-sky-600" />;
    }
  };

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 07 • OPTIONAL EXPANSION MODULES</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            High-Impact Expansion Projects
          </h2>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-purple-100 text-purple-800">
            Sprint Add-Ons & Phase 2 Modules
          </span>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          Advanced autonomous agents and enablement modules available for concurrent activation or post-Q1 checkpoint rollout.
        </p>
      </div>

      {/* 3 Expansion Project Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {OPTIONAL_PROJECTS.map((proj) => (
          <div
            key={proj.id}
            className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-purple-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  {getIcon(proj.id)}
                </div>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {proj.estimatedDelivery}
                </span>
              </div>

              <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider block mb-1">
                {proj.badge}
              </span>
              <h3 className="text-lg font-bold text-slate-900 leading-snug mb-2">
                {proj.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                {proj.description}
              </p>

              <div className="space-y-2 mb-4">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Capabilities Included
                </span>
                {proj.capabilities.map((cap, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{cap}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600">
              <span className="text-slate-500 font-semibold block">Architecture:</span>
              <span className="font-medium text-slate-800">{proj.architecture}</span>
            </div>
          </div>
        ))}
      </div>

      {/* GTM Center of Excellence Highlight Box */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-50 via-white to-sky-50 border border-purple-200 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">
              Institutional Knowledge Transfer: Praecipio GTM Center of Excellence
            </h4>
            <p className="text-xs text-slate-600 mt-0.5 max-w-2xl">
              Every workflow built by Patrick is documented with personalized AI video tutorials and versioned skills, 
              ensuring Praecipio’s team retains permanent operational capability.
            </p>
          </div>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap text-xs shrink-0"
          >
            <span>Next: Activation Roadmap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
