import React, { useState } from 'react';
import { CORE_WORKFLOWS } from '../../data/proposalData';
import { 
  Send, 
  Layers, 
  FileText, 
  CheckCircle, 
  Cpu, 
  Sparkles, 
  ArrowRight,
  TrendingUp,
  ExternalLink
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
  onOpenBrandModal?: () => void;
}

export const Slide04WorkflowsDeepDive1: React.FC<SlideProps> = ({ onNext, onOpenBrandModal }) => {
  const workflows = CORE_WORKFLOWS.slice(0, 3);
  const [activeTab, setActiveTab] = useState<string>(workflows[0].id);

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 04 • DEEP DIVE: WORKFLOWS 01 TO 03</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Outbound, Inbound & Pre-Call Intelligence
          </h2>
          {onOpenBrandModal && (
            <button
              onClick={onOpenBrandModal}
              className="text-xs font-semibold text-sky-600 hover:text-sky-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View Client Architecture Blueprints</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          Detailed technical specifications, inputs, LLM reasoning logic, and direct sales rep impacts for the first three core workflows.
        </p>
      </div>

      {/* 3 Interactive Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {workflows.map((wf) => {
          const isSelected = activeTab === wf.id;
          return (
            <div
              key={wf.id}
              onClick={() => setActiveTab(wf.id)}
              className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-white border-sky-400 shadow-md ring-2 ring-sky-100'
                  : 'bg-slate-50/80 border-slate-200 hover:bg-white hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">
                    Workflow #{wf.number} • {wf.category}
                  </span>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                    {wf.blueprintReference}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 leading-snug mb-2">
                  {wf.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {wf.fullDescription}
                </p>

                {/* Key Deliverables */}
                <div className="space-y-2 mb-4">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Core Capabilities
                  </div>
                  {wf.deliverables.slice(0, 3).map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                {/* Tech Integration */}
                <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200 text-xs mb-3">
                  <span className="text-slate-500 font-semibold block text-[11px]">Integrated Stack:</span>
                  <span className="text-slate-800 font-medium">{wf.stackIntegration.slice(0, 3).join(' • ')}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Metric Target:</span>
                <span className="text-sky-800 font-bold">{wf.metricsTarget.split('|')[0]}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Presenter Notes / Key Takeaway */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-sky-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Immediate Impact:</strong> Reps save 15+ hours weekly on prospecting research, eliminate manual inbound routing delays, and walk into every executive call fully briefed.
          </span>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: Workflows 4–6</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
