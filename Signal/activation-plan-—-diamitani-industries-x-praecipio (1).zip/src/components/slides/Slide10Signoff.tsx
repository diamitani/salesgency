import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { SalesGencyLogo } from '../SalesGencyLogo';
import { PROPOSAL_METADATA } from '../../data/proposalData';
import { 
  CheckCircle2, 
  Printer, 
  ShieldCheck, 
  Sparkles, 
  Award,
  Calendar,
  Lock,
  Download
} from 'lucide-react';

export const Slide10Signoff: React.FC = () => {
  const [signerName, setSignerName] = useState('');
  const [signerTitle, setSignerTitle] = useState('Executive Sponsor');
  const [agreedTerms, setAgreedTerms] = useState(true);
  const [isSigned, setIsSigned] = useState(false);
  const [signedTimestamp, setSignedTimestamp] = useState<string | null>(null);

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signerName.trim()) return;

    setIsSigned(true);
    setSignedTimestamp(new Date().toLocaleString());

    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      console.log('Confetti triggered');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 10 • FORMAL ENGAGEMENT AUTHORIZATION</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Authorization & Next Steps
          </h2>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-sm transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Executive Brief (PDF)</span>
          </button>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          Confirm acceptance of the 6-Month Consulting Activation Plan to lock in the October 5, 2026 kickoff date.
        </p>
      </div>

      {/* Main Acceptance Block */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Terms Summary */}
        <div className="lg:col-span-6 p-6 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Accepted Terms Summary</span>
              <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-800 text-[11px] font-bold">6-Month Term</span>
            </div>

            <div className="mt-4 space-y-2.5 text-xs text-slate-700">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Scope:</strong> 6 custom production workflows + ongoing ad-hoc forward-deployed engineering.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Key Dates:</strong> Kickoff on Monday, Oct 5, 2026 (Initial Engagement Sept 28).</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Governance:</strong> Weekly standups, office hours, and 3-month review in Q1 2027.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Ownership:</strong> 100% intellectual property ownership of custom workflows transfers to Praecipio.</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white border border-slate-200 text-xs">
            <div className="font-bold text-slate-800 mb-1">Diamitani Industries Consultant Signature</div>
            <div className="font-serif italic text-base text-slate-900 border-b border-slate-300 pb-1">
              Patrick Diamitani
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 mt-1.5">
              <span>Patrick Diamitani, Forward Deployed AI Engineer</span>
              <span>Sept 9, 2026</span>
            </div>
          </div>
        </div>

        {/* Right: Client Acceptance Block */}
        <div className="lg:col-span-6 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Praecipio Client Authorization</span>
              {isSigned ? (
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Authorized
                </span>
              ) : (
                <span className="text-xs text-amber-600 font-semibold">Pending Authorization</span>
              )}
            </div>

            {!isSigned ? (
              <form onSubmit={handleSign} className="mt-4 space-y-3.5 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Authorized Signer Name:
                  </label>
                  <input
                    type="text"
                    required
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    placeholder="e.g. Christopher Smith"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-sky-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Corporate Title:
                  </label>
                  <input
                    type="text"
                    required
                    value={signerTitle}
                    onChange={(e) => setSignerTitle(e.target.value)}
                    placeholder="e.g. Managing Director / VP of Sales"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-sky-500 font-medium"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="agreedTerms"
                    checked={agreedTerms}
                    onChange={(e) => setAgreedTerms(e.target.checked)}
                    className="rounded text-sky-600 focus:ring-sky-500"
                  />
                  <label htmlFor="agreedTerms" className="text-xs text-slate-600 cursor-pointer">
                    I approve the 6-month consulting activation starting October 5, 2026.
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={!signerName.trim() || !agreedTerms}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-xs shadow-sm transition-all cursor-pointer mt-2"
                >
                  Sign & Authorize Activation Plan
                </button>
              </form>
            ) : (
              <div className="mt-5 p-5 rounded-xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
                <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto">
                  <Award className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">Engagement Formally Authorized</h4>
                <div className="font-serif italic text-lg text-emerald-900 font-bold">
                  {signerName}
                </div>
                <p className="text-xs text-slate-600">{signerTitle}, Praecipio Consulting</p>
                <div className="text-[11px] text-slate-500 pt-1">
                  Digital Record: {signedTimestamp} • Status: Locked for Oct 5 Kickoff
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="flex items-center gap-1">
              <Lock className="w-3 h-3 text-slate-400" />
              Secure Digital Acceptance Record
            </span>
            <span>Ref: DI-PC-2026-09</span>
          </div>
        </div>
      </div>

      {/* Presenter Notes / Key Takeaway */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Ready for Launch:</strong> Next immediate milestone is the Initial Engagement session on Monday, September 28, 2026.
          </span>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Save PDF / Print Deck</span>
        </button>
      </div>
    </div>
  );
};
