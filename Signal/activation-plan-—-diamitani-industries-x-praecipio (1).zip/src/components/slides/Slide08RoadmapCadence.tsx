import React from 'react';
import { ROADMAP_PHASES, PROPOSAL_METADATA } from '../../data/proposalData';
import { 
  Calendar, 
  CheckCircle2, 
  Rocket, 
  PhoneCall, 
  ShieldCheck, 
  Clock, 
  ArrowRight,
  MessageSquare
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
}

export const Slide08RoadmapCadence: React.FC<SlideProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 08 • ACTIVATION PROCESS & CADENCE</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            The Activation Roadmap
          </h2>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
            Kickoff: {PROPOSAL_METADATA.kickoffDate}
          </span>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          From initial assessment and credential handoff to production pipeline deployment and structured weekly governance.
        </p>
      </div>

      {/* 3 Executive Guarantees */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-sky-50/70 border border-sky-200 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-sky-600 text-white shrink-0">
            <Rocket className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-sky-900 uppercase tracking-wider block">Key Activation Dates</span>
            <div className="font-bold text-slate-900 text-sm mt-0.5">Kickoff: Oct 5, 2026</div>
            <div className="text-xs text-slate-600">Initial Engagement: Sept 28, 2026</div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-indigo-600 text-white shrink-0">
            <PhoneCall className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-indigo-900 uppercase tracking-wider block">Unlimited Communication</span>
            <div className="font-bold text-slate-900 text-sm mt-0.5">Direct Text, Email & Phone</div>
            <div className="text-xs text-slate-600">Rapid response for urgent pipeline blocks</div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-emerald-600 text-white shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider block">Weekly Operating Cadence</span>
            <div className="font-bold text-slate-900 text-sm mt-0.5">Standups + Office Hours</div>
            <div className="text-xs text-slate-600">Q1 2027 formal 3-month review</div>
          </div>
        </div>
      </div>

      {/* Sequential Phase Steps */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {ROADMAP_PHASES.map((phase) => (
          <div
            key={phase.phaseNumber}
            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-200">
                  {phase.phaseNumber}
                </span>
                <span className="text-[11px] font-semibold text-slate-500">
                  {phase.dateRange.split('(')[0]}
                </span>
              </div>

              <h4 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                {phase.title}
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed mb-3">
                {phase.summary}
              </p>

              <div className="space-y-1.5 pt-3 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Deliverable
                </span>
                <div className="text-xs text-slate-700 font-medium flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{phase.deliverables[0]}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3-Month Checkup Callout */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Q1 2027 Milestone Audit:</strong> Formal performance checkpoint to evaluate workflow ROI, revenue generated, and finalize renewal or expansion decisions.
          </span>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: The 3 Ts Framework</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
