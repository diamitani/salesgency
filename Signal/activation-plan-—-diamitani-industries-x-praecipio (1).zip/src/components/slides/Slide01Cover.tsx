import React from 'react';
import { SalesGencyLogo } from '../SalesGencyLogo';
import { PROPOSAL_METADATA } from '../../data/proposalData';
import { 
  Calendar, 
  Clock, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Building2, 
  CheckCircle2, 
  TrendingUp, 
  Workflow
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
  onJumpToSlide?: (slideIndex: number) => void;
}

export const Slide01Cover: React.FC<SlideProps> = ({ onNext, onJumpToSlide }) => {
  return (
    <div className="flex flex-col justify-between h-full space-y-8">
      {/* Top Meta Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <SalesGencyLogo size="md" variant="gradient" />
          <span className="text-slate-300 text-lg font-light">|</span>
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
            <Building2 className="w-4 h-4 text-slate-500" />
            <span>Diamitani Industries</span>
            <span className="text-slate-300">×</span>
            <span className="text-sky-700 font-bold">Praecipio Consulting</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs text-slate-600 font-medium">
          <Calendar className="w-3.5 h-3.5 text-slate-500" />
          <span>Prepared: September 9, 2026 • 4:59 PM EST</span>
        </div>
      </div>

      {/* Main Title & Executive Proposition */}
      <div className="space-y-6 max-w-4xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-sky-600" />
          EXECUTIVE ACTIVATION PLAN • 6-MONTH CONSULTING ENGAGEMENT
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1]">
          Internal GTM & Forward Deployed AI Infrastructure
        </h1>

        <p className="text-lg sm:text-xl text-slate-600 leading-relaxed max-w-3xl font-normal">
          A high-velocity, customized consulting engagement to architect, deploy, and scale 
          autonomous revenue workflows and AI agent infrastructure across Praecipio Consulting.
        </p>
      </div>

      {/* Key Engagement Parameters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-sky-300 transition-colors">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            <Clock className="w-4 h-4 text-sky-600" />
            Term & Structure
          </div>
          <div className="text-lg font-bold text-slate-900 leading-snug">
            6-Month Activation
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Predictable consulting retainer with mutual option to renew
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-sky-300 transition-colors">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            <Calendar className="w-4 h-4 text-emerald-600" />
            Key Dates
          </div>
          <div className="text-lg font-bold text-slate-900 leading-snug">
            Kickoff: Oct 5, 2026
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Initial assessment Sept 28 • Q1 2027 3-month review
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-sky-300 transition-colors">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            <Workflow className="w-4 h-4 text-indigo-600" />
            Core Deliverables
          </div>
          <div className="text-lg font-bold text-slate-900 leading-snug">
            6 Custom Workflows
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Plus ongoing ad-hoc forward-deployed AI engineering
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-sky-300 transition-colors">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            Consultant
          </div>
          <div className="text-lg font-bold text-slate-900 leading-snug">
            Patrick Diamitani
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Forward Deployed AI Engineer & GTM Strategist
          </p>
        </div>
      </div>

      {/* Bottom Presenter Note / Executive Callout */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-sky-50/60 border border-sky-100 text-xs text-slate-700">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0 font-bold">
            💡
          </div>
          <div>
            <strong className="text-slate-900">Executive Summary Note:</strong> Praecipio gains immediate forward-deployed engineering capacity without FTE overhead, recruiting delays, or severance liabilities.
          </div>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold shadow-sm transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Begin Presentation</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
