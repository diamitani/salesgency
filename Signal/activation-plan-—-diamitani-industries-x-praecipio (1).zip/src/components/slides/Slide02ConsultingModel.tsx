import React from 'react';
import { ENGAGEMENT_COMPARISON } from '../../data/proposalData';
import { 
  CheckCircle2, 
  XCircle, 
  Zap, 
  TrendingUp, 
  ShieldCheck, 
  Clock, 
  DollarSign, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
  onPrev?: () => void;
}

export const Slide02ConsultingModel: React.FC<SlideProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 02 • THE STRATEGIC PIVOT</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Consulting Engagement vs. Internal FTE Hire
        </h2>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          While Praecipio initially considered an internal GTM or Forward Deployed AI Engineer hire, 
          a <strong>6-month consulting activation</strong> delivers dramatically faster execution, guaranteed workflow deliverables, 
          and eliminates enterprise hiring friction.
        </p>
      </div>

      {/* Side-by-Side Comparison Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        
        {/* Left: Traditional FTE Hire */}
        <div className="p-6 sm:p-7 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Traditional Path</span>
                <h3 className="text-xl font-bold text-slate-800">Internal FTE Employee Hire</h3>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-slate-200 text-slate-700 text-xs font-semibold">
                High Friction
              </span>
            </div>

            <ul className="mt-5 space-y-3.5 text-sm text-slate-600">
              <li className="flex items-start gap-3">
                <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <span><strong>60–90 Day Ramp:</strong> Lengthy interviewing, corporate onboarding, and ramp delays before initial output.</span>
              </li>
              <li className="flex items-start gap-3">
                <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <span><strong>Heavy Corporate Burden:</strong> Payroll taxes, health benefits, 401(k), equity vesting, and executive recruiting fees (+25%).</span>
              </li>
              <li className="flex items-start gap-3">
                <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <span><strong>Single-Discipline Constraints:</strong> Internal roles are often pigeonholed into narrow job codes rather than cross-functional GTM systems.</span>
              </li>
              <li className="flex items-start gap-3">
                <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <span><strong>Severance & Long-Term Liability:</strong> Difficult and costly to pivot if internal priorities or budget cycles shift.</span>
              </li>
            </ul>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-100 text-xs text-slate-600 border border-slate-200 font-medium">
            Risk profile: Heavy financial commitment with uncertain time-to-first-workflow.
          </div>
        </div>

        {/* Right: Proposed 6-Month Consulting Retainer */}
        <div className="p-6 sm:p-7 rounded-2xl bg-sky-50/70 border-2 border-sky-300 shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-sky-200">
              <div>
                <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">Recommended Strategy</span>
                <h3 className="text-xl font-bold text-slate-900">6-Month Consulting Activation</h3>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-sky-600 text-white text-xs font-bold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Optimal ROI
              </span>
            </div>

            <ul className="mt-5 space-y-3.5 text-sm text-slate-700">
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <span><strong>Immediate Day 1 Execution:</strong> Kickoff on Oct 5 (Assessment Sept 28). First production pipeline live in weeks.</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <span><strong>Guaranteed Deliverables:</strong> 6 custom production workflows tailored to Praecipio's tech stack + ongoing ad-hoc engineering.</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <span><strong>Zero Corporate Overhead:</strong> 100% fixed consulting fee. Zero taxes, zero benefits, zero recruiting markups.</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <span><strong>Built-in Flexibility:</strong> 3-month performance checkpoint (Q1 2027) with a mutual option to renew or expand.</span>
              </li>
            </ul>
          </div>

          <div className="p-3.5 rounded-xl bg-white text-xs text-sky-900 border border-sky-200 font-semibold flex items-center justify-between">
            <span>Bottom Line: Senior AI architect output at a fraction of full-time cost.</span>
            <ShieldCheck className="w-4 h-4 text-sky-600" />
          </div>
        </div>

      </div>

      {/* Presenter Notes / Key Takeaway */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Key Takeaway for Leadership:</strong> Patrick Diamitani acts as an embedded forward-deployed engineer who delivers tangible software and revenue pipelines, not theoretical slide decks.
          </span>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: The 6 Workflows</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
