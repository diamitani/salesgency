import React, { useState } from 'react';
import { 
  Clock, 
  CreditCard, 
  Cpu, 
  CheckCircle2, 
  ShieldCheck, 
  ArrowRight,
  Layers,
  Sparkles
} from 'lucide-react';

interface SlideProps {
  onNext?: () => void;
}

export const Slide09TheThreeTs: React.FC<SlideProps> = ({ onNext }) => {
  const [activeT, setActiveT] = useState<'timeline' | 'transaction' | 'technology'>('timeline');

  return (
    <div className="flex flex-col justify-between h-full space-y-6">
      {/* Slide Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold mb-3">
          <span>SLIDE 09 • ENGAGEMENT OUTPUT DECISION FRAMEWORK</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            The 3 Ts Decision Framework
          </h2>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-sky-100 text-sky-800">
            Timeline • Transaction • Technology
          </span>
        </div>
        <p className="text-slate-600 mt-2 text-base max-w-3xl leading-relaxed">
          The three foundational pillars collaboratively agreed upon between Patrick Diamitani and Praecipio leadership.
        </p>
      </div>

      {/* 3 Ts Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => setActiveT('timeline')}
          className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            activeT === 'timeline'
              ? 'bg-sky-50/80 border-sky-400 shadow-md ring-2 ring-sky-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">T-01</span>
              <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
                <Clock className="w-5 h-5" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-1">Timeline</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              When to expect delivery & operational cadence
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-sky-800">
            Kickoff Oct 5 • 6-Month Horizon
          </div>
        </button>

        <button
          onClick={() => setActiveT('transaction')}
          className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            activeT === 'transaction'
              ? 'bg-emerald-50/80 border-emerald-400 shadow-md ring-2 ring-emerald-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">T-02</span>
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                <CreditCard className="w-5 h-5" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-1">Transaction</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Commercial terms & predictable monthly retainer
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-emerald-800">
            Net 15 • Zero Overhead Burden
          </div>
        </button>

        <button
          onClick={() => setActiveT('technology')}
          className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            activeT === 'technology'
              ? 'bg-purple-50/80 border-purple-400 shadow-md ring-2 ring-purple-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-purple-700 uppercase tracking-wider">T-03</span>
              <div className="p-2 rounded-lg bg-purple-100 text-purple-700">
                <Cpu className="w-5 h-5" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-1">Technology</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Enterprise LLMs, CRM integrations & Atlassian tools
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-purple-800">
            Claude 3.5 • CRM • Clay • Jira
          </div>
        </button>
      </div>

      {/* Selected Pillar Content Box */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm text-xs">
        {activeT === 'timeline' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-base font-bold text-slate-900">Timeline: Milestones & Weekly Cadence</h4>
              <span className="text-sky-700 font-semibold">6-Month Duration</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-700 leading-relaxed">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Sept 28, 2026:</strong> Initial engagement session & credentials audit.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Oct 5, 2026:</strong> Formal kickoff and staging environment initialization.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Oct 19, 2026:</strong> First production workflow live (Inbound routing shield).</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Weekly Standups:</strong> 30-min engineering review and sprint pacing.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Weekly Office Hours:</strong> Dedicated rep coaching on AI prompt workflows.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Q1 2027:</strong> 3-month audit and option-to-renew decision.</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeT === 'transaction' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-base font-bold text-slate-900">Transaction: Predictable Retainer & Commercial Terms</h4>
              <span className="text-emerald-700 font-semibold">Net 15 Terms</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">Monthly Consulting Retainer</div>
                <p className="text-slate-600">Fixed monthly fee covering all strategy, development, and ongoing maintenance.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">Zero Overhead Costs</div>
                <p className="text-slate-600">No healthcare, 401(k), payroll taxes, or agency recruiting markups.</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">Full IP Ownership</div>
                <p className="text-slate-600">100% of all customized workflows and code transfer permanently to Praecipio.</p>
              </div>
            </div>
          </div>
        )}

        {activeT === 'technology' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-base font-bold text-slate-900">Technology: Enterprise Stack & Orchestration</h4>
              <span className="text-purple-700 font-semibold">State-of-the-Art Tooling</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-slate-700">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="text-slate-900 block text-xs">Foundation LLMs</strong>
                <span className="text-slate-600">Claude 3.5 Sonnet & Gemini</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="text-slate-900 block text-xs">CRM Systems</strong>
                <span className="text-slate-600">HubSpot & Salesforce</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="text-slate-900 block text-xs">Data Enrichment</strong>
                <span className="text-slate-600">Clay, Apollo, Clearbit</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <strong className="text-slate-900 block text-xs">Atlassian Suite</strong>
                <span className="text-slate-600">Jira, JSM, Confluence</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Presenter Notes / Key Takeaway */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span>
            <strong className="text-slate-900">Alignment:</strong> Clear terms, predictable finances, and seamless integration with Praecipio's existing technical stack.
          </span>
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Next: Authorization & Sign-off</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
