import React, { useState } from 'react';
import { SalesGencyLogo } from './SalesGencyLogo';
import { X, CheckCircle, ExternalLink, Sparkles, Layers, ShieldCheck } from 'lucide-react';

interface BrandModalLightProps {
  isOpen: boolean;
  onClose: () => void;
}

const CLIENT_BLUEPRINTS = [
  {
    client: 'AEORIM AI',
    architectureType: 'Autonomous Outbound Prospecting Engine',
    description: 'High-scale prospect intelligence pipeline executing automated persona scraping, account-level research synthesis, and multi-touch PAS outreach.',
    primaryOutcome: '24.2% verified reply rate and 4x outbound pipeline acceleration with 100% rep mailbox deliverability.'
  },
  {
    client: 'VNTNR Logistics',
    architectureType: 'Sub-90-Second Inbound Lead Shield',
    description: 'High-frequency inbound routing workflow unifying webhook submission listeners, AI intent scoring, territory assignment, and instant Slack notifications.',
    primaryOutcome: 'Sub-90-second response latency (down from 4.8 hours) and 35% increase in inbound demo completions.'
  },
  {
    client: 'ARCHIN Robotics',
    architectureType: 'Enterprise GTM Command Center',
    description: 'Executive revenue telemetry system connecting CRM pipeline data, conversion velocity, and real-time rep activity into a single-pane dashboard.',
    primaryOutcome: '100% pipeline visibility, daily anomaly detection, and automated leadership forecasting.'
  }
];

export const BrandModalLight: React.FC<BrandModalLightProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'blueprints' | 'identity'>('blueprints');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in no-print">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <SalesGencyLogo size="sm" variant="gradient" />
            <div className="h-4 w-px bg-slate-200" />
            <div>
              <h3 className="text-base font-bold text-slate-900">Proven Architecture & Client Pedigree</h3>
              <p className="text-xs text-slate-500">Live reference blueprints deployed by Patrick Diamitani</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex rounded-lg bg-slate-100 p-0.5 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('blueprints')}
                className={`px-3 py-1.5 rounded-md cursor-pointer transition-all ${
                  activeTab === 'blueprints' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Client Blueprints
              </button>
              <button
                onClick={() => setActiveTab('identity')}
                className={`px-3 py-1.5 rounded-md cursor-pointer transition-all ${
                  activeTab === 'identity' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Brand Guidelines
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {activeTab === 'blueprints' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Praecipio's 6 custom workflows are adapted from battle-tested production blueprints delivered across enterprise AI clients:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {CLIENT_BLUEPRINTS.map((bp) => (
                  <div key={bp.client} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-bold text-sky-700 uppercase tracking-wider">{bp.architectureType}</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">Verified</span>
                      </div>
                      <h4 className="text-base font-bold text-slate-900 mb-1">{bp.client}</h4>
                      <p className="text-xs text-slate-600 mb-3">{bp.description}</p>
                    </div>

                    <div className="pt-3 border-t border-slate-200/80">
                      <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">Key Outcome:</div>
                      <div className="text-xs text-slate-800 font-medium">{bp.primaryOutcome}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'identity' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200">
                <h4 className="text-sm font-bold text-slate-900 mb-2">Typography & Color Specs</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Primary Blue</span>
                    <strong className="text-slate-800 font-mono">#0284C7</strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Deep Slate</span>
                    <strong className="text-slate-800 font-mono">#0F172A</strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Success Emerald</span>
                    <strong className="text-slate-800 font-mono">#059669</strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Display Font</span>
                    <strong className="text-slate-800">Plus Jakarta Sans</strong>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Diamitani Industries x SalesGency</h4>
                  <p className="text-xs text-slate-500">Autonomous GTM & AI Architecture practice led by Patrick Diamitani</p>
                </div>
                <SalesGencyLogo size="md" variant="gradient" />
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Diamitani Industries Activation Plan • Praecipio Consulting</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold cursor-pointer"
          >
            Close Overview
          </button>
        </div>

      </div>
    </div>
  );
};
