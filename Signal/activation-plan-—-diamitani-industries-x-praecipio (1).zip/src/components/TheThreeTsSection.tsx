import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  Clock, 
  CreditCard, 
  Cpu, 
  Check, 
  ShieldCheck, 
  DollarSign, 
  Layers,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export const TheThreeTsSection: React.FC = () => {
  const [activeT, setActiveT] = useState<'timeline' | 'transaction' | 'technology'>('timeline');

  return (
    <section id="three-ts" className="py-14 border-b border-slate-800 bg-slate-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono mb-3">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            SECTION 06 • ENGAGEMENT OUTPUT DECISION FRAMEWORK
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            The 3 Ts Decision Framework
          </h2>
          <p className="mt-2 text-slate-300 text-sm sm:text-base leading-relaxed">
            Patrick Diamitani and Praecipio leadership collaboratively finalize the three foundational parameters 
            governing the engagement output.
          </p>
        </div>

        {/* 3 Ts Navigation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <button
            onClick={() => setActiveT('timeline')}
            className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeT === 'timeline'
                ? 'bg-slate-900 border-cyan-500/50 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/30'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase">T-01</span>
                <div className={`p-2 rounded-lg ${activeT === 'timeline' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-800 text-slate-400'}`}>
                  <Clock className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Timeline</h3>
              <p className="text-xs text-slate-400">When to expect delivery & cadence</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] font-mono text-cyan-300">
              Sept 28 • Oct 5 Kickoff • Q1 2027 Checkup
            </div>
          </button>

          <button
            onClick={() => setActiveT('transaction')}
            className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeT === 'transaction'
                ? 'bg-slate-900 border-emerald-500/50 shadow-xl shadow-emerald-500/10 ring-1 ring-emerald-500/30'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-emerald-400 font-bold uppercase">T-02</span>
                <div className={`p-2 rounded-lg ${activeT === 'transaction' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                  <CreditCard className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Transaction</h3>
              <p className="text-xs text-slate-400">When payment will be made & commercial terms</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] font-mono text-emerald-300">
              Predictable Retainer • Net 15 • Renewal Terms
            </div>
          </button>

          <button
            onClick={() => setActiveT('technology')}
            className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeT === 'technology'
                ? 'bg-slate-900 border-purple-500/50 shadow-xl shadow-purple-500/10 ring-1 ring-purple-500/30'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-purple-400 font-bold uppercase">T-03</span>
                <div className={`p-2 rounded-lg ${activeT === 'technology' ? 'bg-purple-500/20 text-purple-400' : 'bg-slate-800 text-slate-400'}`}>
                  <Cpu className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Technology</h3>
              <p className="text-xs text-slate-400">What systems, LLMs & tools will be used</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] font-mono text-purple-300">
              Claude 3.5 • CRM • Clay • Smartlead • Jira
            </div>
          </button>
        </div>

        {/* Deep-Dive on Active T */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
          
          {/* T1: Timeline */}
          {activeT === 'timeline' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-mono text-cyan-400 font-bold uppercase">Pillar 1 of 3</span>
                  <h3 className="text-2xl font-black text-white">Timeline: Delivery Commitments & Cadence</h3>
                </div>
                <span className="text-xs font-mono px-3 py-1 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30 self-start sm:self-auto">
                  6-Month Total Horizon
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300 leading-relaxed">
                <div className="space-y-3">
                  <h4 className="font-mono text-slate-400 uppercase font-bold text-[11px]">
                    Key Sprint Milestones
                  </h4>
                  <div className="space-y-2">
                    <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                      <strong className="text-white block mb-0.5">Initial Engagement: Sept 28, 2026</strong>
                      Assessment session, tool audits, and secure keysheet/credential handoff.
                    </div>
                    <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                      <strong className="text-white block mb-0.5">Formal Kickoff: Oct 5, 2026</strong>
                      Roadmap and SOW finalization, staging environment initialization.
                    </div>
                    <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                      <strong className="text-white block mb-0.5">First Workflow Live: Oct 19, 2026</strong>
                      Inbound Lead-to-CRM Routing & Deliverability Shield operational.
                    </div>
                    <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                      <strong className="text-white block mb-0.5">Full 6 Workflows Production: Nov 30, 2026</strong>
                      All core automations active, daily health reports executing, GTM dashboard live.
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-mono text-slate-400 uppercase font-bold text-[11px]">
                    Ongoing Operational Cadence
                  </h4>
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span><strong>Weekly Engineering Standups:</strong> 30-minute sync on weekly sprint targets and pipeline metrics.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span><strong>Weekly Office Hours & Team Training:</strong> Hands-on coaching for Praecipio reps on AI prompts & workflow skills.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span><strong>Unlimited Communication:</strong> Dedicated Slack channel, direct text, email, and phone availability for urgent issues.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span><strong>3-Month Check Up (Q1'2027):</strong> Executive milestone review, ROI verification, and option-to-renew decision.</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* T2: Transaction */}
          {activeT === 'transaction' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-mono text-emerald-400 font-bold uppercase">Pillar 2 of 3</span>
                  <h3 className="text-2xl font-black text-white">Transaction: Commercial Terms & Payment Schedule</h3>
                </div>
                <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 self-start sm:self-auto">
                  Predictable Retainer Structure
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="text-xs font-mono text-slate-400">Payment Structure</div>
                  <div className="text-lg font-bold text-white">Monthly Consulting Retainer</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Structured as a fixed monthly consulting fee covering strategy, forward-deployed engineering, and ongoing support.
                  </p>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="text-xs font-mono text-slate-400">Billing Terms</div>
                  <div className="text-lg font-bold text-white">Net 15 / Monthly Invoicing</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Invoiced on the 1st of each month. Initial invoice due upon kickoff (Oct 5, 2026).
                  </p>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="text-xs font-mono text-slate-400">Option to Renew</div>
                  <div className="text-lg font-bold text-white">6-Month Extension Clause</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Mutual option to renew at identical or expanded terms during the Q1 2027 3-Month Check Up.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20 text-xs text-slate-300 leading-relaxed">
                <strong className="text-emerald-300 block mb-1">Corporate Overhead Protection:</strong>
                Zero healthcare costs, zero payroll taxes, zero 401(k) matching, zero agency recruiting markup, and zero severance liability. 
                Full IP rights of all customized workflows transferred directly to Praecipio Consulting.
              </div>
            </div>
          )}

          {/* T3: Technology */}
          {activeT === 'technology' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-mono text-purple-400 font-bold uppercase">Pillar 3 of 3</span>
                  <h3 className="text-2xl font-black text-white">Technology: Enterprise Stack & Orchestration</h3>
                </div>
                <span className="text-xs font-mono px-3 py-1 rounded-full bg-purple-950 text-purple-300 border border-purple-500/30 self-start sm:self-auto">
                  AI-Native Architecture
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-purple-400 font-mono text-[10px] uppercase font-bold">Foundation AI</span>
                  <div className="font-bold text-white text-sm">Anthropic Claude 3.5 & Gemini</div>
                  <p className="text-slate-400 text-[11px]">
                    State-of-the-art coding, research reasoning, and transcript synthesis.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-cyan-400 font-mono text-[10px] uppercase font-bold">CRM & Storage</span>
                  <div className="font-bold text-white text-sm">HubSpot & Salesforce</div>
                  <p className="text-slate-400 text-[11px]">
                    Seamless bi-directional synchronization with Praecipio's source of truth.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-emerald-400 font-mono text-[10px] uppercase font-bold">Data & Scraping</span>
                  <div className="font-bold text-white text-sm">Clay, Apollo & Clearbit</div>
                  <p className="text-slate-400 text-[11px]">
                    Waterfalled waterfall enrichment for 99%+ valid verified email & phone data.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-amber-400 font-mono text-[10px] uppercase font-bold">Email & Outbound</span>
                  <div className="font-bold text-white text-sm">Smartlead / Instantly</div>
                  <p className="text-slate-400 text-[11px]">
                    Multi-domain inbox rotation and automated warmup to protect primary domains.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
                <span className="font-mono text-slate-400 uppercase text-[10px] font-bold block mb-1">
                  Atlassian Ecosystem Co-Existence:
                </span>
                <p>
                  All automations will interface seamlessly with Jira Software, Jira Service Management, and Confluence 
                  via REST APIs and webhooks, ensuring Praecipio’s consulting delivery teams experience zero tool friction.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
