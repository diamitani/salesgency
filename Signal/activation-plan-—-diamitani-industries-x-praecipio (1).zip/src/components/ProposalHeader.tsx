import React from 'react';
import { SalesGencyLogo } from './SalesGencyLogo';
import { PROPOSAL_METADATA } from '../data/proposalData';
import { 
  Calendar, 
  Clock, 
  UserCheck, 
  Printer, 
  ShieldCheck, 
  Sparkles,
  Layers,
  SlidersHorizontal
} from 'lucide-react';

interface ProposalHeaderProps {
  onOpenSimulators: () => void;
  onOpenBrandModal: () => void;
  onScrollToSignoff: () => void;
  onPrint: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const ProposalHeader: React.FC<ProposalHeaderProps> = ({
  onOpenSimulators,
  onOpenBrandModal,
  onScrollToSignoff,
  onPrint,
  activeSection,
  onNavigate
}) => {
  return (
    <header className="relative border-b border-slate-800/80 bg-[#080B11]/90 backdrop-blur-md sticky top-0 z-40 transition-all">
      {/* Top Banner with partnership indicator */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between text-xs border-b border-slate-800/40">
        <div className="flex items-center gap-2 text-slate-400">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[11px] border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            CONFIDENTIAL CLIENT PROPOSAL
          </span>
          <span className="hidden sm:inline text-slate-600">•</span>
          <span className="hidden sm:inline text-slate-400">
            Prepared exclusively for <strong className="text-slate-200">Praecipio Consulting</strong>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenBrandModal}
            className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 transition-colors font-medium cursor-pointer"
            title="View SalesGency Brand Assets & Reference Blueprints"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Brand Guidelines & Blueprints</span>
          </button>
          <span className="text-slate-700">|</span>
          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Export / Print Proposal"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Brand & Document Identifiers */}
          <div className="flex items-start sm:items-center gap-4">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 shadow-inner flex items-center justify-center">
              <SalesGencyLogo size="md" variant="gradient" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-mono tracking-wider uppercase text-cyan-400 font-semibold">
                  Diamitani Industries
                </span>
                <span className="text-slate-600 font-mono text-xs">×</span>
                <span className="text-[11px] font-mono tracking-wider uppercase text-slate-300 font-semibold">
                  Praecipio Consulting
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                Activation Plan
                <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                  6-Month Consulting Engagement
                </span>
              </h1>
            </div>
          </div>

          {/* Quick Details & Author Metadata */}
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-300">
              <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
              <div>
                <span className="text-slate-500 text-[10px] block leading-none">Written by</span>
                <span className="font-semibold text-slate-200">{PROPOSAL_METADATA.author}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <div>
                <span className="text-slate-500 text-[10px] block leading-none">Proposal Date</span>
                <span className="font-semibold text-slate-200">{PROPOSAL_METADATA.proposalDate}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/30 border border-cyan-500/30 text-cyan-300">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <div>
                <span className="text-cyan-500/80 text-[10px] block leading-none">Proposed Kickoff</span>
                <span className="font-semibold text-cyan-200">{PROPOSAL_METADATA.kickoffDate}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onOpenSimulators}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                Live Workflow Simulator
              </button>

              <button
                onClick={onScrollToSignoff}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-xs border border-slate-700 transition-colors cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Review & Sign
              </button>
            </div>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <nav className="mt-4 pt-3 border-t border-slate-800/60 flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar text-xs font-medium">
          {[
            { id: 'overview', label: 'Executive Overview' },
            { id: 'core-workflows', label: '6 Core Workflows' },
            { id: 'simulation', label: 'Interactive Architecture' },
            { id: 'optional-projects', label: 'Optional AI Projects' },
            { id: 'roadmap', label: 'Roadmap & SOWs' },
            { id: 'three-ts', label: 'The 3 Ts (Timeline, Transaction, Tech)' },
            { id: 'signoff', label: 'Acceptance & Sign-off' },
          ].map((tab) => {
            const isActive = activeSection === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onNavigate(tab.id)}
                className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 font-semibold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
