import React, { useState } from 'react';
import { CORE_WORKFLOWS } from '../data/proposalData';
import { WorkflowItem } from '../types';
import { 
  Bot, 
  Send, 
  UserCheck, 
  FileText, 
  BarChart3, 
  Activity, 
  Check, 
  Sparkles, 
  ArrowRight,
  ShieldAlert,
  ExternalLink,
  Layers,
  CheckCircle,
  Clock,
  Database
} from 'lucide-react';

interface CoreWorkflowsSectionProps {
  onOpenSimulatorForWorkflow: (id: string) => void;
  onOpenBrandModal: () => void;
}

export const CoreWorkflowsSection: React.FC<CoreWorkflowsSectionProps> = ({
  onOpenSimulatorForWorkflow,
  onOpenBrandModal
}) => {
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>(CORE_WORKFLOWS[0].id);

  const activeWorkflow = CORE_WORKFLOWS.find((w) => w.id === selectedWorkflowId) || CORE_WORKFLOWS[0];

  const getWorkflowIcon = (id: string) => {
    switch (id) {
      case 'prospect-automation':
        return <Send className="w-5 h-5 text-cyan-400" />;
      case 'inbound-automation':
        return <Bot className="w-5 h-5 text-emerald-400" />;
      case 'pre-call-workflow':
        return <UserCheck className="w-5 h-5 text-purple-400" />;
      case 'post-call-workflow':
        return <FileText className="w-5 h-5 text-blue-400" />;
      case 'daily-execution-report':
        return <Activity className="w-5 h-5 text-amber-400" />;
      case 'gtm-dashboard':
        return <BarChart3 className="w-5 h-5 text-pink-400" />;
      default:
        return <Layers className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="core-workflows" className="py-14 border-b border-slate-800 bg-slate-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono mb-3">
              <Layers className="w-3.5 h-3.5" />
              SECTION 02 • CORE ACTIVATION DELIVERABLES
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              The 6 Core GTM Automations
            </h2>
            <p className="mt-2 text-slate-300 max-w-2xl text-sm sm:text-base">
              Custom-engineered workflows designed to turn Praecipio’s go-to-market engine into an autonomous, 
              high-converting revenue machine.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenBrandModal}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              View Client Reference Blueprints
            </button>
          </div>
        </div>

        {/* Workflow Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-8">
          {CORE_WORKFLOWS.map((workflow) => {
            const isSelected = workflow.id === selectedWorkflowId;
            return (
              <button
                key={workflow.id}
                onClick={() => setSelectedWorkflowId(workflow.id)}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500/30'
                    : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-slate-500">
                    {workflow.number}
                  </span>
                  <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-cyan-500/20' : 'bg-slate-800'}`}>
                    {getWorkflowIcon(workflow.id)}
                  </div>
                </div>
                <div className={`text-xs font-bold line-clamp-2 ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {workflow.title.replace('Customized ', '')}
                </div>
                <div className="mt-2 text-[10px] font-mono text-cyan-400 uppercase tracking-wider">
                  {workflow.category}
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Workflow Deep-Dive Card */}
        <div className="relative rounded-2xl bg-gradient-to-b from-slate-900 to-[#0B0F19] border border-slate-800 p-6 sm:p-8 shadow-2xl overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: Description & Architecture */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 font-mono text-xs font-bold border border-cyan-500/30">
                    WORKFLOW {activeWorkflow.number}
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-xs font-mono text-purple-400 uppercase font-semibold">
                    Category: {activeWorkflow.category}
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-xs text-slate-400">
                    Proven Architecture: <strong className="text-slate-200">{activeWorkflow.blueprintReference}</strong>
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {activeWorkflow.title}
                </h3>
                <p className="mt-1 text-sm text-cyan-400/90 font-medium">
                  {activeWorkflow.subtitle}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 text-sm text-slate-200 leading-relaxed">
                <p className="font-medium text-slate-100 mb-2">
                  {activeWorkflow.summary}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {activeWorkflow.fullDescription}
                </p>
              </div>

              {/* Concrete Deliverables */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  Engineering Deliverables & Output
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeWorkflow.deliverables.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/60 text-xs text-slate-300"
                    >
                      <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tech Stack Integration Chips */}
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold mb-2.5 flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-400" />
                  Target Stack Integrations
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeWorkflow.stackIntegration.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Business Impact & Interactive Simulation Launcher */}
            <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-6">
              {/* Target Performance Scorecard */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-slate-950 to-cyan-950/30 border border-cyan-500/20 shadow-lg">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-cyan-400 font-semibold uppercase">
                    Target Performance Benchmark
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <div className="text-lg font-black text-white tracking-tight">
                  {activeWorkflow.metricsTarget}
                </div>
                <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                  {activeWorkflow.businessImpact}
                </p>
              </div>

              {/* Blueprint Preview Box */}
              <div className="p-5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-mono text-slate-400 uppercase font-semibold">
                    Reference Architecture
                  </div>
                  <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono">
                    {activeWorkflow.blueprintReference}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Built leveraging battle-tested patterns from Diamitani Industries & SalesGency enterprise deployments.
                </p>

                <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => onOpenSimulatorForWorkflow(activeWorkflow.id)}
                    className="flex-1 py-2.5 px-4 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                    Launch Interactive Test Drive
                  </button>

                  <button
                    onClick={onOpenBrandModal}
                    className="py-2.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    title="View Original Architecture Diagram"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Diagram
                  </button>
                </div>
              </div>

              {/* Ad-Hoc Engineering Commitment */}
              <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/20 text-xs text-purple-200 leading-relaxed">
                <div className="font-semibold text-purple-300 flex items-center gap-1.5 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  Continuous Ad-Hoc Construction Guarantee
                </div>
                <p className="text-purple-300/80">
                  "Additionally, Patrick accepts to construct and improve specific ad-hoc workflows, skills, and agents as needed throughout the 6-month engagement."
                </p>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
