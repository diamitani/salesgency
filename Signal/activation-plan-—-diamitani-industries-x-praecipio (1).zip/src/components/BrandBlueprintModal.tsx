import React, { useState } from 'react';
import { SalesGencyLogo } from './SalesGencyLogo';
import { 
  X, 
  Layers, 
  Sparkles, 
  ExternalLink, 
  Check, 
  ShieldCheck, 
  Palette, 
  Activity, 
  Send, 
  BarChart3 
} from 'lucide-react';

interface BrandBlueprintModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BrandBlueprintModal: React.FC<BrandBlueprintModalProps> = ({
  isOpen,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'brand' | 'vntnr' | 'archin' | 'aeorim'>('brand');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#090D16] border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                SalesGency Brand Guidelines & Client Blueprints
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Official Diamitani Industries / SalesGency visual identity and reference systems
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 border-b border-slate-800/80 bg-slate-950/40 text-xs font-medium overflow-x-auto">
          {[
            { id: 'brand', label: 'SalesGency Brand Identity & Wordmarks', icon: Palette },
            { id: 'vntnr', label: 'Blueprint 1: VNTNR CRM Shield (Inbound Routing)', icon: Activity },
            { id: 'archin', label: 'Blueprint 2: ARCHIN Robotics (GTM Dashboard)', icon: BarChart3 },
            { id: 'aeorim', label: 'Blueprint 3: AEORIM AI (Prospect & Email Engine)', icon: Send },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5 text-cyan-400" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-200 text-xs">
          
          {/* TAB 1: Brand Guidelines */}
          {activeTab === 'brand' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-base font-bold text-white mb-1">
                  The SalesGency. Wordmark Specifications
                </h4>
                <p className="text-slate-400">
                  Constructed with bold geometric sans typography and the signature electric cyan dot (<code className="text-cyan-400 font-mono">#00F0FF</code>) with subtle cyan glow.
                </p>
              </div>

              {/* 3 Wordmark Previews */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Variant 1: Gradient with Carbon Weave */}
                <div className="p-6 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center text-center space-y-4 shadow-inner">
                  <div className="w-full py-8 px-4 rounded-lg bg-[#06080D] border border-slate-800/80 flex items-center justify-center">
                    <SalesGencyLogo size="lg" variant="gradient" withGlow={true} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Signature Gradient Wordmark</span>
                    <span className="text-[11px] text-slate-500 font-mono">Primary brand lockup for dark tech backgrounds</span>
                  </div>
                </div>

                {/* Variant 2: Dark Mode Solid */}
                <div className="p-6 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center text-center space-y-4 shadow-inner">
                  <div className="w-full py-8 px-4 rounded-lg bg-[#000000] border border-slate-800/80 flex items-center justify-center">
                    <SalesGencyLogo size="lg" variant="dark" withGlow={true} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Solid Dark Wordmark</span>
                    <span className="text-[11px] text-slate-500 font-mono">Pure white wordmark + glowing cyan dot</span>
                  </div>
                </div>

                {/* Variant 3: Light Mode */}
                <div className="p-6 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center text-center space-y-4 shadow-inner">
                  <div className="w-full py-8 px-4 rounded-lg bg-[#F8FAFC] border border-slate-200 flex items-center justify-center">
                    <SalesGencyLogo size="lg" variant="light" withGlow={false} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Solid Light Wordmark</span>
                    <span className="text-[11px] text-slate-500 font-mono">High-contrast slate typography for print & light decks</span>
                  </div>
                </div>

              </div>

              {/* Color Palette Specifications */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <h5 className="font-mono text-slate-400 uppercase font-bold text-[11px]">
                  Core Brand Color Palette
                </h5>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-[11px]">
                  <div className="p-2.5 rounded bg-[#080B11] border border-slate-800 flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-[#080B11] border border-slate-700" />
                    <div><strong className="text-white block">Carbon Navy</strong>#080B11</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-[#00F0FF]" />
                    <div><strong className="text-cyan-400 block">Electric Cyan</strong>#00F0FF</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-[#6366F1]" />
                    <div><strong className="text-indigo-400 block">Cobalt Indigo</strong>#6366F1</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-[#A855F7]" />
                    <div><strong className="text-purple-400 block">Deep Purple</strong>#A855F7</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: VNTNR Blueprint */}
          {activeTab === 'vntnr' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-emerald-400 font-mono text-xs font-bold uppercase">
                    Client Blueprint Reference: VNTNR Global Logistics
                  </span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono text-[10px]">
                    CRM Shield & Global Lead Routing
                  </span>
                </div>
                <h4 className="text-lg font-bold text-white">
                  Automated Lead-to-CRM Routing with 99/100 Deliverability
                </h4>
                <p className="text-slate-300 mt-1">
                  Engineered by SalesGency. Ingests forms, LinkedIn Ads, and email campaigns → automatic data enrichment → qualifying & routing → dynamic lead scoring → dual sync with HubSpot & Salesforce.
                </p>
              </div>

              {/* Workflow Architecture Diagram Breakdown */}
              <div className="p-5 rounded-xl bg-[#060A12] border border-slate-800 space-y-4">
                <div className="text-xs font-mono text-slate-400 uppercase font-bold">
                  Architecture Flow Implemented in Praecipio Workflow #02
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-cyan-400 font-mono font-bold block mb-1">Step 1: Ingest</span>
                    <span className="text-[11px] text-slate-300">Website Forms, LinkedIn Ads & Webhooks</span>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-purple-400 font-mono font-bold block mb-1">Step 2: Enrich</span>
                    <span className="text-[11px] text-slate-300">Clearbit & ZoomInfo Database Lookup</span>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-blue-400 font-mono font-bold block mb-1">Step 3: Qualify</span>
                    <span className="text-[11px] text-slate-300">AI Scoring & Territory Routing</span>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-emerald-400 font-mono font-bold block mb-1">Step 4: Sync</span>
                    <span className="text-[11px] text-slate-300">HubSpot + Salesforce Verified Connected</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono">
                  <span className="text-slate-400">Deliverability Sender Score: <strong className="text-emerald-400">99/100</strong></span>
                  <span className="text-slate-400">Domain Burn Rate: <strong className="text-cyan-400">0%</strong></span>
                  <span className="text-slate-400">Average Open Rate: <strong className="text-purple-400">42%</strong></span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ARCHIN Blueprint */}
          {activeTab === 'archin' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-cyan-400 font-mono text-xs font-bold uppercase">
                    Client Blueprint Reference: ARCHIN Robotics
                  </span>
                  <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono text-[10px]">
                    Outbound Revenue Intelligence
                  </span>
                </div>
                <h4 className="text-lg font-bold text-white">
                  Executive GTM Command Center with Live Funnel & Attribution
                </h4>
                <p className="text-slate-300 mt-1">
                  Engineered by SalesGency. Consolidates ARR ($4.2M), pipeline value ($18.5M), leads generated (4,150), 
                  and 18.3% conversion velocity into an interactive curved display command center.
                </p>
              </div>

              {/* Architecture Breakdown */}
              <div className="p-5 rounded-xl bg-[#060A12] border border-slate-800 space-y-4">
                <div className="text-xs font-mono text-slate-400 uppercase font-bold">
                  Command Center Modules Implemented in Praecipio Workflow #06
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-white mb-1">Pipeline & Forecast</div>
                    <p className="text-[11px] text-slate-400">Prospecting, Qualification, Demo, Proposal, Closed Won.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-white mb-1">Lead Gen Velocity</div>
                    <p className="text-[11px] text-slate-400">Comparative pacing across Inbound, SDR Outreach, and Events.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-white mb-1">Revenue Attribution</div>
                    <p className="text-[11px] text-slate-400">Multi-touch attribution matrix mapping campaigns to closed revenue.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AEORIM Blueprint */}
          {activeTab === 'aeorim' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-purple-500/30">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-purple-400 font-mono text-xs font-bold uppercase">
                    Client Blueprint Reference: AEORIM AI
                  </span>
                  <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 font-mono text-[10px]">
                    Cold Email Outreach & Sequence Automation
                  </span>
                </div>
                <h4 className="text-lg font-bold text-white">
                  24.2% Reply Rate with PAS Pain Point Personalization
                </h4>
                <p className="text-slate-300 mt-1">
                  Engineered by SalesGency. Automated 14,832 outbound dispatches with 68.5% open rate and 118 enterprise meetings booked using multi-stage PAS pain point sequencing.
                </p>
              </div>

              {/* Sequence Structure */}
              <div className="p-5 rounded-xl bg-[#060A12] border border-slate-800 space-y-3">
                <div className="text-xs font-mono text-slate-400 uppercase font-bold">
                  5-Stage Cadence Architecture Implemented in Praecipio Workflow #01
                </div>

                <div className="space-y-2">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span><strong>Stage 1:</strong> Initial Outreach (98% Sent)</span>
                    <span className="text-cyan-400 font-mono">PAS Pain Point Hook</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span><strong>Stage 2:</strong> Follow-Up 1 (42% Opened | 12% Replied)</span>
                    <span className="text-purple-400 font-mono">Case Study Social Proof</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span><strong>Stage 3:</strong> Follow-Up 2 (6% Replied)</span>
                    <span className="text-emerald-400 font-mono">Technical ROI Calculation</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span><strong>Stage 4 & 5:</strong> Nurture & Final Touch</span>
                    <span className="text-slate-400 font-mono">Graceful Exit with Asset Link</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            All systems licensed and deployed under <strong className="text-slate-200">Diamitani Industries</strong>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            Close Blueprint Viewer
          </button>
        </div>

      </div>
    </div>
  );
};
