import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Bot, 
  UserCheck, 
  FileText, 
  Activity, 
  BarChart3, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Copy, 
  Check, 
  TrendingUp, 
  Clock, 
  Sliders, 
  Zap,
  ArrowRight
} from 'lucide-react';

export const InteractiveSimulators: React.FC<{ initialTab?: string }> = ({ initialTab = 'prospect' }) => {
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [copied, setCopied] = useState<boolean>(false);

  // Simulator 1: Prospect Automation State
  const [prospectIndustry, setProspectIndustry] = useState('Atlassian Enterprise Migration');
  const [prospectRole, setProspectRole] = useState('VP of Engineering / Head of DevOps');
  const [prospectTrigger, setProspectTrigger] = useState('Cloud Jira/Confluence Modernization Announced');
  const [repStyle, setRepStyle] = useState('Consultative & Technical');
  const [isGeneratingProspect, setIsGeneratingProspect] = useState(false);

  // Simulator 2: Inbound Routing State
  const [inboundLeadType, setInboundLeadType] = useState<'enterprise' | 'midmarket' | 'spam'>('enterprise');
  const [routingSimulated, setRoutingSimulated] = useState(true);

  // Simulator 3: GTM Dashboard ROI Calculator
  const [salesTeamSize, setSalesTeamSize] = useState(8);
  const [averageDealSize, setAverageDealSize] = useState(65000); // $65k Praecipio enterprise engagement
  const [currentConversion, setCurrentConversion] = useState(12);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Dynamic calculations for GTM ROI
  const hoursSavedPerRepWeekly = 14.5;
  const totalHoursSavedMonthly = Math.round(salesTeamSize * hoursSavedPerRepWeekly * 4.2);
  const incrementalPipeline = Math.round(salesTeamSize * averageDealSize * 2.8);
  const estimatedARRBoost = Math.round(incrementalPipeline * (currentConversion / 100));

  return (
    <section id="simulation" className="py-14 border-b border-slate-800 bg-[#070A10]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            SECTION 03 • INTERACTIVE WORKFLOW TEST-DRIVE
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Experience The Architecture in Action
          </h2>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Test-drive live simulations of the customized automations proposed for Praecipio Consulting. 
            Adjust inputs below to see how our AI systems research, route, synthesize, and report.
          </p>
        </div>

        {/* Simulator Navigation Tabs */}
        <div className="flex items-center justify-center gap-2 mb-8 overflow-x-auto pb-2">
          {[
            { id: 'prospect', label: '01. Prospect Automation & PAS Email', icon: Send },
            { id: 'inbound', label: '02. Inbound Lead Routing (<90s)', icon: Bot },
            { id: 'precall', label: '03. Pre-Call Dossier & Post-Call Action', icon: UserCheck },
            { id: 'health', label: '04. Daily Health & Error Telemetry', icon: Activity },
            { id: 'roi', label: '05. GTM ROI & Capacity Calculator', icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isCurrent = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isCurrent ? 'text-slate-950' : 'text-cyan-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* SIMULATOR 1: Prospect Automation */}
        {activeTab === 'prospect' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl">
            {/* Input Controls */}
            <div className="lg:col-span-5 space-y-4 border-b lg:border-b-0 lg:border-r border-slate-800 lg:pr-6">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Send className="w-4 h-4 text-cyan-400" />
                  ICP Configuration & Signals
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  AEORIM AI Engine
                </span>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1.5">Target ICP Vertical</label>
                <select
                  value={prospectIndustry}
                  onChange={(e) => setProspectIndustry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="Atlassian Enterprise Migration">Atlassian Server to Cloud Migration (Enterprise)</option>
                  <option value="FinTech Scale-Up">High-Growth FinTech (DevOps & Compliance)</option>
                  <option value="Healthcare Systems">HealthTech & Life Sciences (ITSM & Security)</option>
                  <option value="Retail Omni-Channel">Global Retail (Agile Portfolio Transformation)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1.5">Decision Maker Persona</label>
                <select
                  value={prospectRole}
                  onChange={(e) => setProspectRole(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="VP of Engineering / Head of DevOps">VP of Engineering / Head of DevOps</option>
                  <option value="Chief Technology Officer (CTO)">Chief Technology Officer (CTO)</option>
                  <option value="Director of IT Service Management">Director of IT Service Management (ITSM)</option>
                  <option value="Head of Agile Program Management">Head of Agile Program Management</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1.5">Trigger Event / Buying Intent Signal</label>
                <select
                  value={prospectTrigger}
                  onChange={(e) => setProspectTrigger(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="Cloud Jira/Confluence Modernization Announced">Atlassian Server EOS Compliance Deadline Approaching</option>
                  <option value="Rapid Hiring of 40+ Software Engineers">Rapid Technical Hiring (40+ Engineers added in 90 days)</option>
                  <option value="New VP of Technology Hired">New VP of Technology Appointed (First 90-day mandate)</option>
                  <option value="Recent Tech Stack Outage or Security Audit">Enterprise Security Audit & ITSM Optimization Mandate</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1.5">Sales Rep Voice Tone</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Consultative & Technical', 'Concise Executive', 'Peer-to-Peer Solutions', 'Metrics-Driven'].map((style) => (
                    <button
                      key={style}
                      onClick={() => setRepStyle(style)}
                      className={`px-3 py-1.5 rounded text-[11px] font-medium transition-colors cursor-pointer text-left ${
                        repStyle === style
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'bg-slate-950 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-2">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Enrichment Depth:</span>
                  <span className="font-mono text-emerald-400">14 Verified Data Points</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>Deliverability Check:</span>
                  <span className="font-mono text-cyan-400">99.2% Deliverable (Zero-Burn)</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>Predicted Reply Rate:</span>
                  <span className="font-mono text-emerald-400 font-bold">24.2%</span>
                </div>
              </div>
            </div>

            {/* Generated Output Preview */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-mono text-slate-300 uppercase">
                    Autonomous Dispatch Preview • Variant A (PAS Framework)
                  </span>
                </div>
                <button
                  onClick={() => handleCopy("Subject: Question regarding your Atlassian Cloud migration timeline\n\nHi Sarah,\n\nNoticed your team is scaling engineering headcount while preparing for the Jira Cloud transition. Most DevOps leaders we talk to struggle with data integrity and workflow downtime during complex Atlassian cutovers.\n\nPraecipio has orchestrated 300+ enterprise cloud migrations with 0% data loss and zero production downtime.\n\nWould you be open to a 10-minute briefing on how we de-risk the transition?")}
                  className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 hover:text-cyan-300 cursor-pointer"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? 'Copied' : 'Copy Output'}
                </button>
              </div>

              {/* Research Dossier Card */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5">
                <div className="text-[11px] font-mono uppercase text-cyan-400 font-bold">
                  Extracted Account Intelligence
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div><span className="text-slate-500">Account:</span> <span className="text-slate-200">Apex Global (1,850 emp)</span></div>
                  <div><span className="text-slate-500">Contact:</span> <span className="text-slate-200">Sarah Jenkins ({prospectRole})</span></div>
                  <div><span className="text-slate-500">Current Stack:</span> <span className="text-slate-200">Jira Server, GitHub, AWS</span></div>
                  <div><span className="text-slate-500">Trigger:</span> <span className="text-emerald-400">{prospectTrigger.slice(0, 20)}...</span></div>
                </div>
              </div>

              {/* Email Draft Box */}
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3 font-sans">
                <div className="border-b border-slate-800/80 pb-2.5 text-xs text-slate-400 space-y-1">
                  <div><span className="text-slate-500 font-mono">From:</span> Praecipio Enterprise GTM &lt;consulting@praecipio.com&gt;</div>
                  <div><span className="text-slate-500 font-mono">To:</span> s.jenkins@apexglobal.io</div>
                  <div>
                    <span className="text-slate-500 font-mono">Subject:</span>{' '}
                    <strong className="text-white">
                      Question regarding Apex's {prospectIndustry.includes('Atlassian') ? 'Jira Cloud migration' : 'DevOps acceleration'}
                    </strong>
                  </div>
                </div>

                <div className="text-xs text-slate-200 space-y-3 leading-relaxed">
                  <p>Hi Sarah,</p>
                  <p>
                    Noticed Apex Global recently crossed 1,800 team members while navigating the upcoming {prospectTrigger.toLowerCase()}.
                  </p>
                  <p>
                    Many technology leaders in your position struggle with hidden custom field sprawl, user downtime, and compliance bottlenecks when orchestrating enterprise transitions.
                  </p>
                  <p>
                    Praecipio’s Forward Deployed team has engineered 350+ enterprise Atlassian and digital operations transformations, reducing cutover timelines by 40% with zero lost sprints.
                  </p>
                  <p>
                    Would you be open to a 10-minute peer briefing on how we de-risk the transition for high-growth engineering organizations?
                  </p>
                  <p className="text-slate-400 pt-2 border-t border-slate-900">
                    Best regards,<br />
                    <strong className="text-slate-200">Praecipio Enterprise Practice</strong>
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                <span>Sent on behalf of AE via Smartlead Mailbox Rotation</span>
                <span className="text-cyan-400">Step 1 of 4 Autonomous Sequence</span>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATOR 2: Inbound Automation */}
        {activeTab === 'inbound' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl">
            <div className="lg:col-span-5 space-y-4 border-b lg:border-b-0 lg:border-r border-slate-800 lg:pr-6">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Bot className="w-4 h-4 text-emerald-400" />
                  Simulate Inbound Contact Submission
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                  VNTNR CRM Shield
                </span>
              </div>

              <p className="text-xs text-slate-400">
                Choose a lead scenario submitted through Praecipio's website to observe the instant classification, scoring, and routing workflow.
              </p>

              <div className="space-y-2">
                {[
                  {
                    type: 'enterprise',
                    label: 'Enterprise MQL (High Intent)',
                    company: 'Stratos Financial ($800M ARR)',
                    msg: 'Looking for Atlassian Cloud Platinum migration partner for 5,000 Jira users by Q1.'
                  },
                  {
                    type: 'midmarket',
                    label: 'Mid-Market Discovery',
                    company: 'Nexus Health (250 seats)',
                    msg: 'Need Jira Service Management setup for internal IT helpdesk.'
                  },
                  {
                    type: 'spam',
                    label: 'Irrelevant Inquiry / Vendor Pitch',
                    company: 'SEO Agency Spam',
                    msg: 'Boost your website rankings on Google with backlinks.'
                  }
                ].map((item) => (
                  <button
                    key={item.type}
                    onClick={() => setInboundLeadType(item.type as any)}
                    className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      inboundLeadType === item.type
                        ? 'bg-emerald-950/40 border-emerald-500/50 ring-1 ring-emerald-500/30'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{item.label}</span>
                      <span className="text-[10px] font-mono text-slate-400">{item.company}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 italic line-clamp-1">"{item.msg}"</p>
                  </button>
                ))}
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Latency to Lead Qualification:</span>
                  <span className="font-mono text-emerald-400 font-bold">1.4 Seconds</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>First Response Dispatch:</span>
                  <span className="font-mono text-cyan-400 font-bold">&lt; 45 Seconds</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>CRM Sync Status:</span>
                  <span className="font-mono text-emerald-400">HubSpot & Salesforce Active</span>
                </div>
              </div>
            </div>

            {/* Inbound Routing Visualizer */}
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-mono text-slate-400 uppercase flex items-center justify-between">
                <span>Autonomous Routing Pipeline Execution</span>
                <span className="text-emerald-400 font-bold">Execution ID: #INB-9842</span>
              </div>

              {/* Visual Pipeline Steps */}
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-xs font-mono font-bold">
                      1
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Payload Normalized & Enriched</div>
                      <div className="text-[11px] text-slate-400">Clearbit + ZoomInfo firmographics populated in 400ms</div>
                    </div>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-mono font-bold">
                      2
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">AI Intent & Scoring Assessment</div>
                      <div className="text-[11px] text-slate-400">
                        {inboundLeadType === 'enterprise' && 'Tier 1 Enterprise MQL • Score 98/100 • $150k+ Deal Potential'}
                        {inboundLeadType === 'midmarket' && 'Tier 2 Mid-Market • Score 82/100 • $35k Deal Potential'}
                        {inboundLeadType === 'spam' && 'Tier 4 Unqualified / Vendor Spam • Filtered Out'}
                      </div>
                    </div>
                  </div>
                  <span className={`text-xs font-mono px-2 py-0.5 rounded font-bold ${
                    inboundLeadType === 'spam' ? 'bg-rose-950 text-rose-300' : 'bg-emerald-950 text-emerald-300'
                  }`}>
                    {inboundLeadType === 'spam' ? 'SPAM FILTERED' : 'QUALIFIED MQL'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono font-bold">
                      3
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">CRM & Territory Auto-Assignment</div>
                      <div className="text-[11px] text-slate-400">
                        {inboundLeadType === 'spam' ? 'Archived into Junk Queue' : 'Assigned to Senior Enterprise AE: Marcus Vance (Central Territory)'}
                      </div>
                    </div>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-mono font-bold">
                      4
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Instant Rep Slack Alert & ChiliPiper Calendar Hold</div>
                      <div className="text-[11px] text-slate-400">Slack notification fired with pre-written confirmation draft</div>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-cyan-400">&lt; 42s elapsed</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATOR 3: Pre-Call & Post-Call Dossier */}
        {activeTab === 'precall' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl">
            <div className="lg:col-span-6 space-y-4 border-b lg:border-b-0 lg:border-r border-slate-800 lg:pr-6">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-purple-400" />
                  Pre-Call Executive Dossier (60m Prior)
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
                  Automated Synthesis
                </span>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs text-slate-300">
                <div className="border-b border-slate-800 pb-2">
                  <div className="text-white font-bold text-sm">Meeting: Praecipio Cloud Scoping Discovery</div>
                  <div className="text-slate-400 text-[11px]">Today @ 2:00 PM EST • Attendee: David Ross (Chief Info Officer, Meridian Health)</div>
                </div>

                <div>
                  <span className="text-cyan-400 font-mono uppercase text-[10px] font-bold block mb-1">
                    Executive Profile & Intent
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    David previously served as VP of IT at Highmark. Championed cloud-first initiatives. Hired 8 months ago to modernize clinical operations.
                  </p>
                </div>

                <div>
                  <span className="text-purple-400 font-mono uppercase text-[10px] font-bold block mb-1">
                    Atlassian Footprint & Pain Triggers
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    Currently operating Jira Software Data Center (3,200 seats) + Jira Service Management. Facing server end-of-support in 6 months with strict HIPAA compliance mandates.
                  </p>
                </div>

                <div>
                  <span className="text-emerald-400 font-mono uppercase text-[10px] font-bold block mb-1">
                    Recommended Discovery Inquiries
                  </span>
                  <ul className="list-disc pl-4 space-y-1 text-slate-300">
                    <li>"How is Meridian addressing PHI data classification ahead of the cloud migration?"</li>
                    <li>"What is your target timeline for decommissioning the on-prem server infrastructure?"</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Post-Call Synthesis */}
            <div className="lg:col-span-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  Post-Call Synthesis & CRM Sync (Within 5m)
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500/30">
                  Transcript Mining
                </span>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs text-slate-300">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-white font-bold text-sm">Call Completed: 2:48 PM</span>
                  <span className="font-mono text-emerald-400 text-xs">CRM Deals Updated</span>
                </div>

                <div className="space-y-1.5">
                  <span className="text-blue-400 font-mono uppercase text-[10px] font-bold block">
                    MEDDPICC Summary Extracted
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div><strong className="text-slate-400">Economic Buyer:</strong> David Ross (CIO)</div>
                    <div><strong className="text-slate-400">Budget:</strong> $180k approved for Q4</div>
                    <div><strong className="text-slate-400">Decision Criteria:</strong> Zero healthcare downtime</div>
                    <div><strong className="text-slate-400">Next Step:</strong> Deliver SOW by Oct 12</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-cyan-400 font-mono uppercase text-[10px] font-bold block mb-1">
                    Auto-Drafted Client Follow-Up (Loaded in Rep Drafts)
                  </span>
                  <p className="text-slate-400 text-[11px] italic bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                    "David — enjoyed our conversation today. As discussed, I’ve mapped out our migration protocol specifically addressing your HIPAA audit requirements. Attached is our preliminary architecture checklist..."
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATOR 4: Daily Execution Telemetry */}
        {activeTab === 'health' && (
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-400" />
                  Daily Execution & Automated Health Report
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Sent daily at 8:00 AM to Praecipio leadership: Summary of active runs, uptime, and immediate error triage.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold self-start sm:self-auto">
                System Status: 99.8% Healthy
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs font-mono text-slate-400">Outbound Runs Today</div>
                <div className="text-2xl font-black text-white mt-1">1,420</div>
                <div className="text-[10px] text-emerald-400 font-mono mt-1">100% completed</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs font-mono text-slate-400">Inbound Leads Handled</div>
                <div className="text-2xl font-black text-white mt-1">38</div>
                <div className="text-[10px] text-cyan-400 font-mono mt-1">Avg latency: 54s</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs font-mono text-slate-400">Dossiers Generated</div>
                <div className="text-2xl font-black text-white mt-1">14</div>
                <div className="text-[10px] text-purple-400 font-mono mt-1">100% meeting coverage</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs font-mono text-slate-400">Exceptions / Alerts</div>
                <div className="text-2xl font-black text-amber-400 mt-1">1</div>
                <div className="text-[10px] text-amber-400 font-mono mt-1">Auto-retried & resolved</div>
              </div>
            </div>

            {/* Error Triage Log */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="text-xs font-mono text-slate-400 uppercase font-semibold flex items-center justify-between">
                <span>Recent Error Triage Digest (Slack #gtm-automations-health)</span>
                <span className="text-[11px] text-slate-500">Auto-generated 8:00 AM</span>
              </div>
              <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/20 flex items-start gap-3 text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="font-semibold text-amber-300">
                    Warning: Apollo API Rate Limit Encountered on Batch #409
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    Automatic backoff activated. Execution resumed after 120s pause. Zero prospect records lost. All sequences delivered on schedule.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATOR 5: GTM ROI & Capacity Calculator */}
        {activeTab === 'roi' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl">
            <div className="lg:col-span-5 space-y-5 border-b lg:border-b-0 lg:border-r border-slate-800 lg:pr-6">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-pink-400" />
                Praecipio GTM Team Parameters
              </h3>

              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-300">Active Sales / Consulting Reps:</span>
                  <span className="font-mono text-cyan-400 font-bold">{salesTeamSize} Reps</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="30"
                  value={salesTeamSize}
                  onChange={(e) => setSalesTeamSize(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-300">Average Engagement Deal Size:</span>
                  <span className="font-mono text-emerald-400 font-bold">${averageDealSize.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="25000"
                  max="250000"
                  step="5000"
                  value={averageDealSize}
                  onChange={(e) => setAverageDealSize(Number(e.target.value))}
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-300">Target Opportunity Close Rate:</span>
                  <span className="font-mono text-purple-400 font-bold">{currentConversion}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="35"
                  value={currentConversion}
                  onChange={(e) => setCurrentConversion(Number(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
                <p>
                  Calculated using empirical benchmarks from SalesGency GTM activation deployments: 
                  <strong> 14.5 hours saved per rep/week</strong> across research, logging, and follow-ups.
                </p>
              </div>
            </div>

            {/* Projected Impact Dashboard */}
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-mono text-slate-400 uppercase">
                Projected 6-Month Activation Impact
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-xs text-slate-400 font-mono">Team Capacity Reclaimed</div>
                  <div className="text-3xl font-black text-cyan-400 mt-1">
                    {totalHoursSavedMonthly.toLocaleString()} hrs
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Equivalent to +{Math.round((totalHoursSavedMonthly / 160) * 10) / 10} full-time engineers
                  </div>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-xs text-slate-400 font-mono">Net Pipeline Generated</div>
                  <div className="text-3xl font-black text-emerald-400 mt-1">
                    ${(incrementalPipeline / 1000000).toFixed(2)}M
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Across 6-month consulting activation
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-xl bg-gradient-to-r from-cyan-950/40 via-slate-950 to-purple-950/40 border border-cyan-500/30">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-cyan-300 font-bold uppercase">
                    Estimated Revenue Value Created
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    ROI ~ 12x Retainer
                  </span>
                </div>
                <div className="text-3xl sm:text-4xl font-black text-white mt-2">
                  ${estimatedARRBoost.toLocaleString()}
                </div>
                <p className="text-xs text-slate-300 mt-2">
                  Direct revenue unlocked through accelerated inbound response, 24% outbound reply rates, 
                  and 100% post-call follow-up discipline.
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
