import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { PROPOSAL_METADATA } from '../data/proposalData';
import { 
  ShieldCheck, 
  CheckCircle2, 
  Printer, 
  Sparkles, 
  Lock, 
  PenTool, 
  User, 
  Calendar,
  Building,
  Check
} from 'lucide-react';

export const ProposalSignoff: React.FC<{ onPrint: () => void }> = ({ onPrint }) => {
  const [signerName, setSignerName] = useState('Praecipio Leadership Team');
  const [signerTitle, setSignerTitle] = useState('Executive Stakeholder / Practice Lead');
  const [isSigned, setIsSigned] = useState(false);
  const [signedDate, setSignedDate] = useState('');

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signerName.trim()) return;

    setIsSigned(true);
    const dateStr = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    setSignedDate(dateStr);

    // Fire celebratory confetti!
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <section id="signoff" className="py-14 border-b border-slate-800 bg-[#06090F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            SECTION 07 • ACCEPTANCE & FORMAL KICKOFF
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Proposal Acceptance & Authorization
          </h2>
          <p className="mt-2 text-slate-300 text-sm sm:text-base leading-relaxed">
            Authorize the 6-month consulting activation starting Monday, October 5, 2026, with initial engagement September 28, 2026.
          </p>
        </div>

        {/* Formal Agreement Container */}
        <div className="max-w-4xl mx-auto rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-10 shadow-2xl space-y-8">
          
          {/* Terms Checklist */}
          <div className="space-y-3 border-b border-slate-800 pb-6">
            <h3 className="text-sm font-mono uppercase tracking-wider text-slate-400 font-semibold">
              Summary of Approved Activation Parameters
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Engagement Term:</strong> 6 Months with mutual option to renew</span>
              </div>
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Core Deliverables:</strong> 6 Customized Automations + Ad-hoc engineering</span>
              </div>
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Key Dates:</strong> Sept 28 Assessment • Oct 5 Kickoff • Q1 '27 Checkup</span>
              </div>
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Cadence:</strong> Weekly standups, weekly office hours & unlimited access</span>
              </div>
            </div>
          </div>

          {/* Dual Signature Blocks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Consultant: Patrick Diamitani */}
            <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase">
                  Service Provider / Consultant
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  Authorized & Executed
                </span>
              </div>

              <div className="border-b border-dashed border-slate-700 pb-3">
                <div className="text-2xl font-serif italic text-cyan-300 tracking-wide font-normal">
                  Patrick Diamitani
                </div>
              </div>

              <div className="text-xs space-y-1 text-slate-400">
                <div><strong className="text-slate-200">Patrick Diamitani</strong></div>
                <div>Forward Deployed AI Engineer & GTM Strategist</div>
                <div>Diamitani Industries / SalesGency.</div>
                <div className="text-[11px] font-mono text-slate-500 pt-1">
                  Signed: September 9, 2026 • 4:59 PM EST
                </div>
              </div>
            </div>

            {/* Client: Praecipio Consulting */}
            <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-emerald-400 font-bold uppercase">
                  Client / Authorizing Entity
                </span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                  isSigned 
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-500/30' 
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  {isSigned ? 'Digitally Signed & Accepted' : 'Pending Authorization'}
                </span>
              </div>

              {isSigned ? (
                <div className="space-y-4">
                  <div className="border-b border-dashed border-emerald-500/40 pb-3">
                    <div className="text-2xl font-serif italic text-emerald-300 tracking-wide font-normal">
                      {signerName}
                    </div>
                  </div>
                  <div className="text-xs space-y-1 text-slate-400">
                    <div><strong className="text-slate-200">{signerName}</strong></div>
                    <div>{signerTitle}</div>
                    <div>Praecipio Consulting</div>
                    <div className="text-[11px] font-mono text-emerald-400 pt-1">
                      Accepted: {signedDate}
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSign} className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Authorizer Name:</label>
                    <input
                      type="text"
                      value={signerName}
                      onChange={(e) => setSignerName(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">Authorizer Title:</label>
                    <input
                      type="text"
                      value={signerTitle}
                      onChange={(e) => setSignerTitle(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer mt-2"
                  >
                    <PenTool className="w-3.5 h-3.5" />
                    Accept & Sign Activation Plan
                  </button>
                </form>
              )}
            </div>

          </div>

          {/* Action Bar */}
          <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Lock className="w-4 h-4 text-slate-500" />
              <span>Secure Digital Authorization • Ready for Execution</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onPrint}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-cyan-400" />
                Export / Print PDF Proposal
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
