import React from 'react';
import { ROADMAP_PHASES, PROPOSAL_METADATA } from '../data/proposalData';
import { 
  Calendar, 
  CheckCircle, 
  Clock, 
  Key, 
  FileText, 
  MessageSquare, 
  Sliders, 
  Rocket, 
  PhoneCall, 
  Sparkles,
  ShieldCheck,
  Zap
} from 'lucide-react';

export const ProjectRoadmapSection: React.FC = () => {
  return (
    <section id="roadmap" className="py-14 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono mb-3">
            <Calendar className="w-3.5 h-3.5" />
            SECTION 05 • EXECUTION PHASES & CADENCE
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            The Activation Process
          </h2>
          <p className="mt-2 text-slate-300 max-w-2xl text-sm sm:text-base">
            From initial assessment and credential handoff through personalized SOWs, governance alignment, 
            and weekly sprint execution.
          </p>
        </div>

        {/* Highlight Banner: Kickoff & Communication Guarantees */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <div className="p-5 rounded-xl bg-slate-900/90 border border-cyan-500/30 flex items-start gap-3 shadow-lg">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 shrink-0">
              <Rocket className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono text-cyan-400 uppercase font-bold">Key Activation Dates</div>
              <div className="text-sm font-bold text-white mt-1">
                Proposed Kickoff: {PROPOSAL_METADATA.kickoffDate}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Initial Engagement Session: {PROPOSAL_METADATA.initialEngagementDate}
              </div>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/90 border border-purple-500/30 flex items-start gap-3 shadow-lg">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono text-purple-400 uppercase font-bold">Unlimited Communication</div>
              <div className="text-sm font-bold text-white mt-1">
                Direct Text, Email & Call Availability
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Immediate turnaround for urgent pipeline queries
              </div>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/90 border border-emerald-500/30 flex items-start gap-3 shadow-lg">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono text-emerald-400 uppercase font-bold">Operational Cadence</div>
              <div className="text-sm font-bold text-white mt-1">
                Weekly Standups & Office Hours
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {PROPOSAL_METADATA.checkupDate} Formal Review
              </div>
            </div>
          </div>
        </div>

        {/* Sequenced Roadmap Timeline */}
        <div className="space-y-6">
          {ROADMAP_PHASES.map((phase, idx) => (
            <div
              key={phase.phaseNumber}
              className="relative rounded-2xl bg-slate-900/60 border border-slate-800 p-6 hover:border-slate-700 transition-all"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Left: Phase Identifiers */}
                <div className="lg:col-span-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono font-bold text-xs flex items-center justify-center">
                      {phase.phaseNumber}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {phase.dateRange}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white tracking-tight">
                    {phase.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {phase.summary}
                  </p>
                </div>

                {/* Middle: Activities Checklist */}
                <div className="lg:col-span-5 space-y-2">
                  <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                    Key Activities & Workstreams
                  </div>
                  <div className="space-y-1.5">
                    {phase.activities.map((act, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <span className="text-cyan-400 font-bold">•</span>
                        <span>{act}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Deliverables Output */}
                <div className="lg:col-span-3 bg-slate-950/80 rounded-xl p-3.5 border border-slate-800/80 space-y-2">
                  <div className="text-[10px] font-mono uppercase text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Formal Output
                  </div>
                  <div className="space-y-1">
                    {phase.deliverables.map((del, dIdx) => (
                      <div key={dIdx} className="text-[11px] text-slate-300 flex items-start gap-1.5">
                        <span className="text-emerald-400">✓</span>
                        <span>{del}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          ))}
        </div>

        {/* 3-Month Check Up Deep-Dive */}
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-cyan-950/30 via-slate-900 to-purple-950/30 border border-cyan-500/30">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono text-[10px] font-bold">
                  Q1 2027 MILESTONE
                </span>
                <span className="text-xs text-slate-400 font-mono">Formal Check-Up Session</span>
              </div>
              <h4 className="text-lg font-bold text-white">
                3-Month Performance Audit & Option to Renew
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                A structured checkpoint to review metric attainment, revenue generated, pipeline acceleration, 
                and decide collaboratively on expanding into optional projects or renewing the 6-month consulting activation.
              </p>
            </div>

            <div className="text-xs font-mono text-cyan-300 bg-cyan-950/40 border border-cyan-500/30 px-4 py-2.5 rounded-xl whitespace-nowrap">
              Weekly Standups + Office Hours Included
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
