import React, { useState, useEffect, useRef } from 'react';
import { SalesGencyLogo } from './SalesGencyLogo';
import { BrandModalLight } from './BrandModalLight';
import { 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  Grid3X3, 
  MonitorPlay, 
  FileText, 
  Printer, 
  Sparkles,
  Layers,
  ArrowRight,
  BookOpen
} from 'lucide-react';

import { Slide01Cover } from './slides/Slide01Cover';
import { Slide02ConsultingModel } from './slides/Slide02ConsultingModel';
import { Slide03CoreWorkflowsOverview } from './slides/Slide03CoreWorkflowsOverview';
import { Slide04WorkflowsDeepDive1 } from './slides/Slide04WorkflowsDeepDive1';
import { Slide05WorkflowsDeepDive2 } from './slides/Slide05WorkflowsDeepDive2';
import { Slide06Simulators } from './slides/Slide06Simulators';
import { Slide07ExpansionProjects } from './slides/Slide07ExpansionProjects';
import { Slide08RoadmapCadence } from './slides/Slide08RoadmapCadence';
import { Slide09TheThreeTs } from './slides/Slide09TheThreeTs';
import { Slide10Signoff } from './slides/Slide10Signoff';

export interface SlideItem {
  id: string;
  number: number;
  title: string;
  category: string;
  component: React.ReactNode;
}

export const PresentationDeck: React.FC = () => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'slideshow' | 'grid' | 'document'>('slideshow');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showBrandModal, setShowBrandModal] = useState(false);
  const deckContainerRef = useRef<HTMLDivElement>(null);

  const slides: SlideItem[] = [
    {
      id: 'slide-01',
      number: 1,
      title: 'Executive Activation Plan',
      category: 'Cover & Context',
      component: (
        <Slide01Cover
          onNext={() => setCurrentSlideIndex(1)}
          onJumpToSlide={(idx) => setCurrentSlideIndex(idx)}
        />
      ),
    },
    {
      id: 'slide-02',
      number: 2,
      title: 'Consulting Retainer vs. Internal FTE',
      category: 'Strategic Pivot',
      component: (
        <Slide02ConsultingModel
          onNext={() => setCurrentSlideIndex(2)}
          onPrev={() => setCurrentSlideIndex(0)}
        />
      ),
    },
    {
      id: 'slide-03',
      number: 3,
      title: 'The 6 Core Production Workflows',
      category: 'Workflows Catalog',
      component: (
        <Slide03CoreWorkflowsOverview
          onNext={() => setCurrentSlideIndex(3)}
          onSelectWorkflowDetail={(wfId) => {
            if (['prospect-automation', 'inbound-automation', 'pre-call-workflow'].includes(wfId)) {
              setCurrentSlideIndex(3);
            } else {
              setCurrentSlideIndex(4);
            }
          }}
        />
      ),
    },
    {
      id: 'slide-04',
      number: 4,
      title: 'Deep Dive: Outbound, Inbound & Pre-Call',
      category: 'Workflows 01–03',
      component: (
        <Slide04WorkflowsDeepDive1
          onNext={() => setCurrentSlideIndex(4)}
          onOpenBrandModal={() => setShowBrandModal(true)}
        />
      ),
    },
    {
      id: 'slide-05',
      number: 5,
      title: 'Deep Dive: Post-Call, Telemetry & Dashboard',
      category: 'Workflows 04–06',
      component: (
        <Slide05WorkflowsDeepDive2
          onNext={() => setCurrentSlideIndex(5)}
          onOpenBrandModal={() => setShowBrandModal(true)}
        />
      ),
    },
    {
      id: 'slide-06',
      number: 6,
      title: 'Interactive Workflow Simulators',
      category: 'Live Architecture Test-Drive',
      component: <Slide06Simulators onNext={() => setCurrentSlideIndex(6)} />,
    },
    {
      id: 'slide-07',
      number: 7,
      title: 'High-Impact Expansion Projects',
      category: 'Optional Sprint Modules',
      component: <Slide07ExpansionProjects onNext={() => setCurrentSlideIndex(7)} />,
    },
    {
      id: 'slide-08',
      number: 8,
      title: 'Activation Roadmap & Cadence',
      category: 'Timeline & Milestones',
      component: <Slide08RoadmapCadence onNext={() => setCurrentSlideIndex(8)} />,
    },
    {
      id: 'slide-09',
      number: 9,
      title: 'The 3 Ts Decision Framework',
      category: 'Timeline • Transaction • Tech',
      component: <Slide09TheThreeTs onNext={() => setCurrentSlideIndex(9)} />,
    },
    {
      id: 'slide-10',
      number: 10,
      title: 'Authorization & Sign-Off Block',
      category: 'Acceptance & Execution',
      component: <Slide10Signoff />,
    },
  ];

  const currentSlide = slides[currentSlideIndex];

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger when user is typing in form inputs
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
        e.preventDefault();
        setCurrentSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        setCurrentSlideIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Home') {
        e.preventDefault();
        setCurrentSlideIndex(0);
      } else if (e.key === 'End') {
        e.preventDefault();
        setCurrentSlideIndex(slides.length - 1);
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [slides.length]);

  const toggleFullscreen = () => {
    if (!deckContainerRef.current) return;
    if (!document.fullscreenElement) {
      deckContainerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      ref={deckContainerRef}
      className={`min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col justify-between select-none ${
        isFullscreen ? 'p-6 sm:p-10 bg-white' : ''
      }`}
    >
      {/* Top Deck Control Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200 px-4 sm:px-8 py-3.5 no-print">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          
          {/* Brand & Document Title */}
          <div className="flex items-center gap-3">
            <SalesGencyLogo size="sm" variant="gradient" withGlow={false} />
            <div className="h-4 w-px bg-slate-200" />
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-slate-900 text-sm tracking-tight">
                Diamitani Industries
              </span>
              <span className="text-slate-300">×</span>
              <span className="font-bold text-sky-700 text-sm tracking-tight">
                Praecipio Consulting
              </span>
            </div>
          </div>

          {/* Center: Slide Jump & Title (in slideshow mode) */}
          {viewMode === 'slideshow' && (
            <div className="hidden md:flex items-center gap-2 bg-slate-100/90 border border-slate-200 rounded-full px-3 py-1 text-xs">
              <span className="font-bold text-slate-800">
                Slide {currentSlideIndex + 1} of {slides.length}:
              </span>
              <span className="text-slate-600 font-medium truncate max-w-xs">
                {currentSlide.title}
              </span>
            </div>
          )}

          {/* Right: View Modes & Action Tools */}
          <div className="flex items-center gap-2 text-xs">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode('slideshow')}
                title="Slide Show Mode (Default)"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  viewMode === 'slideshow'
                    ? 'bg-white text-slate-900 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MonitorPlay className="w-3.5 h-3.5 text-sky-600" />
                <span className="hidden sm:inline">Slide Show</span>
              </button>

              <button
                onClick={() => setViewMode('grid')}
                title="Slide Sorter Grid View"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-white text-slate-900 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Grid3X3 className="w-3.5 h-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Slide Sorter</span>
              </button>

              <button
                onClick={() => setViewMode('document')}
                title="Continuous Document View"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  viewMode === 'document'
                    ? 'bg-white text-slate-900 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-purple-600" />
                <span className="hidden sm:inline">All Slides</span>
              </button>
            </div>

            {/* Blueprints Modal Trigger */}
            <button
              onClick={() => setShowBrandModal(true)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer shadow-sm transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Blueprints</span>
            </button>

            {/* Print button */}
            <button
              onClick={handlePrint}
              title="Print Presentation Deck or Export PDF"
              className="flex items-center gap-1.5 p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer shadow-sm transition-all"
            >
              <Printer className="w-4 h-4" />
            </button>

            {/* Fullscreen toggle */}
            <button
              onClick={toggleFullscreen}
              title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen (F)'}
              className="flex items-center gap-1.5 p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer shadow-sm transition-all"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>

        </div>
      </header>

      {/* Main Slide Deck Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
        
        {/* MODE 1: SINGLE SLIDE SHOW (Default & Primary) */}
        {viewMode === 'slideshow' && (
          <div className="w-full">
            {/* Slide Frame Card */}
            <div className="w-full bg-white rounded-3xl slide-card border border-slate-200/90 p-6 sm:p-10 lg:p-12 min-h-[660px] flex flex-col justify-between transition-all duration-200">
              {currentSlide.component}
            </div>

            {/* Slide Progress Indicator */}
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-6">
              <div
                className="bg-sky-600 h-full rounded-full transition-all duration-300 ease-out"
                style={{ width: `${((currentSlideIndex + 1) / slides.length) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* MODE 2: SLIDE SORTER GRID VIEW */}
        {viewMode === 'grid' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-extrabold text-slate-900">Slide Sorter View</h2>
                <p className="text-xs text-slate-500">Click any slide to open in full presentation mode</p>
              </div>
              <button
                onClick={() => setViewMode('slideshow')}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer"
              >
                Resume Slide Show
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {slides.map((s, idx) => (
                <div
                  key={s.id}
                  onClick={() => {
                    setCurrentSlideIndex(idx);
                    setViewMode('slideshow');
                  }}
                  className={`p-6 rounded-2xl border transition-all cursor-pointer group flex flex-col justify-between min-h-[220px] ${
                    currentSlideIndex === idx
                      ? 'bg-sky-50/60 border-sky-400 ring-2 ring-sky-200 shadow-md'
                      : 'bg-white border-slate-200 hover:border-sky-300 hover:shadow-lg'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">
                        Slide {s.number}
                      </span>
                      <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {s.category}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-sky-700 transition-colors">
                      {s.title}
                    </h3>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
                    <span>Jump to Slide</span>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-sky-600 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODE 3: CONTINUOUS DOCUMENT VIEW */}
        {viewMode === 'document' && (
          <div className="space-y-12">
            {slides.map((s, idx) => (
              <div
                key={s.id}
                className="bg-white rounded-3xl slide-card border border-slate-200 p-6 sm:p-10 lg:p-12 min-h-[640px] slide-print-break"
              >
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100 text-xs text-slate-400 font-semibold uppercase tracking-wider">
                  <span>Slide {s.number} of {slides.length} • {s.category}</span>
                  <span>Diamitani Industries x Praecipio Activation Plan</span>
                </div>
                {s.component}
              </div>
            ))}
          </div>
        )}

      </main>

      {/* Bottom Slide Carousel Navigation Controls */}
      {viewMode === 'slideshow' && (
        <footer className="sticky bottom-0 z-40 bg-white/95 backdrop-blur border-t border-slate-200 px-4 sm:px-8 py-3.5 no-print">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
            
            {/* Previous Button */}
            <button
              onClick={() => setCurrentSlideIndex((prev) => Math.max(prev - 1, 0))}
              disabled={currentSlideIndex === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold text-slate-700 shadow-sm transition-all cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            {/* Quick Slide Numbers Strip */}
            <div className="hidden sm:flex items-center gap-1.5 overflow-x-auto py-1">
              {slides.map((s, idx) => {
                const isActive = currentSlideIndex === idx;
                return (
                  <button
                    key={s.id}
                    onClick={() => setCurrentSlideIndex(idx)}
                    title={`Jump to Slide ${s.number}: ${s.title}`}
                    className={`h-8 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                    }`}
                  >
                    {s.number}
                  </button>
                );
              })}
            </div>

            {/* Next Button + Keyboard hint */}
            <div className="flex items-center gap-3">
              <span className="hidden lg:inline text-[11px] text-slate-400 font-medium">
                Use [ ← / → ] keys
              </span>

              <button
                onClick={() => setCurrentSlideIndex((prev) => Math.min(prev + 1, slides.length - 1))}
                disabled={currentSlideIndex === slides.length - 1}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold text-white shadow-sm transition-all cursor-pointer"
              >
                <span>Next Slide</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </footer>
      )}

      {/* Light-themed Brand Guidelines & Client Blueprints Modal */}
      <BrandModalLight
        isOpen={showBrandModal}
        onClose={() => setShowBrandModal(false)}
      />
    </div>
  );
};
