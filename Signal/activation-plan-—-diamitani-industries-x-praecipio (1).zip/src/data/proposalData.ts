import { WorkflowItem, OptionalProject, RoadmapPhase, ProposalMetadata } from '../types';

export const PROPOSAL_METADATA: ProposalMetadata = {
  title: 'Activation Plan',
  subtitle: 'Internal GTM & Forward Deployed AI Infrastructure Activation',
  client: 'Praecipio Consulting',
  author: 'Patrick Diamitani',
  authorTitle: 'Forward Deployed AI Engineer & GTM Strategist',
  company: 'Diamitani Industries',
  brand: 'SalesGency.',
  proposalDate: 'September 9, 2026 • 4:59 PM',
  initialEngagementDate: 'Monday, September 28, 2026',
  kickoffDate: 'Monday, October 5, 2026',
  checkupDate: "Q1 2027 (3-Month Formal Check-Up)",
  engagementLength: '6 Months (with Option to Renew)',
};

export const CORE_WORKFLOWS: WorkflowItem[] = [
  {
    id: 'prospect-automation',
    number: '01',
    title: 'Customized Prospect Automation Workflow',
    subtitle: 'Autonomous ICP Sourcing, Multi-Tier Research & Hyper-Personalized Messaging',
    category: 'Outbound',
    blueprintReference: 'AEORIM AI',
    summary:
      'Combines Praecipio’s technical stack with defined Ideal Customer Profiles (ICPs) to dynamically source high-value accounts, conduct in-depth executive research, and dispatch personalized multi-touch outreach on behalf of sales reps.',
    fullDescription:
      'Engineered to replicate top-tier SDR intelligence at scale. The system monitors trigger events (tech stack additions, executive appointments, Atlassian cloud migrations, funding milestones), aggregates account insights across platforms, and generates tailored PAS (Pain-Agitation-Solution) messaging calibrated to the individual rep’s voice.',
    stackIntegration: ['Apollo / Clay', 'Claude 3.5 Sonnet / Gemini', 'HubSpot / Salesforce', 'Smartlead / Instantly', 'LinkedIn Sales Navigator'],
    businessImpact: 'Targets 20%+ qualified reply rates, 4x outbound pipeline velocity, and saves 15+ hours per AE/SDR per week.',
    deliverables: [
      'Automated ICP lead scraping and data enrichment pipeline',
      'AI research synthesizer generating prospect battle cards',
      'Dynamic variable templating engine for high-converting multi-stage outreach',
      'Deliverability safeguards with zero-burn mailbox rotation'
    ],
    metricsTarget: '24.2% Reply Rate | 68.5% Open Rate | 100% Rep Attribution'
  },
  {
    id: 'inbound-automation',
    number: '02',
    title: 'Customized Inbound Automation Workflow',
    subtitle: 'Instant CRM Routing, Intent Classification & Zero-Delay MQL Assignment',
    category: 'Inbound',
    blueprintReference: 'VNTNR Logistics',
    summary:
      'Unifies Praecipio’s online submission forms, chat widgets, and CRM with an intelligent NLP engine to instantly classify inquiries, score buying intent, assign MQLs to the right account team, and drop lead-to-response latency to seconds.',
    fullDescription:
      'Every second delay on inbound leads reduces conversion. This workflow ingests inbound submissions in real-time, queries company databases to enrich buyer firmographics, executes AI intent analysis to separate high-value opportunities from spam or support tickets, assigns territories, and notifies reps via Slack/Teams with ready-to-send responses.',
    stackIntegration: ['Website Forms / Webhooks', 'CRM (HubSpot & Salesforce)', 'Clearbit / ZoomInfo Enrichment', 'Slack / Teams Notifications', 'Cal.com / Chili Piper'],
    businessImpact: 'Cuts lead-to-first-response time from 4.8 hours to under 90 seconds, lifting inbound demo conversions by an estimated 35%.',
    deliverables: [
      'Webhook listener and payload normalization layer',
      'AI intent classification and spam filtering module',
      'Automated territory and industry-based routing logic',
      'Instant rep alert with auto-drafted qualification summary'
    ],
    metricsTarget: '<90s First Response | 99/100 Deliverability | 0% Lost MQLs'
  },
  {
    id: 'pre-call-workflow',
    number: '03',
    title: 'Customized Pre-Call Intelligence Workflow',
    subtitle: 'Automated Account Research Dossiers Delivered Prior to Every Meeting',
    category: 'Meetings',
    blueprintReference: 'Internal Core',
    summary:
      'Synchronizes with Praecipio’s external meeting calendar to identify upcoming client discovery calls, executes automated background research on attendees and their company, and compiles a comprehensive pre-call briefing report for the consultant or AE.',
    fullDescription:
      'Eliminates pre-meeting preparation overhead. 60 minutes before any scheduled discovery or scoping conversation, the rep receives a concise, actionable executive dossier containing: attendee career background, company recent news, active Jira/Atlassian initiatives, potential pain points, and recommended discovery questions.',
    stackIntegration: ['Google Calendar / Outlook 365', 'LinkedIn API', 'Company Website Scraper', 'Gemini / Claude Dossier Synthesis', 'Slack / Email Delivery'],
    businessImpact: 'Saves 30 minutes of manual research per meeting while driving deeper executive rapport and higher stage-advancement rates.',
    deliverables: [
      'Calendar event listener with automated attendee extraction',
      'Multi-source intelligence gathering engine',
      'One-page executive briefing dossier generator',
      'Automated dispatch to rep via direct message and calendar attachment'
    ],
    metricsTarget: '100% Meeting Coverage | 30 Min Prep Time Saved / Call'
  },
  {
    id: 'post-call-workflow',
    number: '04',
    title: 'Customized Post-Call Synthesis & Action Workflow',
    subtitle: 'Transcript Mining, Automated CRM Updates & Instant Follow-Up Execution',
    category: 'Meetings',
    blueprintReference: 'Internal Core',
    summary:
      'Ingests meeting audio/transcripts immediately following client calls, analyzes conversational sentiment and commitments, updates CRM deal stages with structured notes, and drafts tailored follow-up emails and tasks for review.',
    fullDescription:
      'No deal momentum is lost post-call. The workflow connects to Gong, Chorus, or Fireflies, parses the discussion, extracts agreed action items and technical requirements, maps them directly into CRM custom properties, and creates a formatted follow-up email in the rep’s draft folder within 5 minutes of call completion.',
    stackIntegration: ['Gong / Fireflies / Zoom AI', 'HubSpot / Salesforce CRM', 'Claude Synthesis Engine', 'Gmail / Outlook API', 'Asana / Jira Tasks'],
    businessImpact: 'Eliminates CRM administrative debt, ensures zero dropped customer commitments, and accelerates contract delivery velocity.',
    deliverables: [
      'Call transcript ingest webhook and speaker diarization parser',
      'MEDDPICC / BANT deal scorecard and action item extractor',
      'Bi-directional CRM notes and deal-stage updater',
      'Personalized follow-up draft generator loaded into rep inbox'
    ],
    metricsTarget: '<5 Min Post-Call Dispatch | 100% CRM Cleanliness'
  },
  {
    id: 'daily-execution-report',
    number: '05',
    title: 'Customized Daily Execution & Health Report',
    subtitle: 'Automated Run Logs, Workflow Telemetry & Proactive Failure Triage',
    category: 'Reporting',
    blueprintReference: 'VNTNR Logistics',
    summary:
      'Aggregates daily operational runs across all active GTM automations, compiling an executive spreadsheet and plain-language summary detailing execution volume, pipeline velocity, and immediate alerts for failed automations.',
    fullDescription:
      'Guarantees enterprise reliability and transparency. Each morning at 8:00 AM, Praecipio leadership and revenue operations receive an automated digest displaying: total outbound sequences fired, inbound leads processed, pre/post briefings compiled, and an error log detailing any API rate limits or failed runs with self-healing recommendations.',
    stackIntegration: ['Execution Telemetry Database', 'Google Sheets / Airtable API', 'Slack Ops Channel', 'Datadog / CloudWatch Logs', 'Email Digest Generator'],
    businessImpact: 'Provides 100% visibility into system uptime, prevents pipeline leakage, and ensures zero silent automation failures.',
    deliverables: [
      'Real-time execution listener and error-catching wrapper',
      'Automated daily run spreadsheet sync and archival',
      'Slack executive morning briefing summary',
      'Immediate alert notification for mission-critical automation exceptions'
    ],
    metricsTarget: '99.8% System Uptime | 8:00 AM Daily Delivery | Zero Silent Failures'
  },
  {
    id: 'gtm-dashboard',
    number: '06',
    title: 'Customized Go-To-Market Executive Dashboard',
    subtitle: 'Unified Revenue Intelligence, Pipeline Movement & KPI Visualization',
    category: 'Intelligence',
    blueprintReference: 'ARCHIN Robotics',
    summary:
      'Pulls multi-source data across Praecipio’s marketing, sales, and delivery platforms into a centralized, modern executive command center tracking key GTM velocity metrics, pipeline attribution, and conversion rates.',
    fullDescription:
      'Modeled after elite revenue intelligence interfaces (such as the ARCHIN Robotics command center). Features interactive funnel analytics, lead velocity tracking, revenue attribution by source, outbound vs inbound performance breakdowns, top rep leaderboards, and automated forecasting projections.',
    stackIntegration: ['CRM Warehouse (HubSpot/Salesforce)', 'Analytics API', 'Google Cloud / BigQuery', 'Modern React + D3 / Recharts', 'Executive Role-Based Access'],
    businessImpact: 'Gives executive stakeholders instant, single-pane clarity on sales health, campaign ROI, and team productivity without manual reporting.',
    deliverables: [
      'Multi-source data ingestion and ETL pipeline',
      'Real-time KPI metrics engine (ARR, Pipeline Value, Conversion Rates)',
      'Visual funnel stage and pipeline velocity chart components',
      'Executive-ready exportable reports and milestone tracking'
    ],
    metricsTarget: 'Real-time Refresh | Single Source of Truth | 100% Data Integrity'
  }
];

export const OPTIONAL_PROJECTS: OptionalProject[] = [
  {
    id: 'custom-sdr-agent',
    title: 'Custom Autonomous SDR Agent',
    badge: 'High Impact • Autonomous Outbound',
    description:
      'Connecting Claude 3.5 / Gemini models with live chatbot access to execute end-to-end GTM activities: autonomous prospect qualification, cold call prep, multichannel outreach drafting, objection handling research, and personalized follow-ups.',
    capabilities: [
      'Interactive Slack/Teams chatbot assistant for sales reps',
      'Real-time company search and buyer intent scanning',
      'Natural-language query: "Find 20 Director of IT leads at FinTech firms in Austin"',
      'Automated cadence generation with tone matching rep style'
    ],
    architecture: 'Anthropic Claude 3.5 Sonnet + Custom Tool Calling API + Vector Knowledge Base',
    estimatedDelivery: 'Sprint Add-on (Weeks 7–10)'
  },
  {
    id: 'sales-enablement-agent',
    title: 'Custom Sales Enablement Agent',
    badge: 'Workforce Productivity • AI Native',
    description:
      'Connecting and structuring Praecipio’s entire GTM tech stack for optimized, unified performance through an AI-native internal operating system for all employees, consultants, and account executives.',
    capabilities: [
      'Universal knowledge retrieval across Praecipio case studies, SOWs, and decks',
      'Instant proposal and pricing scope recommendation generator',
      'Competitor battlecard synthesis and objection response assistant',
      'Automated onboarding assistant for new sales & consulting hires'
    ],
    architecture: 'Multi-agent orchestration + Secure Internal Vector RAG over Praecipio IP',
    estimatedDelivery: 'Sprint Add-on (Weeks 11–14)'
  },
  {
    id: 'gtm-coe',
    title: 'Custom GTM Center of Excellence (CoE)',
    badge: 'Long-Term Scale • Org Enablement',
    description:
      'Building an enduring internal Center of Excellence featuring AI-generated video tutorials, tool walkthrough curriculums, and a centralized, version-controlled library of internal skills, workflows, and prompts.',
    capabilities: [
      'Automated high-definition video walkthroughs on tool usage and best practices',
      'Curated curriculum for onboarding new team members on AI-native workflows',
      'Centralized prompt and automation skill repository with version control',
      'Quarterly operational playbook updates and continuous skill benchmarking'
    ],
    architecture: 'LMS / Notion Hub + AI Synthesized Video & Interactive Walkthrough Guides',
    estimatedDelivery: 'Sprint Add-on (Weeks 15–18)'
  }
];

export const ROADMAP_PHASES: RoadmapPhase[] = [
  {
    phaseNumber: '01',
    title: 'Initial Assessment & Credential Transfer',
    dateRange: 'Week of Sept 28 – Oct 4, 2026',
    status: 'upcoming',
    summary: 'Discovery deep-dive into Praecipio’s current tech stack, sales processes, ICP definitions, and credential onboarding.',
    activities: [
      'Comprehensive audit of current tools (CRM, enrichment, email infra, calendars, forms)',
      'Review existing sales pipelines, ICP criteria, historical conversion benchmarks, and KPIs',
      'Define high-priority bottlenecks and quick-win automation opportunities',
      'Secure transfer of logins, API keys, and keysheet credentials via 1Password / Doppler'
    ],
    deliverables: [
      'Tech Stack Audit & Systems Integration Matrix',
      'Secure Credential Verification & Environment Setup',
      'Baseline Metric Scorecard'
    ]
  },
  {
    phaseNumber: '02',
    title: 'Personalized Roadmap & Scope of Work (SOWs)',
    dateRange: 'Oct 5 – Oct 16, 2026',
    status: 'upcoming',
    summary: 'Translating strategic discovery into production engineering specifications and sequenced milestone commitments.',
    activities: [
      'Construct detailed architectural blueprints for the 6 core workflows',
      'Draft formal Scopes of Work (SOWs) with explicit acceptance criteria',
      'Establish sprint-by-sprint release schedule and dependency mappings',
      'Finalize security, data governance, and compliance protocols'
    ],
    deliverables: [
      'Detailed Technical Architecture Diagrams & Workflow Blueprints',
      'Formal SOW Document for each Core Module',
      'Sprint Master Delivery Schedule'
    ]
  },
  {
    phaseNumber: '03',
    title: 'Executive Presentation, Feedback & Alignment',
    dateRange: 'Oct 19 – Oct 23, 2026',
    status: 'upcoming',
    summary: 'Collaborative review of architectural plans with Praecipio leadership to incorporate feedback and ensure strategic lockstep.',
    activities: [
      'Present complete roadmap and interactive workflow prototypes to leadership team',
      'Collect and synthesize leadership feedback, positive reviews, and constructive critiques',
      'Conduct risk-reward evaluations on technical tooling choices and cost profiles',
      'Refine deliverables and calibrate KPIs to match Praecipio Q4 and 2027 fiscal targets'
    ],
    deliverables: [
      'Leadership Alignment Sign-Off',
      'Feedback Incorporation & Scope Calibration Log',
      'Finalized Project Charter'
    ]
  },
  {
    phaseNumber: '04',
    title: 'The 3 Ts Engagement Output Decision',
    dateRange: 'Oct 26 – Oct 30, 2026',
    status: 'upcoming',
    summary: 'Executive agreement on the three foundational pillars of the activation: Timeline, Transaction, and Technology.',
    activities: [
      'Timeline Lock: Formalize milestone delivery dates and review checkpoints',
      'Transaction Agreement: Establish payment structure, retainer milestones, and terms',
      'Technology Selection: Finalize vendors, LLM API allocations, and webhook infrastructure'
    ],
    deliverables: [
      'The 3 Ts Master Agreement',
      'Commercial Terms & Billing Schedule',
      'Tooling Licensing & API Provisioning Plan'
    ]
  },
  {
    phaseNumber: '05',
    title: 'Full Engineering Deployment & Sprint Rollout',
    dateRange: 'Nov 2, 2026 – Jan 15, 2027',
    status: 'upcoming',
    summary: 'Hands-on forward deployed engineering, building, testing, and launching each customized workflow in staging and production.',
    activities: [
      'Sprint 1–2: Inbound Automation & Lead-to-CRM Routing deployment',
      'Sprint 3–4: Prospect Automation & Research engine rollout',
      'Sprint 5–6: Pre-Call & Post-Call meeting intelligence pipelines live',
      'Sprint 7–8: Daily Execution Health reporter & GTM Dashboard launch'
    ],
    deliverables: [
      'All 6 Core Workflows Deployed & Fully Operational in Production',
      'Team User Manuals & Quick-Start Guides',
      'Automated Testing & Monitoring Guardrails'
    ]
  },
  {
    phaseNumber: '06',
    title: 'Q1 2027 Check-Up & Ongoing Operational Cadence',
    dateRange: 'Q1 2027 (Jan – March 2027)',
    status: 'upcoming',
    summary: 'Comprehensive 3-month performance review, continuous workflow iteration, weekly office hours, and option-to-renew evaluation.',
    activities: [
      'Formal 3-Month Performance Review: Assess ROI, pipeline generated, and hours saved',
      'Weekly office hours, engineering standups, and live team training sessions',
      'Unlimited communication channel (direct text, email, and phone/video call availability)',
      'Ad-hoc construction of new skills, custom agents, and performance tuning',
      'Evaluation of 6-Month Renewal & Expansion to Optional Projects'
    ],
    deliverables: [
      'Q1 2027 Performance & ROI Audit Report',
      'Continuous Workflow Iterations & Optimization Log',
      'Option to Renew & Long-Term Scaling Proposal'
    ]
  }
];

export const ENGAGEMENT_COMPARISON = [
  {
    attribute: 'Time to Value',
    consultingActivation: 'Immediate (Sprint 1 releases within 14 days of kickoff)',
    internalHire: '3–5 months (sourcing, interview loops, notice period, onboarding)'
  },
  {
    attribute: 'Specialization Depth',
    consultingActivation: 'Battle-tested GTM automations & enterprise AI blueprints (SalesGency IP)',
    internalHire: 'Generalist FTE requiring steep ramp-up on proprietary tools'
  },
  {
    attribute: 'Financial Overhead',
    consultingActivation: 'Predictable consulting retainer, zero payroll tax, zero healthcare, zero equity dilution',
    internalHire: 'Base salary + 30% benefits + recruiting agency fees + severance risk'
  },
  {
    attribute: 'Commitment Flexibility',
    consultingActivation: '6-Month targeted activation with flexible renewal or transition to internal team',
    internalHire: 'Permanent headcount lock with long-term fixed cost'
  },
  {
    attribute: 'Support & Access',
    consultingActivation: 'Weekly standups, weekly office hours, training, and unlimited direct call/text access',
    internalHire: 'Standard corporate hours & internal meeting overhead'
  }
];
