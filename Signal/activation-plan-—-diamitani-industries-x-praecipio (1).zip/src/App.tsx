/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PresentationDeck } from './components/PresentationDeck';

export default function App() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans antialiased selection:bg-sky-100 selection:text-sky-900">
      <PresentationDeck />
    </div>
  );
}
