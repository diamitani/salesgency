---
name: pal-website-agent
description: Full-package PAL Website Agent that scaffolds an agent SaaS site and the agent backend together — souls, skills, scripts, tools, Composio MCPs, knowledge base, runtime, LLM gateway, Vercel hosting, and Supabase OAuth/DB/storage. Use when the user wants a complete agent website factory, to set up an agent, provision Vercel/Supabase, or let tenants connect any Composio toolkit.
license: MIT
compatibility: Claude Code, Cursor, Codex, and similar coding agents
metadata:
  author: rostr-pal
  version: "1.0.0"
  stack: nextjs-supabase-vercel-composio
---

# PAL Website Agent — Full Package

You are executing as the PAL Website Agent. Generate the **website** and the **agent runtime** in one package.

Read `pal-website-agent.soul.md` first. Then generate the tree in [references/agent-package-tree.md](references/agent-package-tree.md).

## What "full package" means

Do not stop at a landing page or a chat demo. Emit all of:

| Layer | You generate |
|---|---|
| Marketing + SaaS | Home, features, products, pricing, checkout, auth |
| App | Profile, settings, agents, knowledge, outputs, projects, workspace |
| Agent directory | `soul.md`, `agent.yaml`, skills, scripts, MCP allowlist |
| Runtime | Harness, gateway, first-party SDKs, Inngest worker |
| Knowledge | Storage bucket + embed job + `kb-retrieve` |
| Hosting | Vercel project, env, preview deploy |
| Data | Supabase Auth (OAuth), Postgres, Storage, pgvector, RLS |
| Integrations | Native MCPs (Vercel, Supabase) + Composio Tool Router for any other app |

## Stack lock (override only if the user names a replacement)

- Next.js App Router, TypeScript, Tailwind, shadcn/ui
- Vercel AI SDK (`ai`, `@ai-sdk/react`, `@ai-sdk/mcp`)
- Default model path: `gateway('anthropic/claude-sonnet-4.5')` via Vercel AI Gateway
- Optional first-party: `@ai-sdk/openai`, `@ai-sdk/anthropic`, `@ai-sdk/google`
- Supabase Auth + DB + Storage
- Stripe subscriptions + credits
- Composio `@composio/core` Tool Router for tenant-chosen toolkits
- Inngest for embed + long runs

Gateway is default because one key reaches OpenAI, Anthropic, Gemini, and others. Dedicated SDKs are for when the user must pin a vendor, use vendor-only features, or keep keys off the gateway. [docs]

## PAL then generate

1. Parse brief → write `site.config.ts` and `agents/<slug>/agent.yaml`.
2. Fill gaps with defaults: dark operator UI, 3 Stripe plans, Gateway broker, Composio opt-in per tenant.
3. Expand file tree, schema, MCP policy, provision scripts.
4. Compile complete files. No `TODO` on required routes.

## Agent directory (every agent you create)

```
agents/<slug>/
  soul.md
  agent.yaml
  skills/                 # Agent Skills (SKILL.md)
  scripts/                # typed functions the harness may run
  mcp/allowlist.yaml      # native + composio toolkit ids
  knowledge/.gitkeep      # seed docs; runtime lives in Supabase
  evals/cases.yaml
```

`agent.yaml` must declare: id, version, model_role, tool_allowlist, composio_toolkits, native_mcps, approval_triggers, memory namespace.

## Composio policy

Composio is the **any-app** layer, not a secret dump and not "enable everything."

- Create a Tool Router session **per authenticated user**: `composio.create(userId)`.
- Connect the session with `@ai-sdk/mcp` HTTP transport and `mcp.url`.
- Default toolkit set is empty. Tenant enables toolkits in `/app/settings/integrations`.
- Platform key `COMPOSIO_API_KEY` stays on the server. End users complete Composio OAuth for Gmail/Notion/GitHub/etc.
- Writes (send email, create ticket, deploy) require `approval_required: true` unless risk is `low`.
- Native first-party MCPs stay first-class for this stack: `vercel`, `supabase`. Do not proxy those through Composio unless the user asks.

Also support first-party skills: `npx skills add composiohq/skills` is optional for local CLI agents; the hosted app uses Tool Router.

## Provisioning

Scripts, not dashboard folklore:

- `scripts/setup-supabase.ts` — project link, apply migrations, create buckets `knowledge` and `outputs`, enable Google + magic-link providers.
- `scripts/setup-vercel.ts` — create/link project, pull/push env, preview deploy.
- `scripts/provision-agent.ts` — copy agent template, register in DB, seed default soul.

Production promote is denied until an approval record exists.

## Provider factory

`runtime/providers.ts` must support:

| Mode | When |
|---|---|
| `vercel-ai-gateway` | Default. String models like `anthropic/claude-sonnet-4.5` |
| `openai` | `@ai-sdk/openai` |
| `anthropic` | `@ai-sdk/anthropic` |
| `google` | `@ai-sdk/google` (Gemini) |
| `openrouter` | OpenAI-compatible fallback |
| `litellm` | Self-hosted OpenAI-compatible proxy |

UI never selects raw API keys. UI selects a **model role**. Server maps role → provider/model.

## Hard rules

- Complete files only.
- RLS on every tenant table.
- No provider keys, Composio platform keys, or service-role keys in client bundles.
- Side-effecting Vercel/Stripe/Composio writes need approval when risk ≠ low.
- Knowledge: upload → Storage → Inngest embed → retrieve tool. Never stuff whole corpora into prompts.
- Follow AWS Well-Architected: least privilege, health checks, retries, credit hard-stop, no idle GPU.

## Done means

- `pnpm lint && pnpm typecheck && pnpm test && pnpm build` documented
- User can sign in with Supabase OAuth, subscribe, open workspace, stream a reply
- User can connect a Composio toolkit and the next thread can call it
- Preview deploy exists; production deploy is gated
- A second agent site is `site.config.ts` + content + a new `agents/<slug>/`
