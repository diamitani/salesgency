# VectorShift Deal Intelligence Agent — Replit Luna Build Prompts
**Platform:** Replit Agent / Luna  
**Role:** Forward Deployed Engineer (FDE) Demonstration for VectorShift  
**Target Enterprise Client:** Mid-Market Private Equity Sponsor (e.g. Northline Capital / Buyout Fund)  
**Author:** Patrick Diamitani  
**Core Thesis:** Demonstrate how a VectorShift FDE builds and deploys an institutional deal-screening and memory-layer agent on the VectorShift platform using real market data (CS Disco / LAW).

---

## Architecture & System Overview

```
[ VectorShift Platform / Enterprise PE Tenant ]
                   │
                   ▼
       ┌───────────────────────┐
       │   PAL Intake Agent    │ ── (Multi-tenant isolation & run manifest)
       └───────────┬───────────┘
                   │
                   ▼
       ┌───────────────────────┐
       │ VectorShift Knowledge │ ── (SEC EDGAR MCP + Data Room Parser)
       │ Layer (Fact Cabinet)  │
       └───────────┬───────────┘
                   │
                   ▼
 ┌─────────────────────────────────────────────────────────────┐
 │        VectorShift Deterministic Rules Engine (TypeScript)   │
 │   • Evaluates Sponsor Investment Mandate against Filings   │
 │   • Gate 1: B2B Enterprise Software? (SIC 7372)             │
 │   • Gate 2: Revenue Quality & Volatility (92% Usage Risk)   │
 │   • Gate 3: Fund Size Sweet Spot ($25M - $250M Box)         │
 │   • Gate 4: Capital Efficiency & Cash Burn                  │
 │   • Gate 5: Services Drag & Margin Health                   │
 └─────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
       ┌───────────────────────┐
       │ VectorShift Synthesis │ ── (1-Page Monday Deal Screening Memo,
       │ Layer (LLM + Evals)   │     Citations to Accession URLs, Diligence Qs)
       └───────────┬───────────┘
                   │
                   ▼
       ┌───────────────────────┐
       │ Institutional Memory  │ ── (Compounds across deals: logs decision
       │ & Deal Ledger         │     rationale into VectorShift searchable archive)
       └───────────────────────┘
```

---

## Phase 1: Knowledge Base & VectorShift Platform Engine

### Prompt 1: Project Initialization & Knowledge Layer

```text
You are building an enterprise private markets AI application called "VectorShift Deal Intelligence Agent" for an interview demonstration with VectorShift founders (Alexander Leonardi and Marc Klein).

The application demonstrates how a Forward Deployed Engineer (FDE) at VectorShift configures VectorShift's AI Operating System for a Private Equity deal team to screen inbound opportunities (CIMs and 10-Ks), evaluate them against the fund's investment mandate, generate cited Monday screening memos, and preserve institutional deal memory.

Stack & Design Specifications:
- Framework: Next.js 15 (App Router), TypeScript, Tailwind CSS, lucide-react.
- Aesthetic: VectorShift Enterprise Portal — dark obsidian header (#0B0F19), slate borders, warm off-white workspace (#F8FAFC), institutional navy accents (#1E293B), emerald for Pass/Fit (#059669), amber for Watch (#D97706), and crimson for Reject/Pass (#DC2626).
- Design Principle: Two-layer architecture:
  1. Deterministic Rule Engine in TypeScript (evaluates fund criteria mathematically).
  2. Grounded LLM Synthesizer (generates cited 1-page Monday memos from verified facts).

Please create the baseline project structure with these exact files:

1. Create `knowledge/fund_mandate.json`:
{
  "platform": "VectorShift AI Operating System",
  "client_firm": "Mid-Market PE Sponsor (Fund IV)",
  "strategy": "Control Buyouts & Significant Minority Growth in Enterprise Software",
  "mandate_criteria": {
    "target_industry": "B2B Vertical Software & Tech-Enabled Services (SIC 7372)",
    "revenue_band_usd": { "min": 25000000, "max": 250000000 },
    "min_organic_growth_pct": 10.0,
    "min_gross_margin_pct": 50.0,
    "max_acceptable_usage_revenue_pct": 40.0,
    "require_positive_operating_cash_flow": true
  },
  "vectorshift_capabilities": [
    "VDR & CIM Document Processing",
    "Audited SEC EDGAR XBRL Data Ingestion",
    "Institutional Memory & Deal Triage Archiving",
    "Automated Investment Committee Memo Scaffolding"
  ]
}

2. Create `knowledge/cs_disco_facts.json` containing audited SEC filings for CS Disco, Inc. (NYSE: LAW, CIK 0001612630):
{
  "entity": {
    "name": "CS Disco, Inc.",
    "ticker": "LAW",
    "exchange": "NYSE",
    "cik": "0001612630",
    "sic": "7372",
    "sector": "Legal Technology / Litigation SaaS",
    "hq": "Austin, Texas"
  },
  "financials_fy2025": {
    "total_revenue_usd": 156800000,
    "total_revenue_growth_pct": 8.0,
    "software_revenue_usd": 134000000,
    "software_revenue_growth_pct": 12.0,
    "adjusted_ebitda_usd": -10200000,
    "operating_cash_flow_usd": -14900000,
    "liquid_cash_and_sti_usd": 114600000,
    "source": "SEC Form 8-K, filed Feb 25, 2026",
    "url": "https://www.sec.gov/Archives/edgar/data/1612630/000161263026000015/law-20251231.htm"
  },
  "financials_q2_2026": {
    "quarterly_revenue_usd": 43146000,
    "quarterly_revenue_growth_pct": 13.2,
    "usage_based_revenue_pct": 92.0,
    "subscription_based_revenue_pct": 8.0,
    "gaap_gross_margin_pct": 74.4,
    "non_gaap_gross_margin_pct": 76.0,
    "adjusted_ebitda_usd": -3406000,
    "h1_operating_cash_flow_usd": -12757000,
    "period_end_liquid_cash_usd": 101394000,
    "installed_base_delta_usd": -900000,
    "new_logos_delta_usd": 5900000,
    "large_customers_over_100k": 354,
    "source": "SEC Form 10-Q, filed Aug 5, 2026",
    "url": "https://www.sec.gov/Archives/edgar/data/1612630/000161263026000042/law-20260630.htm"
  }
}

3. Create `lib/vectorshift_engine.ts`:
Implement `evaluateTarget(companyData, fundMandate)`:
- Gate 1: `b2b_software_sector` -> PASS (SIC 7372)
- Gate 2: `revenue_scale_box` -> PASS ($156.8M FY25 revenue sits in $25M–$250M target band)
- Gate 3: `growth_quality` -> WATCH/FAIL (Total FY25 revenue grew 8.0% vs 10% mandate, software grew 12%, H1 2026 grew 13.7%)
- Gate 4: `gross_margin_health` -> PASS (76.0% Non-GAAP gross margin exceeds 50% floor)
- Gate 5: `revenue_predictability` -> FAIL (92% usage-based / 8% subscription creates matter volatility)
- Gate 6: `cash_flow_efficiency` -> FAIL (Burned $(14.9)M in FY25, $(12.8)M in H1 2026)
Final Decision: "WATCH" (Meets sector and size scale, but flags critical usage volatility and cash burn diligence risks).

Confirm when these files are created and typed properly.
```

---

## Phase 2: VectorShift Backend & Connected API Layer

### Prompt 2: API Endpoints & Grounded Chat Router

```text
Build the backend API routes connecting the frontend to VectorShift's deal intelligence engine:

1. Create `app/api/vectorshift/screen/route.ts`:
- Accepts POST request with `{ ticker: "LAW", mandate_id: "fund_iv" }`.
- Executes `lib/vectorshift_engine.ts` against `knowledge/cs_disco_facts.json` and `knowledge/fund_mandate.json`.
- Emits a rich JSON response:
  {
    "session": {
      "platform": "VectorShift Deal Intelligence v2.4",
      "firm": "VectorShift Client · Fund IV",
      "run_id": "vs_run_law_" + Date.now(),
      "target": "CS Disco, Inc. (NYSE: LAW)",
      "cik": "0001612630",
      "timestamp": new Date().toISOString()
    },
    "scorecard": {
      "decision": "WATCH",
      "summary": "Advance to management call to probe revenue quality; do not draft formal IC approval memo yet. Asset fits $25M–$250M software scale, but 92% usage mix and ongoing cash burn require diligence.",
      "gates": [...all 6 gates with threshold, metric, status, and audit notes...]
    },
    "monday_memo": {
      "headline": "VectorShift Monday Screening Brief: CS Disco (NYSE: LAW)",
      "thesis": "High-margin (76%) legal tech platform ($156.8M FY25 rev) in Fund IV sweet spot. Sits on the line between high-margin software and volatile matter-driven usage.",
      "growth_diligence": "In Q2 2026, existing customer expansion was $(0.9)M despite +$5.9M in new customer additions. Key question: Are legacy matters churning as lawsuits close?",
      "key_questions": [
        "What percentage of the 92% usage revenue is anchored by contracted annual minimum commitments?",
        "What was the actual dollar contribution of Cecilia AI in FY2025 and Q2 2026?",
        "What specific quarterly runway Milestone brings Adjusted EBITDA from $(8)M to breakeven?"
      ],
      "return_refusal": "IRR and MOIC projections are not computed. VectorShift protocol prohibits hallucinating entry multiples without a signed Letter of Intent (LOI) and capitalization table."
    },
    "institutional_memory_log": {
      "status": "Archived in VectorShift Firm Memory",
      "tag": "LegalTech / Litigation SaaS / 92% Usage",
      "prior_comparables": ["Relativity (Privately Held)", "Everlaw (VC-backed)", "Exterro (PE-backed)"]
    }
  }

2. Create `app/api/vectorshift/chat/route.ts`:
- Handle conversational Q&A from deal partners.
- If asked "What is the projected IRR/MOIC?", return:
  "VectorShift Deal Engine Refusal: Projected IRR and MOIC cannot be calculated without an entry purchase price, debt financing structure, and exit multiple assumption. VectorShift policy strictly prohibits hallucinating financial return models."
- If asked about revenue, margins, cash runway, or growth levers, answer strictly from `knowledge/cs_disco_facts.json` and cite SEC Form 8-K or 10-Q accession sources.

Ensure both routes are compiled and return valid JSON.
```

---

## Phase 3: VectorShift Institutional Executive Frontend UI

### Prompt 3: Enterprise Split-Screen Workspace

```text
Build the interactive VectorShift deal dashboard in `app/page.tsx` with clean modular components.

Design Specifications:
1. Top Navigation Bar:
   - Left: VectorShift Logo mark + "VectorShift · AI Operating System for Private Markets".
   - Subtitle: "Forward Deployed Deal Intelligence Agent · Client: PE Growth & Buyout Fund IV".
   - Right: "SOC 2 Type II Certified · Single-Tenant VPC · SEC EDGAR Live Feed".

2. Top Navigation Tabs:
   - "Deal Triage (Live Screen)"
   - "Institutional Memory Layer"
   - "Audited SEC Filings"
   - "VectorShift Agent Soul (`SOUL.md`)"

3. Main Split-Pane Workspace:
   - Left Pane (40% width): VectorShift Interactive Deal Partner Console:
     * Pre-configured Partner Prompts:
       - "Run VectorShift Screen (LAW)"
       - "Why is this a Watch?"
       - "Explain 92% Usage Volatility"
       - "Probe Customer Cohort Churn"
       - "Compute Fund IV IRR" (Triggers safe refusal)
     * Conversational feed showing user questions, VectorShift agent responses with skill badge (`vectorshift:screen`, `vectorshift:diligence`, `vectorshift:refuse`), and inline SEC filing citations.
     * Bottom input box for custom partner queries.

   - Right Pane (60% width): VectorShift Monday Deal Pack & Scorecard:
     * Top Decision Banner: Amber/Gold theme for "DECISION: WATCH — Schedule Management Diligence Call (Do Not Write Full IC Memo)".
     * Mandate Scorecard Table: Gate Name, Fund Target, CS Disco Metric, Status (Green Pass / Amber Watch / Red Fail), and VectorShift Audit Notes.
     * Cohort & Growth Diagnostic Card: Highlights New Customer additions (+$5.9M) vs Existing Customer Churn (-$0.9M) in Q2 2026.
     * Monday Partner Brief: Formatted executive memo with Key Diligence Questions.
     * Sourced Citations Box: Clickable links directly to official SEC EDGAR 10-Q/8-K accessions.

Ensure the dashboard is responsive, loads cleanly on Replit, and is populated with CS Disco data on startup.
```

---

## Phase 4: Polish, Audit Ledger & Interview Verification

### Prompt 4: Audit Verification & ROSTR Inspection Tabs

```text
Finalize the web application for an executive presentation to Alexander Leonardi and Marc Klein:

1. Interactive Tabs Implementation:
   - "Institutional Memory Layer" Tab: Displays how VectorShift logs and indexes deal triage decisions, enabling partners to search prior deal comparables and never re-underwrite the same pass twice.
   - "Audited SEC Filings" Tab: Shows the raw structured JSON facts from Form 8-K and 10-Q with links to official SEC EDGAR URLs.
   - "VectorShift Agent Soul" Tab: Renders the formatted `SOUL.md` and skills specification showing the ROSTR agent architecture (Identity, Mission, Deterministic Guardrails, Tool Schemas, Evals).

2. Verification & Safety Checks:
   - Clicking "Compute Fund IV IRR" returns VectorShift's safety refusal explaining that return math requires a real entry valuation.
   - Clicking any SEC citation link opens the verified SEC EDGAR filing.
   - Add a footer: "VectorShift Forward Deployed Engineer Demo · Author: Patrick Diamitani · The AI Operating System for Private Market Investors."

Run the build, test all routes, and confirm that the app is live and fully interactive on the Replit preview window.
```

---

## What This Proves to VectorShift

Running these 4 prompts in Replit gives you a live application that directly demonstrates the Forward Deployed Engineer role:

1. **Client-Facing Presence:** Shows how a VectorShift FDE sits with a PE deal partner on day one and delivers a working, cited screening agent.
2. **Productizing the Last Mile:** Demonstrates turning messy SEC filings and CIMs into reusable, structured templates.
3. **Institutional Credibility:** Proves you understand how PE deal teams think, why deterministic rule gates prevent hallucination, and how VectorShift compounds institutional memory across deals.
