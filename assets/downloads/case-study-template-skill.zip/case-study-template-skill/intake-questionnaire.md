# Case Study Intake Questionnaire

Send this to the client (or work through it on a call) before drafting.
Get answers in writing — verbal numbers drift.

## The basics

1. Company name, industry, size (employees or revenue band)?
2. Who was the buyer (name, title)? Who else touched the decision?
3. What exactly did you deliver (scope in one paragraph)?
4. Timeline: when did the work start and end?

## The before

5. What was broken or painful before? (Ask for a scene, not an
   adjective: "what did a bad Tuesday look like?")
6. What had they already tried that didn't work?
7. What would have happened if they'd done nothing?

## The after

8. What changed, in numbers? (Revenue, time, cost, conversion — with
   before AND after values.)
9. What changed that can't be numbered? (Morale, confidence, speed —
   ask for a concrete moment.)
10. What did the client say, in their own words? (Push for a quotable
    sentence; paraphrase is not a quote.)

## Proof and permission

11. Which numbers may we publish? (Get explicit yes/no per number.)
12. May we name the company and the people quoted?
13. Who approves the final draft, and what's their turnaround?
14. Is there a customer logo file we should use?

## The close

15. What should a reader do next? (Book a call, start a trial, reply —
    one action.)
16. What's the one sentence the reader should remember?

## Red flags

- "Just make the numbers sound good" → stop. No invented metrics.
- No named approver → the draft will die in review limbo. Get the name.
- Client won't go on record → write it as an anonymized study or don't
  write it.
