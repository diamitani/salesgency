# PAL Depth Guide

How deep the intake analysis goes before writing a word of the case
study. PAL = Parse, Ambiguity Scan, Latent Intent, Expand, Compile.

## Parse

Read the raw material once without annotating. Then list: who is the
client, what did they buy/hire, what changed, what numbers exist. If
any of the four is missing, that's the first intake question.

## Ambiguity Scan

Flag every vague claim: "improved efficiency", "great results",
"significant growth". Each flagged claim needs either a number or a
concrete scene — "deploys went from Friday-afternoon dread to a
non-event" is a scene; "10x better" is neither.

## Latent Intent

Ask what the case study is FOR: closing enterprise deals, justifying a
renewal, recruiting, or portfolio credibility. The intent decides the
structure — a sales case study leads with ROI; a portfolio piece leads
with craft.

## Expand

For each thin area, generate the specific intake questions (see the
intake questionnaire). Don't write around gaps; go get the answers.

## Compile

Produce the case-study brief: one page with the narrative spine (3
acts), the verified numbers, the quotes with attribution, and the
approved call to action. The brief is what the writer works from — the
writer never improvises facts.

## Depth levels

- **Level 1 (one-pager):** Parse + Compile only. For short testimonial
  style pieces.
- **Level 2 (standard):** full PAL, one intake round. The default.
- **Level 3 (flagship):** full PAL, two intake rounds, client review of
  the brief before drafting. For homepage case studies.
