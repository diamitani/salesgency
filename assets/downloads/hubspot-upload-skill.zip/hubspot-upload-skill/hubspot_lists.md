# HubSpot Lists Reference

How the uploader builds lists, and how to use ILS (inclusion-list-sync)
filter branches for active lists.

## List types

| Type | HubSpot `processingType` | Behavior |
|------|--------------------------|----------|
| Static | `MANUAL` | Snapshot — records added once, membership frozen |
| Active | `DYNAMIC` | Filter-based — membership re-evaluates as records change |

The uploader defaults to static lists named `<batch-id> contacts` /
`<batch-id> companies`. List URLs look like:

`https://app.hubspot.com/contacts/{portalId}/objectLists/{listId}`

## Creating a list (what the script does)

```http
POST /crm/v3/lists
{
  "name": "2026-09-15-batch1 contacts",
  "objectTypeId": "0-1",
  "processingType": "MANUAL"
}
```

`objectTypeId` is `0-1` for contacts, `0-2` for companies. If the name is
taken, the script retries once with a timestamp suffix.

## Adding members

```http
PUT /crm/v3/lists/{listId}/memberships/add
{"recordIds": ["123", "456"]}
```

If `PUT` fails on a tenant, the script retries with `POST`. Records are
added 100 at a time.

## Active-list filter branches (`--filter-branch`)

For `--list-type active`, pass a JSON filter branch describing who belongs.
HubSpot filter-branch shape:

```json
{
  "filterBranchType": "OR",
  "filters": [
    {"property": "lifecyclestage", "operation": {"operator": "EQ", "value": "marketingqualifiedlead"}},
    {"property": "city", "operation": {"operator": "EQ", "value": "Chicago"}}
  ],
  "filterBranches": []
}
```

- `filterBranchType` is `AND` or `OR`.
- `filters` entries use `property` + `operation.operator` + `operation.value`.
  Common operators: `EQ`, `NEQ`, `IS_KNOWN`, `IS_UNKNOWN`, `CONTAINS`,
  `GT`, `LT`.
- Nest groups under `filterBranches` for mixed logic.

Example — active list of MQLs in Chicago:

```bash
python scripts/hubspot_upload.py --file import.csv --batch-id b1 \
  --list-type active \
  --filter-branch '{"filterBranchType":"AND","filters":[
    {"property":"lifecyclestage","operation":{"operator":"EQ","value":"marketingqualifiedlead"}},
    {"property":"city","operation":{"operator":"EQ","value":"Chicago"}}]}'
```

If `--filter-branch` is omitted for an active list, the script builds a
catch-all filter so the uploaded records are captured.

## Required scopes

Lists need the lists read/write scope on the private app, alongside the
contacts/companies read/write scopes.
