#!/usr/bin/env python3
"""Upload formatted contact/company records into HubSpot and build lists.

Usage:
    python scripts/hubspot_upload.py --batch-id 2026-09-15-batch1 --file import.csv
    python scripts/hubspot_upload.py --batch-id b1 --file import.xlsx --only contacts --dry-run

Input: a CSV or .xlsx whose header row uses the template column names from
SKILL.md ("Email", "First Name", ..., "Company Domain Name", ...). A column
named "Record Type" (values: contact | company) may mix both; otherwise use
--only to pick one type for the whole file.

Auth: HUBSPOT_PAT env var, or a KEY=VALUE file at
~/.hubspot-upload/hubspot.env (user-owned, git-ignored, ships no secret).

Behavior (see SKILL.md for the full contract):
  - Fetches the portal's real property definitions; sends only properties
    that exist; validates enum values; coerces numerics.
  - Contacts: batch upsert with idProperty=email.
  - Companies: search-then-update/create by domain (HubSpot's own importer
    dedupe behavior), because domain is usually not a unique property.
  - Creates one static (MANUAL) list per object type named after the batch
    id, adds the records, prints the list links.

Requires: requests (pip install requests). openpyxl only for .xlsx input.
"""

import argparse
import csv
import json
import os
import re
import sys
import time

BASE = "https://api.hubapi.com"
ENV_FILE = os.path.expanduser("~/.hubspot-upload/hubspot.env")

CONTACT_COLUMNS = {
    "Email": "email", "First Name": "firstname", "Last Name": "lastname",
    "Phone Number": "phone", "Mobile Phone Number": "mobilephone",
    "Job Title": "jobtitle", "Company Name": "company",
    "Lead Status": "hs_lead_status", "Lifecycle Stage": "lifecyclestage",
    "Country/Region": "country", "State/Region": "state", "City": "city",
    "LinkedIn URL": "hs_linkedin_url",
}
COMPANY_COLUMNS = {
    "Company Name": "name", "Company Domain Name": "domain",
    "Industry": "industry", "Number of Employees": "numberofemployees",
    "City": "city", "State/Region": "state", "Country/Region": "country",
    "LinkedIn Company Page": "linkedin_company_page",
}
# HubSpot industry option -> (NAICS 2-digit, sector label)
NAICS = {
    "AGRICULTURE": ("11", "Agriculture, Forestry, Fishing and Hunting"),
    "MINING": ("21", "Mining, Quarrying, and Oil and Gas Extraction"),
    "UTILITIES": ("22", "Utilities"),
    "CONSTRUCTION": ("23", "Construction"),
    "MANUFACTURING": ("31", "Manufacturing"),
    "MACHINERY": ("33", "Manufacturing"),
    "CHEMICALS": ("32", "Manufacturing"),
    "WHOLESALE": ("42", "Wholesale Trade"),
    "RETAIL": ("44", "Retail Trade"),
    "SHIPPING": ("48", "Transportation and Warehousing"),
    "TRANSPORTATION": ("48", "Transportation and Warehousing"),
    "COMPUTER_SOFTWARE": ("51", "Information"),
    "INTERNET": ("51", "Information"),
    "COMMUNICATIONS": ("51", "Information"),
    "TELECOMMUNICATIONS": ("51", "Information"),
    "MEDIA": ("51", "Information"),
    "ENTERTAINMENT": ("71", "Arts, Entertainment, and Recreation"),
    "RECREATION": ("71", "Arts, Entertainment, and Recreation"),
    "BANKING": ("52", "Finance and Insurance"),
    "FINANCE": ("52", "Finance and Insurance"),
    "INSURANCE": ("52", "Finance and Insurance"),
    "CONSULTING": ("54", "Professional, Scientific, and Technical Services"),
    "ENGINEERING": ("54", "Professional, Scientific, and Technical Services"),
    "BIOTECHNOLOGY": ("54", "Professional, Scientific, and Technical Services"),
    "ENVIRONMENTAL": ("54", "Professional, Scientific, and Technical Services"),
    "EDUCATION": ("61", "Educational Services"),
    "HEALTHCARE": ("62", "Health Care and Social Assistance"),
    "HOSPITALITY": ("72", "Accommodation and Food Services"),
    "FOOD_BEVERAGE": ("72", "Accommodation and Food Services"),
    "GOVERNMENT": ("92", "Public Administration"),
    "NOT_FOR_PROFIT": ("81", "Other Services"),
    "APPAREL": ("31", "Manufacturing"),
    "ELECTRONICS": ("33", "Manufacturing"),
    "ENERGY": ("22", "Utilities"),
}
COUNTRY_FIX = {"US": "United States", "USA": "United States",
               "UK": "United Kingdom"}


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def load_token():
    token = os.environ.get("HUBSPOT_PAT", "").strip()
    if token:
        return token
    if os.path.exists(ENV_FILE):
        for line in open(ENV_FILE, encoding="utf-8"):
            line = line.strip()
            if line.startswith("HUBSPOT_PAT="):
                return line.split("=", 1)[1].strip().strip("'\"")
    die("no token: set HUBSPOT_PAT or create " + ENV_FILE +
        " containing HUBSPOT_PAT=<your-private-app-token>")


def req(method, path, token, body=None, params=None):
    import requests
    for attempt in range(3):
        r = requests.request(method, BASE + path,
                             headers={"Authorization": f"Bearer {token}",
                                      "Content-Type": "application/json"},
                             json=body, params=params, timeout=30)
        if r.status_code == 429:
            time.sleep(2 ** attempt)
            continue
        if r.status_code >= 400:
            die(f"{method} {path} -> HTTP {r.status_code}: {r.text[:300]}")
        return r.json() if r.text else {}
    die(f"{method} {path} -> rate limited after retries")


def read_rows(path):
    if path.lower().endswith(".xlsx"):
        try:
            import openpyxl
        except ImportError:
            die("openpyxl is required for .xlsx input: pip install openpyxl")
        ws = openpyxl.load_workbook(path, read_only=True).active
        rows = list(ws.iter_rows(values_only=True))
        headers = [str(h).strip() if h is not None else "" for h in rows[0]]
        return [dict(zip(headers, [(str(c).strip() if c is not None else "")
                                   for c in row])) for row in rows[1:]]
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def get_properties(object_type, token):
    defs = req("GET", f"/crm/v3/properties/{object_type}", token,
               params={"limit": 100})["results"]
    return {d["name"]: d for d in defs}


def enum_ok(prop_def, value):
    options = {o["value"] for o in prop_def.get("options", [])}
    labels = {o["label"].lower(): o["value"] for o in prop_def.get("options", [])}
    if value in options:
        return value
    return labels.get(value.lower())


def build_properties(row, colmap, prop_defs, naics=False):
    props = {}
    for col, hs_name in colmap.items():
        val = (row.get(col) or "").strip()
        if not val or hs_name not in prop_defs:
            continue
        pdef = prop_defs[hs_name]
        ftype = pdef.get("fieldType", "")
        if ftype == "number":
            digits = re.sub(r"\D", "", val)
            if digits:
                props[hs_name] = digits
        elif pdef.get("options"):
            if hs_name == "country":
                val = COUNTRY_FIX.get(val.upper(), val)
            mapped = enum_ok(pdef, val)
            if mapped:
                props[hs_name] = mapped
            # else: drop the value rather than failing the batch
        else:
            props[hs_name] = val
    if naics and "industry" in props:
        code_label = NAICS.get(props["industry"])
        if code_label and "industry___naics_code__2_digit_" in prop_defs:
            code, label = code_label
            props["industry___naics_code__2_digit_"] = code
            props["industry___naics_label___2_digit_"] = label
    return props


def chunks(lst, n):
    return [lst[i:i + n] for i in range(0, len(lst), n)]


def upsert_contacts(rows, prop_defs, token, dry_run):
    """Batch upsert by email (unique property). Returns list of record ids."""
    inputs = [{"idProperty": "email", "id": (r.get("Email") or "").strip(),
               "properties": build_properties(r, CONTACT_COLUMNS, prop_defs)}
              for r in rows if (r.get("Email") or "").strip()]
    ids = []
    for batch in chunks(inputs, 100):
        if dry_run:
            print(f"[dry-run] would upsert {len(batch)} contacts")
            continue
        try:
            res = req("POST", "/crm/v3/objects/contacts/batch/upsert", token,
                      {"inputs": batch})
            ids += [x["id"] for x in res.get("results", [])]
        except SystemExit:
            # Retry each record individually so one bad row can't block the batch
            print("batch failed; retrying records individually...", file=sys.stderr)
            for item in batch:
                try:
                    res = req("POST", "/crm/v3/objects/contacts/batch/upsert",
                              token, {"inputs": [item]})
                    ids += [x["id"] for x in res.get("results", [])]
                except SystemExit as e:
                    print(f"record {item['id']} failed: {e}", file=sys.stderr)
                    raise SystemExit(1)
    return ids


def search_companies_by_domain(domains, token):
    found = {}
    for batch in chunks(list(domains), 100):
        res = req("POST", "/crm/v3/objects/companies/search", token, {
            "filterGroups": [{"filters": [{
                "propertyName": "domain", "operator": "IN", "values": batch}]}],
            "properties": ["domain"], "limit": 100})
        for c in res.get("results", []):
            d = (c["properties"].get("domain") or "").lower()
            if d:
                found[d] = c["id"]
    return found


def upsert_companies(rows, prop_defs, token, dry_run):
    """Search-then-update/create by domain. Returns list of record ids."""
    domains = {(r.get("Company Domain Name") or "").strip().lower()
               for r in rows} - {""}
    existing = {} if dry_run else search_companies_by_domain(domains, token)
    to_update, to_create = [], []
    for r in rows:
        props = build_properties(r, COMPANY_COLUMNS, prop_defs, naics=True)
        domain = (r.get("Company Domain Name") or "").strip().lower()
        if domain in existing:
            to_update.append({"id": existing[domain], "properties": props})
        else:
            to_create.append({"properties": props})
    ids = []
    for batch in chunks(to_update, 100):
        if dry_run:
            print(f"[dry-run] would update {len(batch)} companies");
            continue
        res = req("POST", "/crm/v3/objects/companies/batch/update", token,
                  {"inputs": batch})
        ids += [x["id"] for x in res.get("results", [])]
    for batch in chunks(to_create, 100):
        if dry_run:
            print(f"[dry-run] would create {len(batch)} companies");
            continue
        res = req("POST", "/crm/v3/objects/companies/batch/create", token,
                  {"inputs": batch})
        ids += [x["id"] for x in res.get("results", [])]
    return ids


def create_list(object_type, name, list_type, filter_branch, token, dry_run):
    """Create a list; returns (list_id, link)."""
    if list_type == "active":
        body = {"name": name, "objectTypeId": "0-1" if object_type == "contacts" else "0-2",
                "processingType": "DYNAMIC",
                "filterBranch": filter_branch or {
                    "filterBranchType": "OR",
                    "filters": [{"property": "hs_object_id",
                                 "operation": {"operator": "IS_KNOWN"}}]}}
    else:
        body = {"name": name, "objectTypeId": "0-1" if object_type == "contacts" else "0-2",
                "processingType": "MANUAL"}
    if dry_run:
        print(f"[dry-run] would create {list_type} list '{name}'")
        return None, None
    try:
        res = req("POST", "/crm/v3/lists", token, body)
    except SystemExit:
        # Name clash -> retry once with a time suffix
        body["name"] = f"{name} {time.strftime('%Y%m%d-%H%M%S')}"
        res = req("POST", "/crm/v3/lists", token, body)
    return res["listId"], res.get("links", {}).get("list")


def add_memberships(list_id, record_ids, token, dry_run):
    for batch in chunks(record_ids, 100):
        if dry_run:
            print(f"[dry-run] would add {len(batch)} records to list {list_id}");
            continue
        try:
            req("PUT", f"/crm/v3/lists/{list_id}/memberships/add", token,
                {"recordIds": batch})
        except SystemExit:
            req("POST", f"/crm/v3/lists/{list_id}/memberships/add", token,
                {"recordIds": batch})


def portal_id(token):
    import requests
    r = requests.get(BASE + "/account-info/v3/details",
                     headers={"Authorization": f"Bearer {token}"}, timeout=30)
    if r.status_code == 200:
        return r.json().get("portalId")
    return None


def main():
    ap = argparse.ArgumentParser(description="Upload records to HubSpot + build lists")
    ap.add_argument("--file", required=True, help="CSV or .xlsx in the import template format")
    ap.add_argument("--batch-id", required=True, help="names the list(s); aligns with the KPI ledger")
    ap.add_argument("--only", choices=["contacts", "companies"])
    ap.add_argument("--list-name", help="base list name (object type appended)")
    ap.add_argument("--list-description", default="")
    ap.add_argument("--list-type", choices=["static", "active"], default="static")
    ap.add_argument("--filter-branch", help="JSON ILS filter for active lists")
    ap.add_argument("--no-list", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    token = None if args.dry_run else load_token()
    rows = [r for r in read_rows(args.file) if any((v or "").strip() for v in r.values())]
    print(f"read {len(rows)} non-empty rows from {args.file}")

    def rtype(r):
        t = (r.get("Record Type") or "").strip().lower()
        if t.startswith("comp"):
            return "companies"
        if t.startswith("cont"):
            return "contacts"
        return args.only or "contacts"

    result = {}
    for object_type in (["contacts", "companies"] if not args.only else [args.only]):
        subset = [r for r in rows if rtype(r) == object_type]
        if not subset:
            continue
        prop_defs = {} if args.dry_run else get_properties(object_type, token)
        if object_type == "contacts":
            ids = upsert_contacts(subset, prop_defs, token, args.dry_run)
        else:
            ids = upsert_companies(subset, prop_defs, token, args.dry_run)
        print(f"{object_type}: {len(ids)} records written"
              + (" (dry-run)" if args.dry_run else ""))
        link = None
        if not args.no_list and (ids or args.dry_run):
            base = args.list_name or args.batch_id
            name = f"{base} {object_type}"
            fb = json.loads(args.filter_branch) if args.filter_branch else None
            list_id, _ = create_list(object_type, name, args.list_type, fb,
                                    token, args.dry_run)
            if list_id:
                add_memberships(list_id, ids, token, args.dry_run)
                pid = portal_id(token)
                link = (f"https://app.hubspot.com/contacts/{pid}/objectLists/{list_id}"
                        if pid else f"listId={list_id}")
                print(f"list '{name}': {link}")
        result[object_type] = {"records": len(ids), "list": link,
                               "description": args.list_description}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
