# Amplemarket API Reference

Amplemarket exposes a REST API for contacts, sequences, and campaigns.
Auth: API key in the `Authorization` header (create it in Amplemarket →
Settings → Integrations/API). Endpoint paths follow Amplemarket's developer
documentation — confirm exact paths there before building, as they change.

## Core operations (pattern)

```http
POST /contacts              # create/update a contact (email is the dedupe key)
GET  /contacts              # list/search contacts
POST /sequences/{id}/enroll # enroll a contact in a sequence
GET  /sequences             # list sequences and campaigns
```

## Typical Python pattern

```python
import os, requests
BASE = "https://api.amplemarket.com"   # confirm against current developer docs
H = {"Authorization": f"Bearer {os.environ['AMPLEMARKET_API_KEY']}",
     "Content-Type": "application/json"}

def am_post(path, payload):
    r = requests.post(BASE + path, headers=H, json=payload, timeout=30)
    r.raise_for_status()
    return r.json()
```

## Enrollment hygiene

1. **Never enroll without a verified email.** Use the "safe to send" flag
   from the Clay table (see `clay-columns.md`).
2. **One active sequence per contact.** Check current enrollments before
   adding someone to a new sequence.
3. **Suppression lists first.** Sync unsubscribes/bounces from Amplemarket
   back to HubSpot so re-enrichment doesn't resurrect dead contacts.
4. **Bulk operations** are for initial loads; ongoing sync goes through n8n
   so failures are visible in executions.
