# Factors.ai → HubSpot Sync Reference

How intent data flows from Factors.ai into HubSpot companies, and how to
debug it when the sync stalls. The write path is the HubSpot API directly
(private-app token), not Clay.

## The sync path

1. **Factors.ai** — An intent workflow fires (e.g. target account visits
   the pricing page).
2. **Factors.ai** — The `hubspot_update` action matches the HubSpot company
   by `domain` and writes intent fields (workflow name, trigger time into
   `factors_abm__workflow_date`).
3. **HubSpot** — Company record now carries recency + intent; lists and
   workflows in HubSpot react (owner notification, sequence enrollment).

## Prerequisites

- HubSpot private app with `crm.objects.companies.read/write`.
- Custom company property `factors_abm__workflow_date` (datetime) exists in
  HubSpot.
- Every Factors workflow that writes to HubSpot uses `match_on: "domain"`.

## Debugging checklist

1. Confirm the account exists in Factors with a domain set.
2. Confirm the HubSpot company exists with the same domain.
3. Confirm the workflow is `active` and its `hubspot_update` action has
   `match_on: "domain"`.
4. Confirm the Factors → HubSpot integration shows connected.
5. Confirm field mapping includes `factors_abm__workflow_date`.
6. Check workflow execution history for the account's domain.

Read-only API checks for steps 1, 4, 5, and 6:

```http
GET /v1/accounts?domain=EXAMPLE_DOMAIN
GET /v1/integrations/hubspot
GET /v1/integrations/hubspot/field_mapping
GET /v1/workflows/{id}/executions?account_domain=EXAMPLE_DOMAIN
```

## Common failure modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| Nothing writes, no errors | `match_on` is not `"domain"` | Fix the workflow action config |
| 401 from Factors | Key missing/expired/scope | Regenerate in Factors.ai dashboard |
| 404 on an endpoint | Versioned endpoint | Retry with the `/v1/` prefix |
| Field missing in HubSpot | Custom property not created | Create `factors_abm__workflow_date` in HubSpot Settings → Properties |
