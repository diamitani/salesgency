# Clay API Reference

Base URL: `https://api.clay.com` — API versioning follows Clay's public API
docs. Auth: `Authorization: Bearer <CLAY_API_KEY>` (create the key in
Clay → Settings → API). Confirm exact endpoint paths against Clay's current
API documentation before building — vendor APIs change.

## Core operations

```http
GET  /v3/tables                      # list tables in the workspace
GET  /v3/tables/{tableId}            # table metadata + columns
GET  /v3/tables/{tableId}/records    # read rows (paginated)
POST /v3/tables/{tableId}/records    # insert rows
PATCH /v3/tables/{tableId}/records   # update rows by record id
```

## Typical Python pattern

```python
import os, requests
BASE = "https://api.clay.com/v3"
H = {"Authorization": f"Bearer {os.environ['CLAY_API_KEY']}"}

def clay_get(path, params=None):
    r = requests.get(BASE + path, headers=H, params=params, timeout=30)
    r.raise_for_status()
    return r.json()
```

## Webhooks

Clay tables can fire webhooks on row changes (Table → ⋯ → Webhooks). Point
the webhook at your n8n webhook URL so new enriched rows trigger downstream
flows. The payload carries the table id and the changed row's record id —
re-fetch the full row via the API before acting on it.

## Limits and hygiene

- Paginate record reads; don't pull a 100k-row table in one call.
- Enrichment runs cost Clay credits — filter rows in n8n/HubSpot before
  pushing bulk lists into Clay.
- Treat the API key like a password: env var only, never in chat or files.
