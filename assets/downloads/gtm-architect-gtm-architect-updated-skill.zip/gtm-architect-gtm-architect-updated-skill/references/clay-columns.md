# Clay Columns Reference

How to configure the enrichment columns that do the heavy lifting inside a
Clay table. Column types below are Clay product concepts — exact labels can
shift in the UI, so match by behavior.

## Enrichment column types

| Column | What it does | Configure with |
|--------|--------------|----------------|
| **Waterfall enrichment** | Tries data providers in order until one returns a value (e.g. work email, phone, LinkedIn URL) | Provider order, fallback rules, confidence threshold |
| **HTTP API** | Calls any REST endpoint per row, maps JSON response into columns | URL template with `{{column}}` variables, method, headers, response mapping |
| **Claygent (AI agent)** | Researches the row's company/person with web browsing and returns structured fields | Research prompt, output schema, max steps |
| **AI formula** | Generates a value per row from a prompt (personalization lines, summaries, categorization) | Prompt referencing other columns, model choice |
| **Find people / Find companies** | Prospecting sources that add new rows | Search criteria, result limits, dedupe keys |

## Column hygiene rules

1. **One fact per column.** Don't pack "email + verified flag + source" into
   one AI column — split it so downstream tools can filter reliably.
2. **Dedupe keys first.** Before enrichment, add a normalized domain column
   (lowercase, strip `www.`) and dedupe on it.
3. **Verify before push.** Never push a Clay table to HubSpot/Amplemarket
   without a "safe to send" boolean column (email verified OR phone present,
   not a generic `info@` address).
4. **Cost control.** Waterfalls and Claygent calls cost credits — run them
   on filtered subsets, and cache results in the table instead of
   re-enriching.

## Common column recipes

- **Normalized domain:** AI formula — lowercase the website, strip protocol
  and `www.`.
- **ICP fit score:** AI formula — score 1–5 against the ICP definition in
  the company knowledge file; output just the number.
- **Personalized first line:** AI formula — one sentence referencing a
  real, recent company fact from the Claygent research column. Ban
  compliments and generic claims.
