# Mermaid Diagrams — GTM Reference

Diagram recipes for each audience. Save diagrams as `.mermaid` files in the
outputs folder so they can be rendered or embedded.

## Audience → diagram type

| Audience | Use | Avoid |
|----------|-----|-------|
| ELT / executives | Flowchart with subgraphs per owner, Gantt timeline, quadrant matrix | Sequence diagrams, state diagrams |
| Engineers / RevOps | Sequence diagram, state diagram | Mind maps |
| GTM team | Process flowchart, journey map, mind map | Gantt (too detailed) |

## Flowchart (system overview)

```mermaid
flowchart LR
    subgraph Sources[Sources]
        Clay[Clay enrichment]
    end
    subgraph Orchestration[Orchestration]
        N8N[n8n workflows]
    end
    subgraph Systems[Systems of record]
        HS[HubSpot CRM]
        AM[Amplemarket]
    end
    Clay -->|enriched rows| N8N
    N8N -->|upsert| HS
    N8N -->|enroll| AM
    AM -->|bounces| HS
```

## Sequence diagram (one flow, engineer audience)

```mermaid
sequenceDiagram
    participant Form as Web form
    participant N8N as n8n
    participant Clay
    participant HS as HubSpot
    Form->>N8N: submission webhook
    N8N->>Clay: create row + enrich
    Clay-->>N8N: enriched record
    N8N->>HS: upsert company/contact
```

## Gantt (initiative timeline, executive audience)

```mermaid
gantt
    title Outbound engine build
    dateFormat YYYY-MM-DD
    section Build
    Clay table design      :a1, 2026-09-20, 5d
    n8n workflows          :a2, after a1, 7d
    section Launch
    Pilot (500 accounts)   :a3, after a2, 14d
    Full rollout           :a4, after a3, 7d
```

## Quadrant (priority matrix, executive audience)

```mermaid
quadrantChart
    title Segment priority
    x-axis Low fit --> High fit
    y-axis Low intent --> High intent
    quadrant-1 Nurture
    quadrant-2 Strike now
    quadrant-3 Deprioritize
    quadrant-4 Fast follow
    "Acme Corp": [0.8, 0.9]
    "Beta Inc": [0.6, 0.4]
```

## Rules

- One diagram per concept. Label every arrow.
- Use subgraphs to show ownership (who owns which system).
- Keep node labels short; put detail in the surrounding text, not the
  diagram.
- Validate syntax before delivering (mermaid.live or the mermaid CLI).
