# GTM Workflow Patterns — Clay → n8n → HubSpot → Amplemarket

End-to-end patterns. Each pattern names which tool owns each step and the
handoff contract between them.

## Pattern 1 — Inbound enrichment (form fill → enriched CRM record)

1. **n8n** — Webhook node receives the form submission.
2. **Clay** — API creates a row; waterfall enrichment adds firmographics,
   verified email, LinkedIn.
3. **Clay** — AI formula computes ICP fit score (1–5).
4. **n8n** — Polls for enriched rows (or receives a Clay webhook), filters
   `icp_score >= 4` AND `safe_to_send = true`.
5. **HubSpot** — Upsert company (match on domain), create/update contact,
   set lifecycle stage.
6. **Amplemarket** — Enroll in the inbound sequence (only if
   `safe_to_send`).

Handoff contract: Clay row → n8n carries `record_id, domain, email,
icp_score, safe_to_send`.

## Pattern 2 — Outbound list build (TAM → sequenced prospects)

1. **Clay** — Prospecting source columns build the raw list; dedupe on
   normalized domain.
2. **Clay** — Waterfall enrichment (email, phone), Claygent research
   column, personalized first-line AI formula.
3. **Clay** — `safe_to_send` boolean column gates everything.
4. **n8n** — Scheduled run pulls `safe_to_send = true` rows not yet in
   HubSpot.
5. **HubSpot** — Create companies/contacts; stamp `list_name` and
   `enriched_date`.
6. **Amplemarket** — Bulk enroll in the outbound sequence; sync bounces
   back to HubSpot `email_status`.

Handoff contract: never enroll a contact that isn't in HubSpot first —
HubSpot is the system of record.

## Pattern 3 — Signal-based trigger (hiring/funding signal → task)

1. **n8n** — Scheduled run checks signal sources (Clay waterfall on target
   accounts, or a data provider's API).
2. **Clay** — Scores the signal (e.g. "hiring 3+ sales roles" → hot).
3. **HubSpot** — Updates company `signal_date` / `signal_type`; creates a
   task for the account owner.
4. **Amplemarket** — Optionally enrolls the buying committee in a
   signal-specific sequence.

## Pattern 4 — Data hygiene loop (nightly)

1. **n8n** — Nightly schedule.
2. **HubSpot** — Search for contacts missing `email` or with bounced
   status; companies missing `domain`.
3. **Clay** — Re-enrich the gaps; write results back via API.
4. **HubSpot** — Update records; log a hygiene report (counts fixed,
   still missing) to a Slack webhook or email.

## Failure handling (all patterns)

- n8n executions are the audit log — every pattern must be an n8n workflow
  (not a manual Clay push) so failures are visible.
- Retry transient API errors (429/5xx) with backoff; alert on 401s (keys
  rotate).
- Dead-letter: rows that fail 3 runs go to a quarantine list, not dropped.
