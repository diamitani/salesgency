# n8n API Reference

Base URL: your own n8n instance (e.g. `https://n8n.example.com/api/v1`).
Auth: `X-N8N-API-KEY: <N8N_API_KEY>` (create in n8n → Settings → API).
Confirm endpoint paths against your n8n version's API docs — the public
REST API is versioned per n8n release.

## Core operations

```http
GET    /api/v1/workflows              # list workflows
GET    /api/v1/workflows/{id}        # workflow definition (nodes, connections)
POST   /api/v1/workflows             # create workflow
PATCH  /api/v1/workflows/{id}        # update workflow
POST   /api/v1/workflows/{id}/activate    # activate
POST   /api/v1/workflows/{id}/deactivate  # deactivate
GET    /api/v1/executions            # list executions (filter: ?workflowId=)
GET    /api/v1/executions/{id}       # execution detail incl. node run data
DELETE /api/v1/executions/{id}       # delete an execution record
```

## Typical Python pattern

```python
import os, requests
BASE = os.environ["N8N_BASE_URL"].rstrip("/") + "/api/v1"
H = {"X-N8N-API-KEY": os.environ["N8N_API_KEY"]}

def n8n_get(path, params=None):
    r = requests.get(BASE + path, headers=H, params=params, timeout=30)
    r.raise_for_status()
    return r.json()
```

## Webhook trigger

n8n Webhook nodes expose a URL like
`https://<your-instance>/webhook/<path>`. Use it as the target for Clay
webhooks or form submissions. Always use the **production** webhook URL for
live flows, not the test URL.

## Execution triage

- Filter executions by `workflowId` and `status=error` to find failures.
- Execution detail shows per-node input/output — start at the failed node
  and walk backward.
- Never store API keys inside workflow nodes; use n8n credentials and
  reference them.
