# Credentials — GTM Architect Stack

Live API calls need the user's own keys. The skill ships no credentials and
no values. Load this reference only when making live API calls.

## Factors.ai

1. Factors.ai → Settings → Integrations/API → create a key.
2. `export FACTORS_AI_KEY="<YOUR_FACTORS_AI_KEY>"`

## Clay

1. Clay → Settings → API → create a key.
2. `export CLAY_API_KEY="<YOUR_CLAY_API_KEY>"`

## n8n

1. Your n8n instance → Settings → API → create a key.
2. `export N8N_API_KEY="<YOUR_N8N_API_KEY>"`
3. `export N8N_BASE_URL="https://your-n8n-instance.example.com"` (your own
   instance URL — never hard-code someone else's host).

## HubSpot

1. HubSpot → Settings → Integrations → Private Apps → Create private app.
2. Scopes: `crm.objects.contacts.read`, `crm.objects.contacts.write`,
   `crm.objects.companies.read`, `crm.objects.companies.write`,
   `crm.objects.deals.read`.
3. `export HUBSPOT_API_KEY="<YOUR_HUBSPOT_TOKEN>"`

## Amplemarket

1. Amplemarket → Settings → Integrations/API → create an API key.
2. `export AMPLEMARKET_API_KEY="<YOUR_AMPLEMARKET_API_KEY>"`

## Rules

- Scripts read keys from the environment at runtime. Never paste keys into
  chat, code, files, or version control.
- The company knowledge file is user-supplied: the user provides their own
  company knowledge document (products, ICP, competitors, pricing, sales
  process, objection handling). Never fabricate company facts — if the file
  is missing, ask the user for it or answer only from what they state.
