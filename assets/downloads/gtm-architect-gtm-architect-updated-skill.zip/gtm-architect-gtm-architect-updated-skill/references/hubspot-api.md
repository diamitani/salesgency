# HubSpot API Reference

Base URL: `https://api.hubapi.com`. Auth: private-app token in
`Authorization: Bearer <HUBSPOT_API_KEY>` (HubSpot → Settings →
Integrations → Private Apps). Confirm endpoint paths against HubSpot's
current API docs.

## Core operations

```http
GET   /crm/v3/objects/contacts/{id}?properties=email,firstname,lastname,lifecyclestage
POST  /crm/v3/objects/contacts/search          # filtered search
PATCH /crm/v3/objects/contacts/{id}            # update contact
POST  /crm/v3/objects/contacts/batch/create    # bulk create
GET   /crm/v3/objects/companies/{id}?properties=domain,name
POST  /crm/v3/objects/companies/search
PATCH /crm/v3/objects/companies/{id}
POST  /crm/v3/objects/deals/search
```

## Search pattern

```python
import os, requests
H = {"Authorization": f"Bearer {os.environ['HUBSPOT_API_KEY']}",
     "Content-Type": "application/json"}

def hs_search(object_type, filters, properties=("email",)):
    r = requests.post(
        f"https://api.hubapi.com/crm/v3/objects/{object_type}/search",
        headers=H,
        json={"filterGroups": [{"filters": filters}],
              "properties": list(properties), "limit": 100},
        timeout=30)
    r.raise_for_status()
    return r.json()["results"]
```

## Notes

- **Match on domain** for companies — it is the only stable dedupe key.
- Batch endpoints take up to 100 records per call; page with `after`
  cursors.
- Custom properties must exist before you write to them — create them in
  Settings → Properties first (e.g. an ABM workflow-date field).
- Required private-app scopes for this skill's flows:
  `crm.objects.contacts.read/write`, `crm.objects.companies.read/write`,
  `crm.objects.deals.read`.
