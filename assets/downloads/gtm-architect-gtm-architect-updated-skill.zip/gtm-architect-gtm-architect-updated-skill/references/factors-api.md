# Factors.ai API Reference

Base URL: `https://api.factors.ai` — API versioning can vary by endpoint;
some calls need a `/v1/` prefix. Auth: `Authorization: Bearer
<FACTORS_AI_KEY>` (Factors.ai → Settings → Integrations/API). Confirm exact
endpoint paths against Factors.ai's current API documentation.

## Core operations

```http
GET  /v1/accounts?domain=EXAMPLE.COM        # look up an account by domain
POST /v1/accounts                            # create/update an account
GET  /v1/workflows                           # list intent workflows
POST /v1/workflows                           # create an intent workflow
GET  /v1/workflows/{id}/executions           # workflow execution history
GET  /v1/alerts                              # list alerts
POST /v1/alerts                              # create an alert
GET  /v1/integrations/hubspot                # HubSpot integration status
GET  /v1/integrations/hubspot/field_mapping  # field mapping status
```

## Workflow object (create)

```json
{
  "name": "High-intent pricing visitors",
  "trigger": {"type": "page_visit", "url_contains": "/pricing"},
  "filters": [{"field": "employee_count", "operator": "gte", "value": 200}],
  "actions": [
    {"type": "hubspot_update",
     "match_on": "domain",
     "fields": {"factors_abm__workflow_date": "{{triggered_at}}"}},
    {"type": "slack", "channel": "#gtm-alerts",
     "message": "Hot account: {{account.name}}"}
  ]
}
```

## Typical Python pattern

```python
import os, requests
BASE = "https://api.factors.ai/v1"
H = {"Authorization": f"Bearer {os.environ['FACTORS_AI_KEY']}",
     "Content-Type": "application/json"}

def factors_get(path, params=None):
    r = requests.get(BASE + path, headers=H, params=params, timeout=30)
    r.raise_for_status()
    return r.json()
```

## Notes

- Identify accounts by **domain** everywhere — it is the join key with
  HubSpot and Clay.
- `match_on` must be `"domain"` on any `hubspot_update` action, or the
  sync silently writes nothing.
- Write the trigger timestamp into a custom HubSpot field
  (`factors_abm__workflow_date`) so recency is queryable in the CRM.
