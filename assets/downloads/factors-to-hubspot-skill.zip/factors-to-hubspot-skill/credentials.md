# Credentials — Factors.ai → HubSpot Sync

This skill makes live calls to the Factors.ai API and the HubSpot API. You
supply your own keys; the skill ships no credentials and no values.

## Factors.ai API key

1. Log in to your Factors.ai workspace.
2. Open **Settings → Integrations / API** (or ask your Factors.ai admin for a
   key with read/write access to accounts, workflows, alerts, and events).
3. Copy the key and store it as an environment variable:

```bash
export FACTORS_AI_KEY="<YOUR_FACTORS_AI_KEY>"
```

## HubSpot private-app token

The sync writes to HubSpot companies (not via Clay — the HubSpot API
directly), so it needs a HubSpot private-app token, not a Clay key.

1. In HubSpot, go to **Settings → Integrations → Private Apps → Create
   private app**.
2. Grant these scopes: `crm.objects.companies.read`,
   `crm.objects.companies.write`, `crm.objects.contacts.read`,
   `crm.objects.contacts.write`.
3. Copy the token and store it as an environment variable:

```bash
export HUBSPOT_API_KEY="<YOUR_HUBSPOT_TOKEN>"
```

Every script in this skill reads `FACTORS_AI_KEY` and `HUBSPOT_API_KEY` from
the environment at runtime. Never paste keys into chat, code, files, or
version control.

## Troubleshooting

- **401 from Factors.ai** — key missing/expired or wrong scope. Regenerate
  in the Factors.ai dashboard.
- **401/403 from HubSpot** — the private app lacks a needed scope, or the
  token was rotated. Check the app's scopes and re-copy the token.
- **Sync silently not updating** — the usual cause is not auth but the
  workflow's `match_on` field (must be `"domain"`) or the
  `factors_abm__workflow_date` field mapping. See the debugging section in
  `SKILL.md`.
