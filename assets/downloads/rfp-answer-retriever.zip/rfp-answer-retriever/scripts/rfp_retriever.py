#!/usr/bin/env python3
"""
rfp_retriever.py — Full pipeline orchestrator: parse -> match -> ticket -> export.

Usage:
  python3 scripts/rfp_retriever.py --input "RFP.pdf" --rfp-name "Example" \
      --output rfp_response_example_20260326.xlsx --kb-dir references/
  python3 scripts/rfp_retriever.py --questions /tmp/questions.json \
      --rfp-name "Example" --output rfp_response_example_20260326.xlsx \
      --kb-dir references/

Set HUBSPOT_ACCESS_TOKEN to enable ticket creation for NO MATCH questions;
omit it to skip ticket creation.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def run(script, *argv):
    cmd = [sys.executable, os.path.join(HERE, script), *argv]
    print(f"+ {' '.join(cmd)}")
    subprocess.run(cmd, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", help="RFP file (PDF/DOCX/XLSX/TXT)")
    ap.add_argument("--questions", help="Pre-parsed questions.json")
    ap.add_argument("--rfp-name", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--kb-dir", default=os.path.join(HERE, "..", "references"))
    args = ap.parse_args()
    if not args.input and not args.questions:
        print("Provide --input or --questions.", file=sys.stderr)
        sys.exit(2)

    tmpdir = tempfile.mkdtemp(prefix="rfp_")
    questions_path = args.questions
    if args.input:
        questions_path = os.path.join(tmpdir, "questions.json")
        run("rfp_parser.py", "--input", args.input, "--output", questions_path,
            "--source-name", args.rfp_name)

    matches_path = os.path.join(tmpdir, "matches.json")
    run("kb_matcher.py", "--questions", questions_path, "--kb-dir", args.kb_dir,
        "--output", matches_path)

    with open(matches_path, encoding="utf-8") as f:
        matches = json.load(f)

    ticket_enabled = bool(os.environ.get("HUBSPOT_ACCESS_TOKEN"))
    if not ticket_enabled:
        print("HUBSPOT_ACCESS_TOKEN not set — skipping ticket creation.")
    for m in matches:
        if m.get("confidence") == "NO MATCH" and ticket_enabled:
            run("create_hubspot_ticket.py",
                "--question", m["question"],
                "--rfp-source", f"RFP - {args.rfp_name}",
                "--suggested-owner", "Unassigned",
                "--priority", "MEDIUM")

    run("build_rfp_response.py", "--input", matches_path, "--output", args.output)

    high = sum(1 for m in matches if m["confidence"] == "HIGH")
    med = sum(1 for m in matches if m["confidence"] == "MEDIUM")
    none = sum(1 for m in matches if m["confidence"] == "NO MATCH")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"✅ Answered (HIGH): {high}")
    print(f"⚠️  Needs review (MEDIUM): {med}")
    print(f"❌ No answer / Ticketed: {none}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


if __name__ == "__main__":
    main()
