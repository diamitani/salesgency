#!/usr/bin/env python3
"""
kb_matcher.py — Score questions against the KB using the matching rubric.

Scoring axes (see references/matching-rules.md):
  Topic 0–3, Country 0–2, Completeness 0–2  (max 7)
Confidence: 6–7 HIGH, 4–5 MEDIUM, 0–3 NO MATCH.
'new' status caps at MEDIUM. 'unreviewed' entries are excluded.

Usage:
  python3 scripts/kb_matcher.py --questions /tmp/questions.json \
      --kb-dir references/ --output /tmp/matches.json
"""
import argparse
import glob
import json
import os
import re

STOP = frozenset("""a an the and or of to in on for with is are was were be
been do does did have has had what which who whom how why when where
does your you our we it its this that these those by as at from into
can could should would may might will shall must""".split())


def tokens(s):
    return {t for t in re.findall(r"[a-z0-9]+", s.lower()) if t not in STOP}


def detect_country(question):
    q = question.lower()
    countries = {
        "germany": "DE", "german": "DE", "deutschland": "DE",
        "france": "FR", "french": "FR",
        "uk": "UK", "united kingdom": "UK", "britain": "UK",
        "us": "US", "usa": "US", "united states": "US", "american": "US",
        "canada": "CA", "australia": "AU", "japan": "JP", "brazil": "BR",
        "india": "IN", "spain": "ES", "italy": "IT", "netherlands": "NL",
    }
    for name, code in countries.items():
        if re.search(r"\b" + re.escape(name) + r"\b", q):
            return code
    return None


def load_kb(kb_dir):
    facts = []
    for path in sorted(glob.glob(os.path.join(kb_dir, "*.json"))):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        entries = data if isinstance(data, list) else data.get("facts", [])
        for e in entries:
            e = dict(e)
            e["_file"] = os.path.basename(path)
            facts.append(e)
    return facts


def score_topic(q_toks, fact):
    f_toks = tokens(fact.get("q", "") + " " + fact.get("type", ""))
    overlap = q_toks & f_toks
    if not q_toks or not f_toks:
        return 0
    ratio = len(overlap) / min(len(q_toks), len(f_toks))
    # 3 = direct answer: question's key content words mostly covered
    key = {t for t in q_toks if len(t) > 3}
    key_hit = len(overlap & key) / max(len(key), 1)
    if key_hit >= 0.6 or ratio >= 0.5:
        return 3
    if ratio >= 0.3 or key_hit >= 0.35:
        return 2
    if ratio > 0.1:
        return 1
    return 0


def score_completeness(fact):
    answer = fact.get("a", "")
    if re.search(r"\d", answer) and len(answer) > 60:
        return 2  # specifics: numbers, process detail
    if len(answer) > 30:
        return 1
    return 0


def score_country(question_country, fact_country):
    fact_country = (fact_country or "global").upper()
    if not question_country or fact_country == "GLOBAL":
        return 2 if not question_country or fact_country == "GLOBAL" else 1
    return 2 if fact_country == question_country else 0


def match_question(question, facts):
    q_toks = tokens(question)
    q_country = detect_country(question)
    scored = []
    for fact in facts:
        if fact.get("status") == "unreviewed":
            continue
        t = score_topic(q_toks, fact)
        if t == 0:
            continue
        c = score_country(q_country, fact.get("country"))
        if c == 0 and q_country:
            continue  # wrong-country facts never answer a country-scoped question
        comp = score_completeness(fact)
        total = t + c + comp
        scored.append((total, fact))
    scored.sort(key=lambda x: -x[0])
    if not scored:
        return {"confidence": "NO MATCH", "candidates": []}
    top = scored[0]
    candidates = [c for c in scored[:3]]
    confidence = "HIGH" if top[0] >= 6 else "MEDIUM" if top[0] >= 4 else "NO MATCH"
    if confidence == "HIGH" and top[1].get("status") == "new":
        confidence = "MEDIUM"  # new facts cap at MEDIUM
    if confidence == "NO MATCH":
        return {"confidence": "NO MATCH", "candidates": []}
    # near-tie: surface top two as Option A / Option B
    near_tie = len(scored) > 1 and scored[0][0] - scored[1][0] <= 1
    return {
        "confidence": confidence,
        "near_tie": near_tie,
        "candidates": [
            {"score": s, "question": f["q"], "answer": f["a"],
             "type": f.get("type"), "owner": f.get("owner"),
             "country": f.get("country"), "source": f.get("source"),
             "status": f.get("status"), "file": f.get("_file")}
            for s, f in candidates
        ],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions", required=True)
    ap.add_argument("--kb-dir", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    with open(args.questions, encoding="utf-8") as f:
        questions = json.load(f)
    facts = load_kb(args.kb_dir)
    print(f"Loaded {len(facts)} KB facts from {args.kb_dir}")

    results = []
    for q in questions:
        qtext = q["question"] if isinstance(q, dict) else str(q)
        n = q.get("n") if isinstance(q, dict) else None
        m = match_question(qtext, facts)
        results.append({"n": n, "question": qtext, **m})

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    counts = {}
    for r in results:
        counts[r["confidence"]] = counts.get(r["confidence"], 0) + 1
    print(f"Matched {len(results)} questions: {counts} -> {args.output}")


if __name__ == "__main__":
    main()
