#!/usr/bin/env python3
"""
create_hubspot_ticket.py — Create a HubSpot ticket for an RFP KB gap.

Auth comes ONLY from the HUBSPOT_ACCESS_TOKEN environment variable
(your own HubSpot private app token). It is never accepted on the command
line so it can't leak into shell history.

Usage:
  export HUBSPOT_ACCESS_TOKEN=...   # your own token
  python3 scripts/create_hubspot_ticket.py \
    --question "The question text" \
    --rfp-source "RFP - Example" \
    --suggested-owner "Security" \
    --priority "HIGH"
"""
import argparse
import datetime
import json
import os
import sys
import urllib.request

API_BASE = "https://api.hubapi.com/crm/v3/objects/tickets"

PRIORITY_MAP = {"HIGH": "HIGH", "MEDIUM": "MEDIUM", "LOW": "LOW"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--question", required=True)
    ap.add_argument("--rfp-source", default="")
    ap.add_argument("--suggested-owner", default="Unassigned")
    ap.add_argument("--priority", default="MEDIUM",
                    choices=["HIGH", "MEDIUM", "LOW"])
    ap.add_argument("--due-days", type=int, default=7)
    args = ap.parse_args()

    token = os.environ.get("HUBSPOT_ACCESS_TOKEN")
    if not token:
        print("HUBSPOT_ACCESS_TOKEN is not set — cannot create ticket.",
              file=sys.stderr)
        print_manual_block(args)
        sys.exit(2)

    due = (datetime.date.today() +
           datetime.timedelta(days=args.due_days)).isoformat()
    payload = {
        "properties": {
            "subject": f"KB gap: {args.question[:120]}",
            "content": (f"RFP source: {args.rfp_source}\n"
                        f"Suggested owner team: {args.suggested_owner}\n\n"
                        f"Question:\n{args.question}"),
            "hs_ticket_priority": PRIORITY_MAP[args.priority],
            "hs_pipeline_stage": "1",  # "New" stage of the default pipeline
            "hs_due_date": due,
        }
    }
    req = urllib.request.Request(
        API_BASE,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {token}",
                 "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = json.load(resp)
    except Exception as e:  # noqa: BLE001
        print(f"HubSpot API call failed: {e}", file=sys.stderr)
        print_manual_block(args)
        sys.exit(1)
    print(f"Ticket created: id={body.get('id')}")


def print_manual_block(args):
    print("\n--- Create this ticket manually in HubSpot ---")
    print(f"Subject: KB gap: {args.question[:120]}")
    print(f"RFP source: {args.rfp_source}")
    print(f"Suggested owner: {args.suggested_owner}")
    print(f"Priority: {args.priority}")
    print(f"Question: {args.question}")
    print("--------------------------------------------")


if __name__ == "__main__":
    main()
