#!/usr/bin/env python3
"""
build_rfp_response.py — Build the formatted RFP response workbook.

Input: matches.json from kb_matcher.py (with confidence + candidates).
Output: .xlsx (requires openpyxl) or .csv fallback.

Usage:
  python3 scripts/build_rfp_response.py --input /tmp/matches.json \
      --output rfp_response_example_20260326.xlsx
"""
import argparse
import csv
import json
import os

COLUMNS = ["#", "Question", "Answer", "Confidence", "Source",
           "Owner", "Review Flag"]


def rows_from_matches(matches):
    rows = []
    for m in matches:
        cand = (m.get("candidates") or [{}])[0]
        conf = m.get("confidence", "NO MATCH")
        answer = cand.get("answer") if conf in ("HIGH", "MEDIUM") else "No KB Answer"
        flag = ""
        if conf == "MEDIUM":
            flag = "REVIEW"
        elif conf == "NO MATCH":
            flag = "TICKET"
        elif m.get("near_tie"):
            flag = "CONFIRM A/B"
        rows.append([m.get("n", ""), m.get("question", ""), answer, conf,
                     cand.get("source", ""), cand.get("owner", ""), flag])
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    with open(args.input, encoding="utf-8") as f:
        matches = json.load(f)
    rows = rows_from_matches(matches)

    ext = os.path.splitext(args.output)[1].lower()
    if ext == ".xlsx":
        try:
            from openpyxl import Workbook
            from openpyxl.styles import PatternFill, Font, Alignment
            wb = Workbook()
            ws = wb.active
            ws.title = "RFP Response"
            hdr_fill = PatternFill("solid", fgColor="222B40")
            hdr_font = Font(bold=True, color="FFFFFF")
            flag_fills = {"REVIEW": PatternFill("solid", fgColor="FFC857"),
                          "TICKET": PatternFill("solid", fgColor="EE4266"),
                          "CONFIRM A/B": PatternFill("solid", fgColor="FFC857")}
            for ci, col in enumerate(COLUMNS, 1):
                cell = ws.cell(row=1, column=ci, value=col)
                cell.fill = hdr_fill
                cell.font = hdr_font
            for ri, row in enumerate(rows, 2):
                for ci, val in enumerate(row, 1):
                    cell = ws.cell(row=ri, column=ci, value=val)
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
                flag = row[-1]
                if flag in flag_fills:
                    ws.cell(row=ri, column=len(COLUMNS)).fill = flag_fills[flag]
            ws.column_dimensions["B"].width = 50
            ws.column_dimensions["C"].width = 70
            ws.freeze_panes = "A2"
            wb.save(args.output)
            print(f"Wrote {len(rows)} answers -> {args.output}")
            return
        except ImportError:
            print("openpyxl not installed — writing CSV instead.")
            args = argparse.Namespace(input=args.input,
                                      output=os.path.splitext(args.output)[0] + ".csv")

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(COLUMNS)
        w.writerows(rows)
    print(f"Wrote {len(rows)} answers -> {args.output}")


if __name__ == "__main__":
    main()
