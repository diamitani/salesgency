#!/usr/bin/env python3
"""
rfp_parser.py — Extract a numbered question list from an RFP file.

Supports PDF, DOCX, XLSX, TXT. Output: JSON array of {"n": int, "question": str}.

Usage:
  python3 scripts/rfp_parser.py --input "RFP.pdf" --output /tmp/questions.json --source-name "ACME"
"""
import argparse
import json
import os
import re
import sys


def text_from_pdf(path):
    for mod, fn in (("pypdf", "read"), ("pdfplumber", "read")):
        try:
            if mod == "pypdf":
                from pypdf import PdfReader
                return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages)
            from pdfplumber import open as pdf_open
            with pdf_open(path) as pdf:
                return "\n".join((p.extract_text() or "") for p in pdf.pages)
        except ImportError:
            continue
    raise RuntimeError("No PDF library installed (try: pip install pypdf).")


def text_from_docx(path):
    try:
        from docx import Document
    except ImportError:
        raise RuntimeError("python-docx not installed (pip install python-docx).")
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs)


def questions_from_xlsx(path):
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise RuntimeError("openpyxl not installed (pip install openpyxl).")
    wb = load_workbook(path, read_only=True)
    questions = []
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            for cell in row or []:
                text = str(cell).strip() if cell else ""
                if len(text) > 20 and text.endswith("?"):
                    questions.append(text)
    return questions


def extract_questions(text):
    # Numbered/sectioned question-like lines, plus anything ending in "?"
    questions = []
    numbered = re.compile(r"^\s*(?:\d+(?:\.\d+)*[\.\)\:]|\-|\•)\s+(.{20,})$")
    for line in text.splitlines():
        line = line.strip()
        if not line or len(line) < 20:
            continue
        m = numbered.match(line)
        if m and m.group(1).rstrip().endswith("?"):
            questions.append(m.group(1).strip())
        elif line.endswith("?") and len(line) < 600:
            questions.append(line)
    # dedup, keep order
    return list(dict.fromkeys(questions))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--source-name", default="")
    args = ap.parse_args()

    ext = os.path.splitext(args.input)[1].lower()
    if ext == ".pdf":
        qs = extract_questions(text_from_pdf(args.input))
    elif ext == ".docx":
        qs = extract_questions(text_from_docx(args.input))
    elif ext in (".xlsx", ".xls"):
        qs = questions_from_xlsx(args.input)
    elif ext == ".txt":
        with open(args.input, encoding="utf-8", errors="replace") as f:
            qs = extract_questions(f.read())
    else:
        print(f"Unsupported file type: {ext}", file=sys.stderr)
        sys.exit(2)

    out = [{"n": i + 1, "question": q, "source": args.source_name} for i, q in enumerate(qs)]
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"Extracted {len(out)} questions -> {args.output}")


if __name__ == "__main__":
    main()
