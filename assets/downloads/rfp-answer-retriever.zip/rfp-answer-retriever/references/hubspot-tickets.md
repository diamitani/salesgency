# HubSpot Tickets for KB Gaps

When a question scores NO MATCH, create a HubSpot ticket so the owning team
can add the missing fact to the real KB.

## Auth

Set `HUBSPOT_ACCESS_TOKEN` in the environment (your own HubSpot private app
token). Never put the token on the command line — it ends up in shell
history. The script refuses to run without the variable set.

## Command

```bash
python3 scripts/create_hubspot_ticket.py \
  --question "The question text" \
  --rfp-source "RFP - Schaeffler Group" \
  --suggested-owner "Security" \
  --priority "HIGH"
```

## Ticket fields

| Argument | HubSpot field | Notes |
|---|---|---|
| `--question` | subject + content | Question text verbatim |
| `--rfp-source` | `rfp_source` | Which RFP the gap came from |
| `--suggested-owner` | `hubspot_owner_id` (via team name lookup) or a note | Pick one of: Product, Security, Compliance, Legal, Operations, Sales, Implementation |
| `--priority` | `hs_ticket_priority` | HIGH / MEDIUM / LOW |
| `--due` | `hs_due_date` | Optional; default 7 days out |

Priority guidance:

- **HIGH** — blocker for a live RFP with a submission deadline.
- **MEDIUM** — gap found during routine RFP prep.
- **LOW** — nice-to-have clarification, no deadline.

## Failure mode

If the API call fails, do not retry blindly. Print the ticket details as a
formatted block so the user can create it manually in HubSpot, and note the
failure in the RFP response summary.
