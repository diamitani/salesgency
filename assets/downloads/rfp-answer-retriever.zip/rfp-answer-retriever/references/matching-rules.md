# Matching Rules — Scoring Rubric

Each question is scored against every KB fact on three axes. The maximum is
7 points. Confidence bands: 6–7 = HIGH, 4–5 = MEDIUM, 0–3 = NO MATCH.

## Topic (0–3)

- **3** — The fact answers the question directly. Same subject, same scope.
- **2** — Same topic, close but not exact (e.g. question asks about SSO
  providers; fact confirms SSO with SAML 2.0 but names no providers).
- **1** — Adjacent topic only (e.g. question asks about encryption keys; fact
  covers encryption algorithms).
- **0** — Unrelated.

## Country (0–2)

- **2** — Fact country matches the question's country, or the question is not
  country-scoped.
- **1** — Fact is `global` and the question names a country (may miss local
  requirements).
- **0** — Fact is scoped to a different country than the question.

## Completeness (0–2)

- **2** — The answer fully addresses the question with specifics (numbers,
  process steps, named integrations).
- **1** — Partially addresses it; a reviewer must fill the gap.
- **0** — Vague or only tangentially related.

## Status modifiers

- `status: "new"` — cap the final confidence at MEDIUM regardless of score.
- `status: "unreviewed"` — exclude entirely; do not score.
- `status: "confirmed"` — no modifier.

## Tie-breaking

If the top two candidates are within 1 point of each other, surface both as
**Option A / Option B** and ask the user to confirm which fits. Never silently
pick between near-ties.

## Conflict rule

If a fact is conflict-flagged (e.g. an `unreviewed` duplicate contradicts a
`confirmed` fact), do not use either as an answer. Note the conflict in the
response and create a HubSpot ticket for the owning team.
