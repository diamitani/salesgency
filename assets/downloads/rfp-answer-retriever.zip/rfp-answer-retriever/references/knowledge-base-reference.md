# Knowledge Base Reference

How the KB JSON files bundled with this skill are organized, and how to
replace them with your own company's data.

## Files

- `references/master_kb_confirmed.json` — example facts with
  `status: "confirmed"`. Load first; highest confidence.
- `references/master_kb_facts.json` — example broader KB. Load second;
  **exclude** any fact with `status: "unreviewed"`.

## Field key

| Key | Meaning | Example |
|---|---|---|
| `q` | The question this fact answers | "Is the platform SOC 2 Type II certified?" |
| `a` | The answer text, ready to paste | "Yes. The platform holds..." |
| `type` | Fact category: security, compliance, product, legal, operations, commercial | "compliance" |
| `owner` | Team owning the fact | "Security" |
| `country` | Scope: "global" or an ISO country code | "DE" |
| `source` | Where the fact was verified | "Security portal Q3 2026" |
| `status` | "confirmed", "new", or "unreviewed" | "confirmed" |

## Status rules

- **confirmed** — verified by the owning team; usable as an answer.
- **new** — recently added, not yet reviewed; MEDIUM confidence at best.
- **unreviewed** — pending conflicts; **never** use as an answer. Note the
  conflict and create a HubSpot ticket (see `hubspot-tickets.md`).

## Country scoping

- A fact with a country code only answers questions scoped to that country.
- A `global` fact answers any country-scoped question, but is downgraded to
  MEDIUM confidence for a country-specific question (it may not cover local
  requirements).

## Replacing the example data

These files are placeholders for your real KB. Keep the same field schema,
mark every fact with a status, and never mix `unreviewed` entries into the
confirmed file. Point the scripts at your KB directory with `--kb-dir`.
