# Backend Verification Pattern

Runnable 19-test API verification runner referenced by the
agent-architect skill. Run it against any FastAPI backend built with the
ROSTR full-stack SaaS pattern before deploying. It exercises every
endpoint class and reports PASS/FAIL counts — the gate is 19/19.

## The 19 tests

| # | Test | Method & path |
|---|---|---|
| 1 | Health check responds | GET /health |
| 2 | OpenAPI schema loads | GET /openapi.json |
| 3 | PAL compile accepts input | POST /pal/compile |
| 4 | PAL compile rejects empty input | POST /pal/compile (422) |
| 5 | List agents | GET /hub/agents |
| 6 | Get single agent | GET /hub/agents/{id} |
| 7 | Get missing agent → 404 | GET /hub/agents/does-not-exist |
| 8 | Create agent | POST /hub/agents |
| 9 | Create agent validates body | POST /hub/agents (422 on bad body) |
| 10 | Update agent | PATCH /hub/agents/{id} |
| 11 | Delete agent | DELETE /hub/agents/{id} |
| 12 | List decisions | GET /hub/decisions |
| 13 | Record decision | POST /hub/decisions |
| 14 | List learnings | GET /hub/learnings |
| 15 | Log learning | POST /hub/learnings |
| 16 | Query knowledge | GET /hub/knowledge?q=test |
| 17 | Add knowledge | POST /hub/knowledge |
| 18 | Unauthorized → 401 (no token) | GET /hub/agents without auth header |
| 19 | CORS preflight | OPTIONS /hub/agents |

## The script

Copy into the project under test and run
`python3 verify_backend.py <base-url>`. Set `TOKEN` below to a real test
token for the backend under test before running.

```python
#!/usr/bin/env python3
"""API verification runner: 19 tests, PASS/FAIL report, exit 0 only on 19/19."""
import sys
import urllib.request
import urllib.error
import json

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8420"
TOKEN = {"Authorization": "Bearer dev-token"}  # replace with a real test token

results = []

def check(name, method, path, body=None, expect=200, headers=None):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    hdrs = {"Content-Type": "application/json"}
    hdrs.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    payload = None
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8", "replace")
            try:
                payload = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                payload = None
            ok = resp.status == expect
            results.append((name, ok, f"got {resp.status}, want {expect}"))
    except urllib.error.HTTPError as e:
        ok = e.code == expect
        results.append((name, ok, f"got {e.code}, want {expect}"))
    except Exception as e:  # noqa: BLE001
        results.append((name, False, f"error: {e}"))
    return payload

H = TOKEN
check("health", "GET", "/health", expect=200)
check("openapi", "GET", "/openapi.json", expect=200)
check("pal_compile_ok", "POST", "/pal/compile", body={"input": "summarize Q3"}, headers=H)
check("pal_compile_422", "POST", "/pal/compile", body={"input": ""}, expect=422, headers=H)
check("agents_list", "GET", "/hub/agents", headers=H)
check("agent_get_404", "GET", "/hub/agents/does-not-exist", expect=404, headers=H)
created = check("agent_create", "POST", "/hub/agents",
                body={"name": "qa-probe", "model": "test"}, headers=H)
agent_id = (created or {}).get("id") if isinstance(created, dict) else None
if agent_id:
    check("agent_get", "GET", f"/hub/agents/{agent_id}", headers=H)
else:
    results.append(("agent_get", False, "no id returned by agent_create"))
check("agent_create_422", "POST", "/hub/agents", body={"nope": 1}, expect=422, headers=H)
if agent_id:
    check("agent_update", "PATCH", f"/hub/agents/{agent_id}",
          body={"name": "qa-probe-renamed"}, headers=H)
    check("agent_delete", "DELETE", f"/hub/agents/{agent_id}", headers=H)
else:
    results.append(("agent_update", False, "no id returned by agent_create"))
    results.append(("agent_delete", False, "no id returned by agent_create"))
check("decisions_list", "GET", "/hub/decisions", headers=H)
check("decision_create", "POST", "/hub/decisions", body={"text": "probe"}, headers=H)
check("learnings_list", "GET", "/hub/learnings", headers=H)
check("learning_log", "POST", "/hub/learnings", body={"context": "probe", "insight": "probe"}, headers=H)
check("knowledge_query", "GET", "/hub/knowledge?q=test", headers=H)
check("knowledge_add", "POST", "/hub/knowledge", body={"text": "probe"}, headers=H)
check("auth_401", "GET", "/hub/agents", expect=401)
check("cors_preflight", "OPTIONS", "/hub/agents", expect=200, headers={
    "Origin": "https://app.example.com",
    "Access-Control-Request-Method": "GET",
})

passed = sum(1 for _, ok, _ in results if ok)
for name, ok, detail in results:
    print(("PASS" if ok else "FAIL"), name, "-", detail)
print(f"{passed}/{len(results)} passed")
sys.exit(0 if passed == len(results) else 1)
```

Adapt paths, auth scheme, and payload shapes to the backend under test.
The non-negotiable part is the discipline: automated, counted, and green
before any deploy claim.
