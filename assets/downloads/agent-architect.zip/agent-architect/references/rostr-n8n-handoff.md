# ROSTR → n8n Execution Handoff

Contract for handing a designed ROSTR agent architecture to n8n for
execution. The agent-architect skill produces the design; this document
defines the handoff format so the n8n side can execute it without
re-interpretation.

## Handoff package

The architect emits one handoff package per workflow:

```json
{
  "workflow_name": "lead-triage-v1",
  "trigger": {"type": "webhook", "path": "/lead-triage"},
  "nodes": [
    {"id": "intake", "type": "webhook-receiver", "config": {"method": "POST"}},
    {"id": "enrich", "type": "http-request", "config": {"url": "<ENRICHMENT_API_URL_FROM_PROJECT_CONFIG>", "method": "GET"}},
    {"id": "score", "type": "code", "config": {"runtime": "python", "entrypoint": "score_lead"}},
    {"id": "route", "type": "if", "config": {"condition": "score >= 70"}},
    {"id": "notify", "type": "slack", "config": {"channel": "#sdr-alerts"}}
  ],
  "edges": [
    {"from": "intake", "to": "enrich"},
    {"from": "enrich", "to": "score"},
    {"from": "score", "to": "route"},
    {"from": "route.true", "to": "notify"}
  ],
  "credentials": [
    {"node": "enrich", "credential_name": "Enrich API key", "env_var": "ENRICH_API_KEY"},
    {"node": "notify", "credential_name": "Slack OAuth", "env_var": "SLACK_TOKEN"}
  ],
  "error_policy": {"on_node_error": "route_to_dead_letter", "retries": 2, "backoff": "exponential"}
}
```

## Rules

1. **Every node has an id, a type, and a config.** No free-form prose in
   the package — the n8n builder maps node types to real n8n node classes.
2. **Credentials are references, never values.** The handoff names the
   credential and the env var that holds it. Values live in the n8n
   credential store or the deployment's secret manager.
3. **One trigger per workflow.** Multi-trigger designs are split into
   separate workflows at handoff time.
4. **Error policy is mandatory.** Every handoff declares retries, backoff,
   and the dead-letter destination. A workflow without an error policy is
   rejected by the builder.
5. **Idempotency keys** on any node that writes to an external system
   (CRM, billing, messaging). The builder adds a dedupe check node when
   the architect forgets.

## Mapping ROSTR capabilities to n8n nodes

| ROSTR capability | n8n node type | Notes |
|---|---|---|
| `web_search` | HTTP Request | Points at the search API endpoint |
| `file_system:read/write` | Read/Write Binary File | Scoped to the workflow's workspace dir |
| `llm:complete` | OpenAI / HTTP Request | Model + prompt in node config |
| `crm:upsert` | HubSpot / HTTP Request | Uses the CRM credential reference |
| `notify:*` | Slack / Email Send | Channel/recipient in config |

## Verification after import

1. Open the imported workflow in the n8n editor — every node must show a
   green "configured" state (no orange warnings).
2. Run with the sample payload from the handoff's `test_payload` field.
3. Confirm the dead-letter path fires by forcing one node to fail.
