# Gemini ADK Integration

How to wrap ROSTR agent YAML configs as Google Agent Development Kit
(ADK) agents. Install the ADK with `pip install google-adk` (the package
name is `google-adk`, not `google-genai` alone).

## The wrapper class

```python
from google.adk.agents import Agent
from google.adk.tools import Tool

class ROSTRGeminiAgent:
    """Wraps a ROSTR agent YAML config as an ADK Agent."""

    def __init__(self, config: dict):
        self.config = config
        self.agent = Agent(
            name=config["name"],
            description=config.get("description", ""),
            instruction=self._build_instruction(config),
            tools=[self._to_tool(c) for c in config.get("capabilities", [])],
        )

    def _build_instruction(self, config: dict) -> str:
        # ROSTR system prompt + PAL framing become the ADK instruction.
        parts = [
            f"You are {config['name']}.",
            config.get("system_prompt", ""),
            "Follow the PAL pipeline: Parse, Ambiguity Scan, "
            "Latent Intent, Expand, Compile.",
        ]
        return "\n".join(p for p in parts if p)

    def _to_tool(self, capability: str) -> Tool:
        # Map each ROSTR capability string to an ADK Tool.
        handler = CAPABILITY_HANDLERS.get(capability)
        if handler is None:
            raise ValueError(f"No ADK mapping for capability: {capability}")
        return Tool.from_function(handler, name=capability)

    def run(self, prompt: str):
        return self.agent.run(prompt)
```

## Tool mapping table

| ROSTR capability | ADK Tool.from_function handler | Notes |
|---|---|---|
| `web_search` | `search_web(query)` | Wraps a search API call |
| `file_system:read` | `read_file(path)` | Scoped to the agent workspace |
| `file_system:write` | `write_file(path, content)` | Scoped to the agent workspace |
| `llm:complete` | `complete(prompt, model)` | Sub-model call |
| `crm:read` / `crm:upsert` | `crm_read(...)` / `crm_upsert(...)` | Needs the CRM credential |

Add rows as new capabilities appear. Unmapped capabilities raise at
wrap time — fail fast rather than silently dropping a tool.

## Graceful degradation

```python
try:
    from google.adk.agents import Agent  # noqa
    ADK_AVAILABLE = True
except ImportError:
    ADK_AVAILABLE = False

def load_agent(config: dict):
    if not ADK_AVAILABLE:
        # Still load the config: show it as "available but not runnable".
        return {"config": config, "status": "adk-not-installed"}
    return ROSTRGeminiAgent(config)
```

If the ADK isn't installed, configs still load and report their
availability status — the system never crashes on a missing optional
dependency.

## Session and runner wiring

Use ADK's `Runner` with an in-memory session service for single-turn
tasks, or a persistent session service when the agent needs memory
across turns. Keep ROSTR's SQLite learning store as the long-term
memory; the ADK session holds only the current conversation.
