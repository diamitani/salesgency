# Amplemarket API Credentials — Setup Guide

How to get your own Amplemarket API key and wire it into this skill.
No credential values are stored in this skill — the key lives in your
environment.

## Get the key

1. Log in to your Amplemarket dashboard (app.amplemarket.com).
2. Open account settings → API / integrations (the exact label varies by
   plan; look for "API keys" or "Developer").
3. Generate a new API key. Copy it once — you won't see it again.

If your plan doesn't expose API keys, ask your Amplemarket admin or
account manager to enable API access.

## Store the key

```bash
# Add to your shell profile (~/.zshrc, ~/.bashrc) or a .env file:
export AMPLEMARKET_API_KEY=<YOUR_AMPLEMARKET_API_KEY>

# Verify it's set (prints nothing but the key length, not the key):
python3 -c "import os; print('set' if os.environ.get('AMPLEMARKET_API_KEY') else 'missing')"
```

Replace `<YOUR_AMPLEMARKET_API_KEY>` with the key you copied. Never commit
the real value to git, never paste it into chat logs you share.

## Use the key

```python
import os
import requests

AMP_BASE = "https://api.amplemarket.com"
AMP_HEADERS = {
    "Authorization": f"Bearer {os.environ['AMPLEMARKET_API_KEY']}",
    "Content-Type": "application/json",
}

resp = requests.get(f"{AMP_BASE}/sequences", headers=AMP_HEADERS)
resp.raise_for_status()
print(resp.json())
```

## Rotation

If a key leaks, revoke it in the Amplemarket dashboard and generate a new
one, then update the environment variable. The skill reads the env var at
call time, so no skill files need to change.
