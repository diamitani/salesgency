#!/usr/bin/env python3
"""Resolve free-text industry input to a valid HubSpot industry value.

Usage:
    python3 scripts/industry_resolver.py "SaaS" "Fintech" "oil & gas" "Manufacturing" "54"

Resolution ladder (first confident hit wins):
  1. exact    — already a HubSpot option (validated against the portal snapshot)
  2. synonym  — curated GTM/data-provider term
  3. fuzzy    — difflib close match against canonical industries (cutoff 0.86)
  4. sector/naics-code — input names a NAICS sector label or 2-digit code

Every candidate is checked against the live portal options in
hubspot_properties.json. If it isn't a real option there, the resolver falls
back to the NAICS-sector default; if that also fails, it returns
"unresolved" rather than guessing.

Prints one JSON object per input: {input, industry, naics, sector, method}.
"""

import difflib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
MAP_PATH = os.path.join(SKILL_DIR, "references", "industry_mapping.json")
SNAP_PATH = os.path.join(SKILL_DIR, "hubspot_properties.json")
FUZZY_CUTOFF = 0.86


def load():
    with open(MAP_PATH, encoding="utf-8") as f:
        mapping = json.load(f)
    portal_options = set()
    if os.path.exists(SNAP_PATH):
        snap = json.load(open(SNAP_PATH, encoding="utf-8"))
        portal_options = {o["value"] for o in
                          snap.get("industry", {}).get("options", [])}
    return mapping, portal_options


def norm(text):
    return "".join(c for c in text.strip().lower() if c.isalnum())


def portal_ok(candidate, portal_options):
    """Accept exact matches or whitespace/punctuation-only differences."""
    if candidate in portal_options:
        return candidate
    for opt in portal_options:
        if norm(opt) == norm(candidate):
            return opt
    return None


def enrich(industry, mapping):
    info = mapping["hubspot_to_naics"].get(industry, {})
    return info.get("naics"), info.get("sector")


def resolve(raw, mapping, portal_options):
    text = (raw or "").strip()
    if not text:
        return {"input": raw, "industry": None, "naics": None,
                "sector": None, "method": "unresolved"}

    canonical = {norm(k): k for k in mapping["hubspot_to_naics"]}

    # 1. exact (against canonical list)
    hit = canonical.get(norm(text))
    method = "exact"
    if not hit:
        # 2. synonym
        hit = mapping["synonyms"].get(text.lower())
        method = "synonym" if hit else None
    if not hit:
        # 3. fuzzy against canonical industries
        matches = difflib.get_close_matches(text, list(canonical),
                                            n=1, cutoff=FUZZY_CUTOFF)
        # difflib compares raw strings; normalize by matching on norm keys
        if not matches:
            norm_keys = list(canonical.keys())
            nm = difflib.get_close_matches(norm(text), norm_keys,
                                           n=1, cutoff=FUZZY_CUTOFF)
            if nm:
                hit, method = canonical[nm[0]], "fuzzy"
        else:
            hit, method = canonical[norm(matches[0])], "fuzzy"
    if not hit:
        # 4. NAICS sector label or 2-digit code
        sector_hit = None
        t = text.strip()
        if t in mapping["sector_defaults"]:
            sector_hit = mapping["sector_defaults"][t]
        else:
            for code, default in mapping["sector_defaults"].items():
                info = mapping["hubspot_to_naics"].get(default, {})
                if info.get("sector", "").lower() == t.lower():
                    sector_hit = default
                    break
        if sector_hit:
            hit, method = sector_hit, "sector"

    if not hit:
        return {"input": raw, "industry": None, "naics": None,
                "sector": None, "method": "unresolved"}

    # Validate against the live portal options; fall back to sector default.
    ok = portal_ok(hit, portal_options) if portal_options else hit
    if not ok:
        naics, _ = enrich(hit, mapping)
        default = mapping["sector_defaults"].get(naics) if naics else None
        ok = portal_ok(default, portal_options) if default else None
        if ok:
            hit, method = ok, method + "+sector-default"
        else:
            return {"input": raw, "industry": None, "naics": naics,
                    "sector": None, "method": "unresolved"}

    naics, sector = enrich(ok, mapping)
    return {"input": raw, "industry": ok, "naics": naics,
            "sector": sector, "method": method}


def main():
    if len(sys.argv) < 2:
        print("usage: python3 scripts/industry_resolver.py <industry> [...]",
              file=sys.stderr)
        sys.exit(1)
    mapping, portal_options = load()
    for raw in sys.argv[1:]:
        print(json.dumps(resolve(raw, mapping, portal_options)))


if __name__ == "__main__":
    main()
