#!/usr/bin/env python3
"""Refresh the portal property snapshot (hubspot_properties.json) from live HubSpot.

Usage:
    python3 scripts/refresh_hubspot_props.py

Reads the private-app token from HUBSPOT_PAT (env) or
~/.hubspot-upload/hubspot.env, fetches the live `industry` property
definition for companies, and rewrites hubspot_properties.json so the
resolver validates against current portal options.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
SNAP_PATH = os.path.join(SKILL_DIR, "hubspot_properties.json")
ENV_FILE = os.path.expanduser("~/.hubspot-upload/hubspot.env")


def load_token():
    token = os.environ.get("HUBSPOT_PAT", "").strip()
    if token:
        return token
    if os.path.exists(ENV_FILE):
        for line in open(ENV_FILE, encoding="utf-8"):
            line = line.strip()
            if line.startswith("HUBSPOT_PAT="):
                return line.split("=", 1)[1].strip().strip("'\"")
    print("ERROR: no token: set HUBSPOT_PAT or create " + ENV_FILE,
          file=sys.stderr)
    sys.exit(1)


def main():
    import requests
    token = load_token()
    r = requests.get(
        "https://api.hubapi.com/crm/v3/properties/companies/industry",
        headers={"Authorization": f"Bearer {token}"}, timeout=30)
    if r.status_code >= 400:
        print(f"ERROR: HubSpot returned HTTP {r.status_code}: {r.text[:300]}",
              file=sys.stderr)
        sys.exit(1)
    prop = r.json()
    snap = {
        "_note": "Refreshed from the live portal. Regenerate with: "
                 "python3 scripts/refresh_hubspot_props.py",
        "industry": {
            "name": prop.get("name", "industry"),
            "label": prop.get("label", "Industry"),
            "type": prop.get("type"),
            "fieldType": prop.get("fieldType"),
            "options": [{"label": o.get("label"), "value": o.get("value")}
                        for o in prop.get("options", [])],
        },
    }
    with open(SNAP_PATH, "w", encoding="utf-8") as f:
        json.dump(snap, f, indent=2)
        f.write("\n")
    print(f"wrote {SNAP_PATH} with "
          f"{len(snap['industry']['options'])} industry options")


if __name__ == "__main__":
    main()
