# Project Overview: [PROJECT_NAME]

**Generated:** [DATE]
**Owner:** [NAME]
**Status:** [Draft / Active / Complete]
**Audience:** Executive / stakeholder — readable in 5 minutes, no technical background required.

---

## Executive Summary

[2–3 sentences. What this project is, why it matters now, and what success looks like — plain language, no acronyms.]

## Business Use Case

**The problem:** [Who feels it, how it hurts today, cost of inaction.]

**The opportunity:** [What changes if this ships. Why now.]

**Who benefits:** [Primary users / customers / teams.]

## Goals & Success Metrics

| Goal | Target | Measured by |
|------|--------|-------------|
| [Primary goal] | [Number + date] | [Source/report] |
| [Secondary goal] | [Number + date] | [Source/report] |

**North-star outcome:** [One sentence — the single metric that matters most.]

## Scope

**In scope:**
- [Deliverable / capability 1]
- [Deliverable / capability 2]

**Out of scope:**
- [Explicit exclusion 1]
- [Explicit exclusion 2]

## Timeline & Milestones

| Milestone | Target date | Owner | Status |
|-----------|-------------|-------|--------|
| [Milestone 1] | [Date] | [Name] | [Not Started / In Progress / Complete] |
| [Milestone 2] | [Date] | [Name] | [Not Started / In Progress / Complete] |

## Stakeholders

| Role | Name | Responsibility |
|------|------|----------------|
| Owner | [Name] | [Decisions, accountability] |
| Sponsor | [Name] | [Approval, resourcing] |
| Builder | [Name] | [Execution] |

## Risks & Dependencies

| Risk / Dependency | Impact | Mitigation / Owner |
|-------------------|--------|--------------------|
| [Risk 1] | [High / Med / Low] | [Plan + owner] |

## Related Artifacts

- JTBD Document: [link]
- Build Guide: [link]
- PRD: [link, if produced]
- KPI Tracking: [link]
- Architecture Diagram: [link]

---

*If a slide deck is wanted instead of (or in addition to) this doc, generate it via `your-slide-deck-builder`.*
