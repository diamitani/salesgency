"""Build a static dashboard HTML from the execution store.

Usage: python3 scripts/dashboard/build.py [--days 7]
Writes dashboard/index.html (self-contained, no external assets).
"""
import argparse
import html
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import store

# skill root = two levels above scripts/dashboard/; dashboard/ lives at the root
SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DASH_DIR = os.path.join(SKILL_ROOT, "dashboard")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    args = ap.parse_args()
    conn = store.connect()
    workflows = [dict(r) for r in
                 conn.execute("SELECT id, name, active, last_seen FROM workflows "
                              "ORDER BY last_seen DESC")]
    for w in workflows:
        w["stats"] = store.workflow_stats(conn, w["id"], args.days)
        w["streak"] = store.consecutive_failures(conn, w["id"])
    fails = store.recent_failures(conn, 25, args.days)
    conn.close()

    rows = "\n".join(
        f"<tr><td>{html.escape(w['name'] or w['id'])}</td>"
        f"<td><code>{html.escape(w['id'])}</code></td>"
        f"<td>{w['stats']['total']}</td>"
        f"<td class='{'bad' if w['stats']['error_rate'] >= 0.2 else 'ok'}'>"
        f"{w['stats']['error_rate']*100:.1f}%</td>"
        f"<td>{w['streak']}</td>"
        f"<td>{w['stats']['avg_duration_ms']}ms</td></tr>"
        for w in workflows)

    frows = "\n".join(
        f"<tr><td>{html.escape(f['started_at'][:19])}</td>"
        f"<td>{html.escape(f['name'] or f['workflow_id'])}</td>"
        f"<td>{html.escape(f['status'])}</td>"
        f"<td>{html.escape((f['error'] or '')[:160])}</td></tr>"
        for f in fails)

    page = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>n8n execution dashboard — last {args.days}d</title>
<style>
body{{font-family:system-ui,sans-serif;max-width:1100px;margin:2rem auto;padding:0 1rem;color:#1a1a1a}}
table{{border-collapse:collapse;width:100%;margin:1rem 0}}
th,td{{border:1px solid #ddd;padding:.5rem .75rem;text-align:left;font-size:.9rem}}
th{{background:#f5f5f5}} .ok{{color:#1a7f37;font-weight:600}} .bad{{color:#b42318;font-weight:600}}
code{{font-size:.8rem;background:#f5f5f5;padding:.1rem .3rem;border-radius:3px}}
h1{{font-size:1.4rem}} h2{{font-size:1.1rem;margin-top:2rem}}
</style></head><body>
<h1>n8n execution dashboard</h1>
<p>Window: last {args.days} days · generated {html.escape(store.now_iso()[:19])}Z</p>
<h2>Workflows</h2>
<table><tr><th>Name</th><th>ID</th><th>Runs</th><th>Error rate</th><th>Fail streak</th><th>Avg duration</th></tr>
{rows or '<tr><td colspan="6">No executions ingested yet — run scripts/ingest.py first.</td></tr>'}
</table>
<h2>Recent failures</h2>
<table><tr><th>Time (UTC)</th><th>Workflow</th><th>Status</th><th>Error</th></tr>
{frows or '<tr><td colspan="4">None in window.</td></tr>'}
</table>
</body></html>"""

    os.makedirs(DASH_DIR, exist_ok=True)
    out = os.path.join(DASH_DIR, "index.html")
    with open(out, "w") as fh:
        fh.write(page)
    print(f"Wrote {out} ({len(workflows)} workflows, {len(fails)} failures)")


if __name__ == "__main__":
    main()
