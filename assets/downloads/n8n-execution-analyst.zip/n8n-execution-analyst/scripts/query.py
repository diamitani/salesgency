"""Grounded natural-language query over the execution store.

Usage: python3 scripts/query.py "<their question>"
Prints JSON: {"answer": "<plain-language answer>", "data": {...}}.
Every number in `answer` comes from `data`. If the store has no data for the
question, it says so — never guesses.

Understood intents (keyword-routed):
  execution <id> / why did <id> fail  -> per-execution diagnosis
  success rate / how many failed      -> per-workflow rates over --days
  recurring                           -> failures grouped by category+node
  stall / stuck / stopped running     -> stalled runs + quiet workflows
  recent failures                     -> latest failures
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diagnose
import store

OUT = {"answer": "", "data": {}}


def emit(answer, data):
    OUT["answer"] = answer
    OUT["data"] = data
    print(json.dumps(OUT, indent=2))


def intent_execution(conn, q):
    m = re.search(r"(?:execution\s+)?#?(\d+)", q)
    if not m:
        return None
    d = diagnose.why_failed(conn, m.group(1))
    if not d.get("found"):
        emit(f"No stored execution with id {m.group(1)}.", {"execution_id": m.group(1)})
        return True
    emit(
        f"Execution {d['execution_id']} ({d['workflow']}) ended {d['status']}"
        + (f" at node '{d['stop_node']}'" if d.get("stop_node") else "")
        + (f": {d['stop_reason'][:200]}" if d.get("stop_reason") else "."),
        d)
    return True


def intent_rates(conn, days):
    rows = conn.execute("SELECT id, name FROM workflows ORDER BY last_seen DESC").fetchall()
    stats = [store.workflow_stats(conn, r["id"], days) for r in rows]
    if not stats or all(s["total"] == 0 for s in stats):
        emit(f"No executions stored for the last {days} days.", {"days": days})
        return
    parts = [f"{s['workflow_id']}: {s['success']}/{s['total']} succeeded "
             f"({s['error_rate']*100:.1f}% errors)" for s in stats if s["total"]]
    emit(f"Last {days} days — " + "; ".join(parts) + ".",
         {"days": days, "workflows": stats})


def intent_recurring(conn, days):
    rec = diagnose.recurring(conn, days)
    if not rec:
        emit(f"No recurring failure pattern in the last {days} days.", {"days": days})
        return
    parts = [f"{r['c']}x {r['error_category']} at '{r['stop_node']}' "
             f"in {r['name'] or r['workflow_id']}" for r in rec[:5]]
    emit(f"Recurring failures (last {days}d): " + "; ".join(parts) + ".",
         {"days": days, "patterns": rec})


def intent_stalls(conn, days):
    stalled = diagnose.stalls(conn, 30)
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    quiet = [dict(r) for r in conn.execute(
        """SELECT w.id, w.name, MAX(e.started_at) last_run
           FROM workflows w LEFT JOIN executions e ON e.workflow_id = w.id
           WHERE w.active = 1 GROUP BY w.id HAVING MAX(e.started_at) IS NULL
           OR MAX(e.started_at) < ?""", (since,))]
    bits = []
    if stalled:
        bits.append(f"{len(stalled)} run(s) stuck >30m: " +
                    ", ".join(f"{s['id']} ({s['name'] or s['workflow_id']})" for s in stalled[:5]))
    if quiet:
        bits.append(f"{len(quiet)} active workflow(s) with no runs in {days}d: " +
                    ", ".join(q["name"] or q["id"] for q in quiet[:5]))
    if not bits:
        emit("No stalled runs and every active workflow has run recently.", {})
    else:
        emit(" ".join(bits) + ".", {"stalled": stalled, "quiet_workflows": quiet})


def intent_failures(conn, days):
    fails = store.recent_failures(conn, 10, days)
    if not fails:
        emit(f"No failures in the last {days} days.", {"days": days})
        return
    parts = [f"{f['id']} ({f['name'] or f['workflow_id']}): "
             f"{(f['error'] or f['stop_reason'] or f['status'])[:100]}" for f in fails[:5]]
    emit(f"Latest failures: " + " | ".join(parts),
         {"days": days, "failures": fails})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("question", nargs="?", default="")
    ap.add_argument("--days", type=int, default=7)
    args = ap.parse_args()
    q = args.question.lower()
    conn = store.connect()

    if re.search(r"execution|why did|why failed", q) and re.search(r"\d", q):
        intent_execution(conn, q)
    elif re.search(r"success rate|how many|fail.*rate|error rate", q):
        intent_rates(conn, args.days)
    elif "recurr" in q:
        intent_recurring(conn, args.days)
    elif re.search(r"stall|stuck|stopped running|haven't run|hasn't run|quiet|inactive", q):
        intent_stalls(conn, args.days)
    elif "fail" in q:
        intent_failures(conn, args.days)
    else:
        n = conn.execute("SELECT COUNT(*) c FROM executions").fetchone()["c"]
        nw = conn.execute("SELECT COUNT(*) c FROM workflows").fetchone()["c"]
        emit(f"The store holds {n} executions across {nw} workflows. "
             "Ask about success rates, a specific execution id, recurring failures, "
             "or stalled runs.",
             {"executions": n, "workflows": nw})
    conn.close()


if __name__ == "__main__":
    main()
