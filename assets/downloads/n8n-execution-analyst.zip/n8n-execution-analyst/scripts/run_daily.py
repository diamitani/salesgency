"""Daily runner: ingest, print the health digest, run alerts, rebuild dashboard.

Intended for cron, e.g.:
  0 6 * * * cd /path/to/skill && /usr/bin/python3 scripts/run_daily.py >> logs/daily.log 2>&1

Usage: python3 scripts/run_daily.py [--limit 500] [--fixtures tests/fixtures]
"""
import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alert as alert_mod
import diagnose
import ingest
import store


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=500)
    ap.add_argument("--fixtures", default=None)
    args = ap.parse_args()

    if args.fixtures:
        n = ingest.ingest_fixtures(args.fixtures)
    else:
        for v in ("N8N_BASE_URL", "N8N_API_KEY"):
            if not os.environ.get(v):
                sys.exit(f"Missing env {v} — see docs/README.md, "
                         "or pass --fixtures tests/fixtures for offline demo.")
        n = ingest.ingest_live(limit=args.limit)
    print(f"ingested={n}")

    conn = store.connect()
    print("--- 24h workflow health ---")
    for r in conn.execute("SELECT id, name FROM workflows ORDER BY last_seen DESC"):
        s = store.workflow_stats(conn, r["id"], days=1)
        print(f"{r['name'] or r['id']}: {s['total']} runs, "
              f"{s['error_rate']*100:.1f}% errors")
    fails = store.recent_failures(conn, 10, days=1)
    if fails:
        print("--- recent failures ---")
        for f in fails:
            print(f"{f['started_at']} [{f['workflow_id']}] {f['stop_node']}: "
                  f"{(f['error'] or '')[:120]}")
    rec = diagnose.recurring(conn, days=1)
    if rec:
        print("--- recurring ---")
        for p in rec[:5]:
            print(f"{p['c']}x {p['error_category']} @ {p['stop_node']} "
                  f"in {p['name'] or p['workflow_id']}")
    stalled = diagnose.stalls(conn, 30)
    if stalled:
        print("--- stalled ---")
        for s_ in stalled:
            print(f"{s_['id']} [{s_['name'] or s_['workflow_id']}] {s_['status']} "
                  f"since {s_['started_at'][:19]}")
    conn.close()

    print("--- alerts ---")
    alerts = alert_mod.check(days=1)
    if alerts:
        for line in alerts:
            print("ALERT:", line)
        alert_mod.post_webhook(alerts)
    else:
        print("OK — no alerts.")

    print("--- dashboard ---")
    subprocess.run([sys.executable,
                    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "dashboard", "build.py"),
                    "--days", "7"], check=True)


if __name__ == "__main__":
    main()
