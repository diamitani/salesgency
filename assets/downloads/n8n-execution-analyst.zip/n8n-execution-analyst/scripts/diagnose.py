"""Diagnosis against the execution store.

Usage:
  python3 scripts/diagnose.py --execution <id>   # why did this run fail
  python3 scripts/diagnose.py --recurring [--days 7]   # failures grouped by category+node
  python3 scripts/diagnose.py --stalls [--minutes 30]  # runs still 'new'/'waiting' too long
"""
import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import store

STALLED_STATUSES = ("new", "waiting")


def why_failed(conn, exec_id):
    ex = store.get_execution(conn, exec_id)
    if not ex:
        return {"execution_id": exec_id, "found": False}
    nodes = json.loads(ex.get("node_errors") or "[]")
    return {
        "execution_id": exec_id,
        "found": True,
        "workflow": ex.get("workflow_name") or ex.get("workflow_id"),
        "status": ex.get("status"),
        "mode": ex.get("mode"),
        "started_at": ex.get("started_at"),
        "stop_node": ex.get("stop_node"),
        "stop_reason": ex.get("stop_reason"),
        "error_category": ex.get("error_category"),
        "node_errors": nodes,
    }


def recurring(conn, days=7):
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    rows = conn.execute(
        """SELECT e.workflow_id, w.name, e.error_category, e.stop_node,
                  COUNT(*) c, MAX(e.started_at) last_seen
           FROM executions e JOIN workflows w ON w.id = e.workflow_id
           WHERE e.status IN ('error','crashed') AND e.started_at>=?
           GROUP BY e.workflow_id, e.error_category, e.stop_node
           HAVING COUNT(*) >= 2
           ORDER BY c DESC""", (since,)).fetchall()
    return [dict(r) for r in rows]


def stalls(conn, minutes=30):
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat()
    rows = conn.execute(
        """SELECT e.id, e.workflow_id, w.name, e.status, e.started_at
           FROM executions e JOIN workflows w ON w.id = e.workflow_id
           WHERE e.status IN ('new','waiting') AND e.started_at < ?
           ORDER BY e.started_at""", (cutoff,)).fetchall()
    return [dict(r) for r in rows]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--execution")
    ap.add_argument("--recurring", action="store_true")
    ap.add_argument("--stalls", action="store_true")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--minutes", type=int, default=30)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    conn = store.connect()

    if args.execution:
        out = why_failed(conn, args.execution)
    elif args.recurring:
        out = recurring(conn, args.days)
    elif args.stalls:
        out = stalls(conn, args.minutes)
    else:
        ap.print_help()
        return
    conn.close()
    if args.json or isinstance(out, dict):
        print(json.dumps(out, indent=2))
    else:
        if not out:
            print("Nothing found.")
        for r in out:
            print(f"{r['c']}x [{r['name'] or r['workflow_id']}] "
                  f"{r['error_category']} @ {r['stop_node']} (last {r['last_seen'][:19]})"
                  if "c" in r else
                  f"{r['id']} [{r['name'] or r['workflow_id']}] {r['status']} "
                  f"since {r['started_at'][:19]}")


if __name__ == "__main__":
    main()
