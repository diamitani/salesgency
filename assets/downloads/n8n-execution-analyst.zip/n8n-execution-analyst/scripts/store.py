"""SQLite store for the chatbot workflow execution analyst.

Shared library used by ingest.py, query.py, alert.py, run_daily.py and
dashboard/build.py. stdlib only.

Tables:
  workflows  - one row per n8n workflow id: id, name, active, first_seen, last_seen
  executions - one row per execution: id, workflow_id, status, started_at,
               finished_at, duration_ms, error, node_errors (JSON)
Status values mirror the n8n API: success | error | cancelled | waiting | crashed | new
"""
import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone

DB_PATH = os.environ.get(
    "EXEC_STORE_DB",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                 "data", "executions.db"),
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS workflows (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS executions (
    id TEXT PRIMARY KEY,
    workflow_id TEXT NOT NULL REFERENCES workflows(id),
    status TEXT NOT NULL,
    mode TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    duration_ms INTEGER,
    error TEXT,
    node_errors TEXT,
    stop_node TEXT,
    stop_reason TEXT,
    error_category TEXT,
    raw_json TEXT,
    created_row TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_exec_wf_time ON executions (workflow_id, started_at);
CREATE INDEX IF NOT EXISTS idx_exec_status ON executions (status);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect(path: str = DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def upsert_workflow(conn, wf_id: str, name: str = "", active: int = 1) -> None:
    ts = now_iso()
    conn.execute(
        """INSERT INTO workflows (id, name, active, first_seen, last_seen)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name, active=excluded.active, last_seen=excluded.last_seen""",
        (wf_id, name, active, ts, ts),
    )


def insert_execution(conn, exec_id: str, workflow_id: str, status: str,
                     started_at: str, finished_at: str | None = None,
                     duration_ms: int | None = None, error: str | None = None,
                     node_errors: list | None = None, mode: str | None = None,
                     stop_node: str | None = None, stop_reason: str | None = None,
                     error_category: str | None = None,
                     raw_json: str | None = None) -> None:
    conn.execute(
        """INSERT INTO executions
           (id, workflow_id, status, started_at, finished_at, duration_ms, error,
            node_errors, mode, stop_node, stop_reason, error_category, raw_json)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             status=excluded.status, finished_at=excluded.finished_at,
             duration_ms=excluded.duration_ms, error=excluded.error,
             node_errors=excluded.node_errors, mode=excluded.mode,
             stop_node=excluded.stop_node, stop_reason=excluded.stop_reason,
             error_category=excluded.error_category, raw_json=excluded.raw_json""",
        (exec_id, workflow_id, status, started_at, finished_at, duration_ms,
         error, json.dumps(node_errors or []), mode, stop_node, stop_reason,
         error_category, raw_json),
    )


def workflow_stats(conn, workflow_id: str, days: int = 7) -> dict:
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    rows = conn.execute(
        """SELECT status, COUNT(*) c
           FROM executions WHERE workflow_id=? AND started_at>=?
           GROUP BY status""",
        (workflow_id, since)).fetchall()
    total = sum(r["c"] for r in rows)
    ok = sum(r["c"] for r in rows if r["status"] == "success")
    avg = conn.execute(
        "SELECT AVG(duration_ms) a FROM executions WHERE workflow_id=? AND started_at>=? "
        "AND duration_ms IS NOT NULL", (workflow_id, since)).fetchone()["a"]
    return {
        "workflow_id": workflow_id,
        "days": days,
        "total": total,
        "success": ok,
        "error_rate": round(1 - ok / total, 3) if total else 0.0,
        "by_status": {r["status"]: r["c"] for r in rows},
        "avg_duration_ms": round(avg or 0),
    }


def recent_failures(conn, limit: int = 20, days: int = 7) -> list[dict]:
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    rows = conn.execute(
        """SELECT e.id, e.workflow_id, w.name, e.status, e.mode, e.started_at,
                  e.finished_at, e.duration_ms, e.error, e.node_errors,
                  e.stop_node, e.stop_reason, e.error_category
           FROM executions e JOIN workflows w ON w.id = e.workflow_id
           WHERE e.status IN ('error','crashed') AND e.started_at>=?
           ORDER BY e.started_at DESC LIMIT ?""",
        (since, limit)).fetchall()
    return [dict(r) for r in rows]


def get_execution(conn, exec_id: str) -> dict | None:
    row = conn.execute(
        """SELECT e.*, w.name AS workflow_name FROM executions e
           JOIN workflows w ON w.id = e.workflow_id WHERE e.id=?""",
        (exec_id,)).fetchone()
    return dict(row) if row else None


def consecutive_failures(conn, workflow_id: str, limit: int = 10) -> int:
    rows = conn.execute(
        """SELECT status FROM executions WHERE workflow_id=?
           ORDER BY started_at DESC LIMIT ?""",
        (workflow_id, limit)).fetchall()
    n = 0
    for r in rows:
        if r["status"] in ("error", "crashed"):
            n += 1
        else:
            break
    return n


if __name__ == "__main__":
    conn = connect()
    conn.close()
    print(f"Store ready at {DB_PATH}")
