"""Pull n8n executions into the local SQLite store.

Env: N8N_BASE_URL, N8N_API_KEY (see docs/README.md).
Usage:
  python3 scripts/ingest.py [--limit 200] [--workflow <id>] [--full]
  python3 scripts/ingest.py --from-fixtures tests/fixtures   # offline demo, no key needed
"""
import argparse
import glob
import json
import os
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parse
import store


def api_get(path: str, params: dict | None = None) -> dict:
    base = os.environ["N8N_BASE_URL"].rstrip("/")
    key = os.environ["N8N_API_KEY"]
    qs = ""
    if params:
        qs = "?" + "&".join(f"{k}={v}" for k, v in params.items())
    req = urllib.request.Request(base + path + qs,
                                 headers={"X-N8N-API-KEY": key,
                                          "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode())


def store_record(conn, ex: dict) -> None:
    rec = parse.extract_record(ex)
    store.upsert_workflow(conn, rec["workflow_id"], rec["workflow_name"],
                          rec["workflow_active"])
    store.insert_execution(
        conn, rec["exec_id"], rec["workflow_id"], rec["status"],
        rec["started_at"], rec["finished_at"], rec["duration_ms"], rec["error"],
        rec["node_errors"], mode=rec["mode"], stop_node=rec["stop_node"],
        stop_reason=rec["stop_reason"], error_category=rec["error_category"],
        raw_json=rec["raw_json"])


def ingest_live(limit: int = 200, workflow_id: str | None = None,
                full: bool = False) -> int:
    conn = store.connect()
    params = {}
    if workflow_id:
        params["workflowId"] = workflow_id
    n, cursor, target = 0, None, (10 ** 9 if full else limit)
    while n < target:
        params["limit"] = min(250, target - n)
        if cursor:
            params["cursor"] = cursor
        page = api_get("/api/v1/executions", params)
        items = page.get("data", [])
        if not items:
            break
        for ex in items:
            store_record(conn, ex)
            n += 1
        cursor = page.get("nextCursor")
        if not cursor:
            break
    conn.commit()
    conn.close()
    return n


def ingest_fixtures(fixtures_dir: str) -> int:
    conn = store.connect()
    n = 0
    for path in sorted(glob.glob(os.path.join(fixtures_dir, "*.json"))):
        with open(path) as fh:
            payload = json.load(fh)
        items = payload.get("data", payload) if isinstance(payload, dict) else payload
        if isinstance(items, dict):
            items = [items]
        for ex in items:
            store_record(conn, ex)
            n += 1
    conn.commit()
    conn.close()
    return n


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--workflow", default=None)
    ap.add_argument("--full", action="store_true",
                    help="backfill: paginate through everything")
    ap.add_argument("--from-fixtures", default=None,
                    help="load fixture JSONs instead of calling the API")
    args = ap.parse_args()

    if args.from_fixtures:
        n = ingest_fixtures(args.from_fixtures)
        print(f"Loaded {n} fixture executions into {store.DB_PATH}")
        return
    for v in ("N8N_BASE_URL", "N8N_API_KEY"):
        if not os.environ.get(v):
            sys.exit(f"Missing env {v} — see docs/README.md. "
                     "Or demo offline: --from-fixtures tests/fixtures")
    n = ingest_live(args.limit, args.workflow, args.full)
    print(f"Ingested {n} executions into {store.DB_PATH}")


if __name__ == "__main__":
    main()
