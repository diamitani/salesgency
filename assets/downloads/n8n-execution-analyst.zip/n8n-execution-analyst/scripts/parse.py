"""Extractor: n8n API execution payload -> canonical store record.

Used by ingest.py (and usable standalone). Never invents values: anything the
payload doesn't carry comes back as None.
"""
import json

RAW_JSON_CAP = 200_000  # bytes; raw payloads are for forensics, not warehousing


def _duration_ms(ex):
    try:
        from datetime import datetime
        s, f = ex.get("startedAt"), ex.get("stoppedAt")
        if not (s and f):
            return None
        s = datetime.fromisoformat(s.replace("Z", "+00:00"))
        f = datetime.fromisoformat(f.replace("Z", "+00:00"))
        return int((f - s).total_seconds() * 1000)
    except Exception:
        return None


def _node_errors(ex):
    """Per-node errors from resultData.runData: [{node, message}]."""
    out = []
    try:
        run_data = ((ex.get("data") or {}).get("resultData") or {}).get("runData") or {}
        for name, runs in run_data.items():
            for item in runs or []:
                err = (item or {}).get("error")
                if err:
                    out.append({"node": name,
                                "message": str(err.get("message", ""))[:300]})
    except Exception:
        pass
    return out


def _top_error(ex):
    try:
        e = ((ex.get("data") or {}).get("resultData") or {}).get("error") or {}
        return e.get("message") or e.get("description")
    except Exception:
        return None


def _stop_node(ex, node_errors):
    """Where it stopped: the erroring node if known, else the last node with run data."""
    if node_errors:
        return node_errors[0]["node"]
    try:
        run_data = ((ex.get("data") or {}).get("resultData") or {}).get("runData") or {}
        keys = list(run_data.keys())
        return keys[-1] if keys else None
    except Exception:
        return None


def categorize(error, node_errors):
    """Coarse error category for recurring-failure grouping. Heuristic, honest."""
    text = " ".join([error or ""] + [n.get("message", "") for n in node_errors]).lower()
    if not text.strip():
        return "unknown"
    for needle, cat in [
        ("timeout", "timeout"), ("timed out", "timeout"),
        ("econnrefused", "connection"), ("enotfound", "connection"),
        ("econnreset", "connection"), ("socket hang up", "connection"),
        ("429", "rate_limit"), ("rate limit", "rate_limit"),
        ("401", "auth"), ("403", "auth"), ("unauthorized", "auth"),
        ("404", "not_found"),
        ("out of memory", "resource"), ("oom", "resource"),
        ("cannot read", "data_shape"), ("undefined", "data_shape"),
        ("nonexistent", "data_shape"),
    ]:
        if needle in text:
            return cat
    return "other"


def extract_record(ex):
    """Return the canonical dict for one n8n execution payload."""
    wf = ex.get("workflowData") or {}
    node_errors = _node_errors(ex)
    error = _top_error(ex)
    raw = json.dumps(ex)
    return {
        "exec_id": str(ex.get("id")),
        "workflow_id": str(ex.get("workflowId") or wf.get("id") or "unknown"),
        "workflow_name": wf.get("name", ""),
        "workflow_active": 1 if wf.get("active", True) else 0,
        "status": ex.get("status", "unknown"),
        "mode": ex.get("mode"),
        "started_at": ex.get("startedAt", ""),
        "finished_at": ex.get("stoppedAt"),
        "duration_ms": _duration_ms(ex),
        "error": error,
        "node_errors": node_errors,
        "stop_node": _stop_node(ex, node_errors),
        "stop_reason": error,
        "error_category": categorize(error, node_errors)
        if (ex.get("status") in ("error", "crashed")) else None,
        "raw_json": raw[:RAW_JSON_CAP],
    }
