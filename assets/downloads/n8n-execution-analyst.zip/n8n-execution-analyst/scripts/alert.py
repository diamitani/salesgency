"""Alert checks against the execution store.

Thresholds (env-overridable):
  ALERT_ERROR_RATE   default 0.20  — 7-day error rate per workflow
  ALERT_STREAK       default 3     — consecutive failures per workflow
Optional: ALERT_WEBHOOK — POSTs the alert lines as JSON {"text": ...}.
Dry-run by default: nothing is ever sent unless ALERT_DRY_RUN=false.

Usage: python3 scripts/alert.py [--days 7]
Exit code 1 when any alert fires (useful for cron).
"""
import argparse
import json
import os
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import store


def check(days: int = 7) -> list[str]:
    err_rate = float(os.environ.get("ALERT_ERROR_RATE", "0.20"))
    streak_n = int(os.environ.get("ALERT_STREAK", "3"))
    conn = store.connect()
    alerts: list[str] = []
    for r in conn.execute("SELECT id, name FROM workflows ORDER BY last_seen DESC"):
        s = store.workflow_stats(conn, r["id"], days)
        if s["total"] >= 5 and s["error_rate"] >= err_rate:
            alerts.append(
                f"HIGH ERROR RATE: {r['name'] or r['id']} — "
                f"{s['error_rate']*100:.1f}% errors over {s['total']} runs ({days}d)")
        n = store.consecutive_failures(conn, r["id"])
        if n >= streak_n:
            alerts.append(
                f"FAILING STREAK: {r['name'] or r['id']} — {n} consecutive failures")
    conn.close()
    return alerts


def post_webhook(lines: list[str]) -> None:
    """Send only when the user explicitly enables it. ALERT_DRY_RUN defaults
    to "true": printing alert lines never sends anything."""
    url = os.environ.get("ALERT_WEBHOOK")
    if not url:
        return
    if os.environ.get("ALERT_DRY_RUN", "true").lower() != "false":
        print("(dry-run: webhook configured but ALERT_DRY_RUN is not 'false' — "
              "nothing was sent)")
        return
    body = json.dumps({"text": "n8n execution alerts:\n" + "\n".join(lines)}).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30):
        pass


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    args = ap.parse_args()
    alerts = check(args.days)
    if not alerts:
        print("OK — no alerts.")
        return
    for line in alerts:
        print("ALERT:", line)
    post_webhook(alerts)
    sys.exit(1)


if __name__ == "__main__":
    main()
