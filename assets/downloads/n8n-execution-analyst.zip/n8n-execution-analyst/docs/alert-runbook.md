# Alert runbook

`scripts/alert.py` checks the store against thresholds and notifies. It is
**dry-run by default**: it prints `ALERT:` lines and exits 1, sending nothing.

## Thresholds (env)

| Var | Default | Fires when |
|---|---|---|
| `ALERT_ERROR_RATE` | `0.20` | a workflow with ≥ 5 runs in the window meets/exceeds it |
| `ALERT_STREAK` | `3` | that many consecutive failures on one workflow |

## Enabling real notifications

1. Set `ALERT_WEBHOOK` to an HTTPS endpoint that accepts `{"text": "..."}`
   (e.g. a Slack incoming webhook). Alerts remain dry-run: they print
   `ALERT:` lines and a "(dry-run … nothing was sent)" note.
2. Run once by hand: `python3 scripts/alert.py --days 1`. Confirm the message
   content reads correctly — nothing is delivered.
3. Only after confirming with the user, set `export ALERT_DRY_RUN=false` in
   the cron environment. Then `post_webhook` delivers.

## Responding to an alert

1. `python3 scripts/diagnose.py --execution <id>` — stop node + reason.
2. `python3 scripts/diagnose.py --recurring --days 7` — is it a pattern?
3. Check the category: `rate_limit`/`auth` → credentials or quota in n8n;
   `connection` → downstream service; `data_shape` → upstream payload changed.
4. Fix in n8n (this skill is read-only — it never edits workflows).
5. Re-run `scripts/run_daily.py` to confirm the streak clears.

## Quiet workflows

`scripts/query.py "which active workflows stopped running"` lists active
workflows with no recent runs — the silent failure mode alerts can't see
(no executions = no errors). Review weekly.
