# n8n Execution Analyst — docs

## Setup

1. n8n → **Settings → n8n API → Create an API key**.
2. Export before any live run:
   ```bash
   export N8N_API_KEY="<your key>"
   export N8N_BASE_URL="https://your-instance.app.n8n.cloud"
   ```
3. `python3 scripts/store.py` — one-time DB init (`data/executions.db`).
4. `python3 scripts/ingest.py --limit 50` — pilot pull.

No key yet? Demo offline: `python3 scripts/ingest.py --from-fixtures tests/fixtures`.

## Daily loop

`python3 scripts/run_daily.py` — ingest → health digest → alert check →
dashboard rebuild. Wire to cron at 06:00 CT.

## Answering questions

`python3 scripts/query.py "<question>"` prints `{"answer", "data"}` JSON.
Relay the `answer` in plain language, citing execution IDs from `data`.
Never state a number that isn't in that output.

## Modules

| Script | Role |
|---|---|
| `scripts/store.py` | SQLite DAL: workflows + executions tables, stats helpers |
| `scripts/parse.py` | Extractor: n8n API payload → canonical record |
| `scripts/ingest.py` | n8n API client (`--limit`, `--workflow`, `--full`, `--from-fixtures`) |
| `scripts/diagnose.py` | `--execution`, `--recurring`, `--stalls` |
| `scripts/query.py` | Grounded NL query → `{"answer","data"}` JSON |
| `scripts/alert.py` | Threshold notifier, dry-run by default |
| `scripts/run_daily.py` | Orchestrator: ingest → digest → alerts → dashboard |
| `scripts/dashboard/build.py` | Static HTML dashboard → `dashboard/index.html` |

See `SCHEMA.md` for the store layout and `alert-runbook.md` for alerting.
