# Execution store schema

SQLite at `data/executions.db` (override with `EXEC_STORE_DB`). Created by
`scripts/store.py`; rows written by `scripts/ingest.py` via `scripts/parse.py`.

## workflows

| Column | Meaning |
|---|---|
| id | n8n workflow id (PK) |
| name | workflow display name |
| active | 1 = active, 0 = inactive |
| first_seen / last_seen | ISO-8601 UTC ingestion timestamps |

## executions

| Column | Meaning |
|---|---|
| id | n8n execution id (PK) |
| workflow_id | FK → workflows.id |
| status | `success` · `error` · `cancelled` · `waiting` · `crashed` · `new` |
| mode | n8n run mode (`trigger`, `webhook`, `manual`, `retry`, …), null when unknown |
| started_at / finished_at | ISO-8601 UTC |
| duration_ms | finished − started, null when unknown |
| error | top-level error message, null on success |
| node_errors | JSON array of `{"node", "message"}` |
| stop_node | node where the run stopped (erroring node, else last node with run data) |
| stop_reason | same as `error`; the human-readable "why it stopped" |
| error_category | heuristic bucket for grouping: `timeout`, `connection`, `rate_limit`, `auth`, `not_found`, `resource`, `data_shape`, `other`, `unknown` |
| raw_json | full n8n API payload, capped at 200KB, for forensics |
| created_row | row insertion time (UTC) |

Indexes: `(workflow_id, started_at)`, `(status)`.

## Derived metrics (`scripts/store.py`, `scripts/diagnose.py`)

- **error_rate** = 1 − success/total over the window.
- **consecutive failures** = failing runs since the last non-failing run.
- **recurring** = failures grouped by (workflow, error_category, stop_node), count ≥ 2.
- **stalls** = runs still `new`/`waiting` older than the threshold (default 30 min).
